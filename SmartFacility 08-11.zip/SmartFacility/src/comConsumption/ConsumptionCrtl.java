
/*this whole class is commented as it is not required now but its temporary*/

/*package comConsumption;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.JSONException;
import org.json.JSONObject;


@Path("/consumptionTcs")
public class ConsumptionCrtl {
	
	

	@SuppressWarnings("resource")
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public ArrayList<String[]> getCsvFileData()
	{

//		System.out.println("inservlet getCsvData");
		
		*//** String csvFile = "C:\\Users\\1252807\\11111111111\\FloorVsDevices.csv";
		 * C://workspace/IICTestBed/WebContent 
		 ***//*
		String csvFile = "C://LekhaWorkspaces/TestbedWS/IICTestBed/WebContent/_resources/FloorVsDevices.csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		int i=0;
	
		ArrayList<String[]> al= new ArrayList<String[]>();
		String[] data = null;
		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {
							
				// use comma as separator
				data = line.split(cvsSplitBy);
//				System.out.println(Arrays.toString(data));       // http://stackoverflow.com/questions/8410294/why-does-printlnarray-have-strange-output-ljava-lang-string3e25a5     
//				System.out.println("\t");                       // here we use Arrays.toString  The toString() method of an array returns a String describing the identity of the array rather than its contents. That's because arrays don't override Object.toString()
				al.add(data);
				System.out.println(Arrays.toString(al));
				System.out.println("\t");				
								
			}
				
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
	
		}
		
		for (String[] arr : al) {
            System.out.println(Arrays.toString(arr));       // same way we required to cast into String to print Arraylist 
        }                                                  //http://stackoverflow.com/questions/7676528/print-a-string-from-arraylist-of-string
		
		System.out.println(al);
		return al; 				
	}
	
}
*/