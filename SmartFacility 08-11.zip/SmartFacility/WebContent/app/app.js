﻿/** loads the Visualization API and the linechart package * */

google.load('visualization', '1', {packages : [ 'gauge', 'line','corechart' ]});

//google.charts.load('current', {packages: ['corechart','line']});
/** sets a callback to run when the Google Visualization API is loaded * */
google.setOnLoadCallback(function() {
	angular.bootstrap(document.body, [ 'app' ]);
});


// angular.js main app initialization
/*var app = angular.module("app", [ 'ui.router', 'ui.bootstrap' ]);*/
var app = angular.module("app", [ 'ui.router', 'ui.bootstrap', 'angularTreeview', 'angular.filter', 'ui.grid' ]);

app.run([ '$rootScope', '$state', '$stateParams', function($rootScope, $state, $stateParams) {
			$rootScope.$state = $state;
			$rootScope.$stateParams = $stateParams;
		} ]);

// Google Map directive
/*
 * app.config(['uiGmapGoogleMapApiProvider', function (GoogleMapApi) {
 * GoogleMapApi.configure({ //key: 'your api key', // v: '3.20', libraries:
 * 'weather,geometry,visualization' }); }])
 */

app.config(function($stateProvider, $urlRouterProvider, $locationProvider) {

	      
	$stateProvider.state('login', {
		url : '/login',
		templateUrl : 'app/partials/login/loginSignUp.html',
		controller : 'loginPageCtrl',
	})
	
	.state('home', {
		url : '/home',
		templateUrl : 'app/partials/home/home.html',
		
		//abstract: true
		// controller: homeCtrl
		// U can define controller here or in html file directly if u use many
		// controller for single html file.
	}) 
	
	.state('tcs', {
		url : '/tcs',
		templateUrl : 'app/partials/tcs/tcs1.html',
	})
	
	.state('adminHome', {
		url : '/admin',
		templateUrl : 'app/partials/adminConfiguration/adminHome.html'
        
	})
	
	.state('dashboardHome', {
		url : '',
		templateUrl : 'app/partials/dashboards/dashboardHome/dashboardHome.html',
		abstract: true
	})
	
	.state('dashboardLinksFirst', {
		url : '/dashboards',
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/dashboardHome/dashboardLinksFirst.html',
			}
		}
	})
	
	.state('energyManagement', {
		url : '/energyManagement',
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/dashboardHome/dashboardLinks.html',
			}
		}
	})
	
	.state('energyBlank', {
		url : '/energyBlank',
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/energyFacilityBlank/energyFacilityBlank.html',
			}
		}
	})
	
	.state('facilityBlank', {
		url : '/facilityBlank',
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityManagementBlank/facilityManagementBlank.html',
			}
		}
	})
	
	/*.state('dashboardLinks', {
		url : '/dashboardLinks',
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/dashboardHome/dashboardLinkPage.html',
			}
		}
	})*/
	
	.state('consumption', {
		url : '/consumption',
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityEnergyManagement/equipmentMonitoring/consumption.html',
			}
		}
	})
	
	/*.state('consumptionCom', {
		url : '/consumptionCom',
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/consumption/consumptionCom.html',
			}
		}
	})
	
	.state('consumptionComThird', {
		url : '/consumptionComThird',
        parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/consumption/consumptionComThird.html',
			}
		}
	})
	
	.state('consumptionComSeven', {
		url : '/consumptionComSeven',
        parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/consumption/consumptionComSeven.html',
			}
		}
	})*/
	
	.state('monitoringCost', {
		url : '/monitoringCost',
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityEnergyManagement/monitoringCost/monitoringCost.html',
			}
		}
	})
	
	.state('bioGasGeneration', {
		url : '/bioGasGeneration',
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityEnergyManagement/bioGasGeneration/bioGasGeneration.html',
			}
		}
	})
	
	.state('foodWasteManagement', {
		url : '/foodWasteManagement',
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityWasteManagement/foodWasteManagement.html',
			}
		}
	})
	
	.state('waterManagement', {
		url : '/waterManagement',
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityWaterManagement/waterManagement.html',
			}
		}
	}) 
	
//	.state('waterGasUsage', {
//		url : '/waterGasUsage',
//        parent: 'dashboardHome',
//		views: {
//			'dashboardContent@dashboardHome':{
//				templateUrl : 'app/partials/dashboards/waterGasUsage/waterGasUsage.html',
//			}
//		}
//	})
	
	.state('heatMap', {
		url : '/heatMap',
        parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityEnergyManagement/consumptionHeatMap/heatMap.html',
			}
		}
	})
	
	.state('occupancyAnalysis', {
		url : '/occupancyAnalysis',
        parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityEnergyManagement/occupancyAnalysis/occupancyAnalysis.html',
			}
		}
	})
	
	.state('occupancyAnalysis.occupancyAnalysisHeatMap', {
		url : '/occupancyAnalysisHeatMap',
		views: {
			'occupancyContent@occupancyAnalysis':{
				templateUrl : 'app/partials/dashboards/facilityEnergyManagement/occupancyAnalysis/occupancyAnalysisHeatMap.html',
			}
		}
	})
	
		.state('occupancyAnalysis.occupancyAnalysisMonthly', {
		url : '/occupancyAnalysisMonthly',
		views: {
			'occupancyContent@occupancyAnalysis':{
				templateUrl : 'app/partials/dashboards/facilityEnergyManagement/occupancyAnalysis/occupancyAnalysisMonthly.html',
			}
		}
	})
	
	.state('occupancyAnalysis.occupancyAnalysisWeekly', {
		url : '/occupancyAnalysisWeekly',
		views: {
			'occupancyContent@occupancyAnalysis':{
				templateUrl : 'app/partials/dashboards/facilityEnergyManagement/occupancyAnalysis/occupancyAnalysisWeekly.html',
			}
		}
	})
	.state('equipmentAnalysis', {
		url : '/equipmentAnalysis',
        parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/equipmentAnalysis.html',
			}
		}
	})
	
	.state('performance', {
		url : '/equipmentPerformance',
        parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/equipmentAnalysis/performance.html',
			}
		}
	})
	
	.state('prediction', {
		url : '/equipmentPerformance',
        parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/equipmentAnalysis/prediction.html',
			}
		}
	})
	
	.state('analysisConsumption', {
		url : '/consumptionAnalysis',
        parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityEnergyManagement/analysis-consumption/analysisConsumption.html',
			}
		}
	})
	
	.state('analysisEnergyCost', {
		url : '/energyCostAnalysis',
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityEnergyManagement/analysis-energyCost/analysisEnergyCost.html',
			}
		}
	})
	
	.state('meterSummary', {
		url : '/meterSummary',
        parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityEnergyManagement/meterSummary/meterSummary.html',
			}
		}
	})	
	
	.state('energyManagerDashboard', {
		url : '/energyManagerDashboard',
		
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityEnergyManagement/summary/energyManagerDashboard/energyManagerDashboard.html',
			}
		}
	})
	
	.state('executiveDashboard', {
		url : '/executiveDashboard',
		
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityEnergyManagement/summary/executiveDashboard/executiveDashboard.html',
			}
		}
	})
	
	.state('maintenanceStaff', {
		url : '/maintenanceStaff',
		
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityEnergyManagement/summary/maintenanceStaff/maintenanceStaff.html',
			}
		}
	})
	
		.state('incidentManagement', {
		url : '/incidentManagement',
		
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityIncidentManagement/incident.html',
			}
		}
	})
	
	.state('parkingManagement', {
		url : '/parkingManagement',
		
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityParkingManagement/parking.html',
			}
		}
	})
	
	.state('fireManagement', {
		url : '/fireManagement',
		
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityFireManagement/fire.html',
			}
		}
	})
	
	.state('sustainabilityPune', {
		url : '/sustainabilityPune',
		
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/sustainabilityKPI/sustainabilityKPIPune.html',
			}
		}
	})
	
	.state('sustainabilityKolkata', {
		url : '/sustainabilityKolkata',
		
		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/sustainabilityKPI/sustainabilityKPIKolkata.html',
			}
		}
	})
	
	.state('airQualityManagement', {
		url : '/airQualityManagement',

		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityAirQualityManagement/airQuality.html',
			}
		}
	})
	
	
	.state('lightManagement', {
		url : '/lightManagement',

		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityEnergyManagement/lightManagement/lightManagement.html',
			}
		}
	})
	
	
	.state('carbonFootprint', {
		url : '/carbonFootprint',

		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityEnergyManagement/carbonFootprint/carbonFootprint.html',
			}
		}
	})
	
	
	.state('equipment-wisePerformance', {
		url : '/equipment-wisePerformance',

		parent: 'dashboardHome',
		views: {
			'dashboardContent@dashboardHome':{
				templateUrl : 'app/partials/dashboards/facilityEnergyManagement/equipment-wisePerformance/equipment-wisePerformance.html',
			}
		}
	})

	$urlRouterProvider
	// If the url is ever invalid, e.g. '/asdf', then redirect to '/home' state
	.otherwise('/login');
});

app.controller('appCtrl', function($scope, $location, $rootScope, $state,$http) {
	$scope.location = $location;
	
	$scope.state = $state;
});


/*app.run(function($rootScope, $state, $location, $timeout) {
    $rootScope.$on('$stateChangeSuccess', function(event, toState){

        $rootScope.showInclude = true;

        if($state.current.name === 'login') {
            $rootScope.showInclude = false;
        }
    });
})
*/