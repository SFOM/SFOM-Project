app.controller('sustainabilityKPICtrl', function($scope) {



});


/*app.controller('tataSustainCtrl', function($scope, $state, $location, tataSustainabiltyService) {
	tataSustainabiltyService.gettataSustainabiltyData().then(function(result) {*/

app.controller('tataSustainCtrl', function($scope) {
	/*	tataSustainabiltyService.gettataSustainabiltyData().then(function(result) {*/
			var result=new Array();
			result[0]=["Target","Actual"];										
			$scope.columnLabels = result[0];
			$scope.tableData2 = [["Achieved PUE (Power Utilization Efficiency)", "1.65",""],["Renewable Procurement Energy", "20%",""],["Zero Solid Disposal to Landfill","< 5%",""],["Electricity Consumptiom (Kwh/FTE/Monthly)","186 kWh",""],
			                     ["Carbon FootPrint (tCO2/FTE/Annum)", "1.82",""], ["Fresh Water Consumption (Litres/FTE/Month)", "1077 ltrs",""], ["Reused Water (KL)", "107130",""], ["Waste Generated (Kg/FTE/Annum)", "18 kg",""], 
			                     ["Paper Consumption (Reams/1000FTE/Month)", "50",""]];
		/*});*/

			var date = new Date();
			 $scope.month = ['Jan', 'Feb', 'Mar', 'Apr', 'May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
			 $scope.year = ['2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020'];
			 $scope.selectedMonth = $scope.month[date.getMonth()];
			
			 $scope.selectedYear =$scope.year[5] ;
			 
						//  $scope.mon = month[date.getMonth()];
						  // $scope.year = date.getFullYear();


	});



app.controller('powerUtilizationEfficiencyBarChartCntr', function($scope) {

	drawChart();

	function drawChart() {
		
		var data6 = google.visualization.arrayToDataTable([
		                                                   ['Year', 'Target', 'Actual'],
		                                                   ['2016', 1.65, null],
		                                                   ['2015', 1.81, 1.81],
		                                                   ['2014', 2.16, 2.16]]);	
	      	      
		var options6 = {
				title : '',
				 is3D:true,
				 legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
				hAxis : {
					title : 'Year',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',
					  
				chartArea:{                   
		        	width:'40%',height:'55%'
		        		}
			};

		var chart = new google.visualization.ColumnChart(document
				.getElementById('powerUtilizationEfficiencyBarChart'));
		chart.draw(data6, options6);
	}

});


app.controller('renewableProcurementEnergyBarChartCntr', function($scope) {

	drawChart();

	function drawChart() {
		
		var data6 = google.visualization.arrayToDataTable([
		                                                   ['Year', 'Target', 'Actual'],
		                                                   ['2016', 2.40, null],
		                                                   ['2015', 2.27, 2.28],
		                                                   ['2014', 2.16, 2.16]]);	
	      	      
		var options6 = {
				title : '',
				 is3D:true,
				 legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
				hAxis : {
					title : 'Year',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : '%',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',
					  
				chartArea:{                   
		        	width:'40%',height:'55%'
		        		}
			};

		var chart = new google.visualization.ColumnChart(document
				.getElementById('renewableProcurementEnergyBarChart'));
		chart.draw(data6, options6);
	}

});


app.controller('rainWaterHarvestingBarChartCntr', function($scope) {

	drawChart();

	function drawChart() {
		
		var data6 = google.visualization.arrayToDataTable([
		                                                   ['Year', 'Target', 'Actual'],
		                                                   ['2016', 266458, null],
		                                                   ['2015', 217296, 217396],
		                                                   ['2014', 148469, 148769]]);	
	      	      
		var options6 = {
				title : '',
				 is3D:true,
				 legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
				hAxis : {
					title : 'Year',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',
					  
				chartArea:{                   
		        	width:'40%',height:'55%'
		        		}
			};

		var chart = new google.visualization.ColumnChart(document
				.getElementById('rainWaterHarvestingBarChart'));
		chart.draw(data6, options6);
	}

});


app.controller('electricityConsumptionBarChartCntr', function($scope) {

	drawChart();

	function drawChart() {
		
		var data6 = google.visualization.arrayToDataTable([
		                                                   ['Year', 'Target', 'Actual'],
		                                                   ['2016', 186, null],
		                                                   ['2015', 196, 196],
		                                                   ['2014', 216, 216]]);	
	      	      
		var options6 = {
				title : '',
				 is3D:true,
				 legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
				hAxis : {
					title : 'Year',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',
					  
				chartArea:{                   
		        	width:'40%',height:'55%'
		        		}
			};

		var chart = new google.visualization.ColumnChart(document
				.getElementById('electricityConsumptionBarChart'));
		chart.draw(data6, options6);
	}

});


app.controller('carbonFootprintBarChartCntr', function($scope) {

	drawChart();

	function drawChart() {
		
		var data6 = google.visualization.arrayToDataTable([
		                                                   ['Year', 'Target', 'Actual'],
		                                                   ['2016', 1.82, null],
		                                                   ['2015', 1.97, 1.97],
		                                                   ['2014', 1.99, 1.99]]);	
	      	      
		var options6 = {
				title : '',
				 is3D:true,
				 legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
				hAxis : {
					title : 'Year',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',
					  
				chartArea:{                   
		        	width:'40%',height:'55%'
		        		}
			};

		var chart = new google.visualization.ColumnChart(document
				.getElementById('carbonFootprintBarChart'));
		chart.draw(data6, options6);
	}

});


app.controller('freshWaterConsumptionBarChartCntr', function($scope) {

	drawChart();

	function drawChart() {
		
		var data6 = google.visualization.arrayToDataTable([
		                                                   ['Year', 'Target', 'Actual'],
		                                                   ['2016', 1077, null],
		                                                   ['2015', 1062, 1072],
		                                                   ['2014', 1061, 1076]]);	
	      	      
		var options6 = {
				title : '',
				 is3D:true,
				 legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
				hAxis : {
					title : 'Year',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',
					  
				chartArea:{                   
		        	width:'40%',height:'55%'
		        		}
			};

		var chart = new google.visualization.ColumnChart(document
				.getElementById('freshWaterConsumptionBarChart'));
		chart.draw(data6, options6);
	}

});


app.controller('reusedWaterBarChartCntr', function($scope) {

	drawChart();

	function drawChart() {
		
		var data6 = google.visualization.arrayToDataTable([
		                                                   ['Year', 'Target', 'Actual'],
		                                                   ['2016', 1071130, null],
		                                                   ['2015', 805051, 805051],
		                                                   ['2014', 610557, 610557]]);	
	      	      
		var options6 = {
				title : '',
				 is3D:true,
				 legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
				hAxis : {
					title : 'Year',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',
					  
				chartArea:{                   
		        	width:'40%',height:'55%'
		        		}
			};

		var chart = new google.visualization.ColumnChart(document
				.getElementById('reusedWaterBarChart'));
		chart.draw(data6, options6);
	}

});


app.controller('wasteGeneratedBarChartCntr', function($scope) {

	drawChart();

	function drawChart() {
		
		var data6 = google.visualization.arrayToDataTable([
		                                                   ['Year', 'Target', 'Actual'],
		                                                   ['2016', 15.2, null],
		                                                   ['2015', 17.8, 17.7],
		                                                   ['2014', 18.2, 18.2]]);	
	      	      
		var options6 = {
				title : '',
				 is3D:true,
				 legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
				hAxis : {
					title : 'Year',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',
					  
				chartArea:{                   
		        	width:'40%',height:'55%'
		        		}
			};

		var chart = new google.visualization.ColumnChart(document
				.getElementById('wasteGeneratedBarChart'));
		chart.draw(data6, options6);
	}

});


app.controller('paperConsumptionBarChartCntr', function($scope) {

	drawChart();

	function drawChart() {
		
		var data6 = google.visualization.arrayToDataTable([
		                                                   ['Year', 'Target', 'Actual'],
		                                                   ['2016', 50, null],
		                                                   ['2015', 51, 51],
		                                                   ['2014', 54, 55]]);	
	      	      
		var options6 = {
				title : '',
				 is3D:true,
				 legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
				hAxis : {
					title : 'Year',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',
					  
				chartArea:{                   
		        	width:'40%',height:'55%'
		        		}
			};

		var chart = new google.visualization.ColumnChart(document
				.getElementById('paperConsumptionBarChart'));
		chart.draw(data6, options6);
	}

});



app.controller('electricityConsumptionBarChartKolCntr', function($scope) {

	drawChart();

	function drawChart() {
		
		var data6 = google.visualization.arrayToDataTable([
		                                                   ['Year', 'Target', 'Actual'],
		                                                   ['2016', 186, null],
		                                                   ['2015', 210, 248],
		                                                   ['2014', 205, 234]]);	
	      	      
		var options6 = {
				title : '',
				 is3D:true,
				 legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
				hAxis : {
					title : 'Year',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',
					  
				chartArea:{                   
		        	width:'40%',height:'55%'
		        		}
			};

		var chart = new google.visualization.ColumnChart(document
				.getElementById('electricityConsumptionBarChart'));
		chart.draw(data6, options6);
	}

});


app.controller('freshWaterConsumptionBarChartKolCntr', function($scope) {

	drawChart();

	function drawChart() {
		
		var data6 = google.visualization.arrayToDataTable([
		                                                   ['Year', 'Target', 'Actual'],
		                                                   ['2016', 1077, null],
		                                                   ['2015', 1167, 1235],
		                                                   ['2014', 1142, 1187]]);	
	      	      
		var options6 = {
				title : '',
				 is3D:true,
				 legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
				hAxis : {
					title : 'Year',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',
					  
				chartArea:{                   
		        	width:'40%',height:'55%'
		        		}
			};

		var chart = new google.visualization.ColumnChart(document
				.getElementById('freshWaterConsumptionBarChart'));
		chart.draw(data6, options6);
	}

});


app.controller('carbonFootprintBarChartKolCntr', function($scope) {

	drawChart();

	function drawChart() {
		
		var data6 = google.visualization.arrayToDataTable([
		                                                   ['Year', 'Target', 'Actual'],
		                                                   ['2016', 1.92, null],
		                                                   ['2015', 1.98, 1.99],
		                                                   ['2014', 1.94, 1.96]]);	
	      	      
		var options6 = {
				title : '',
				 is3D:true,
				 legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
				hAxis : {
					title : 'Year',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',
					  
				chartArea:{                   
		        	width:'40%',height:'55%'
		        		}
			};

		var chart = new google.visualization.ColumnChart(document
				.getElementById('carbonFootprintBarChart'));
		chart.draw(data6, options6);
	}

});