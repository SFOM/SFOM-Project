app.controller('fireCtrl',function($scope, $state, $location, fwdFloorService){
	

});

app.controller('fireTypeDonutChartCntr', function($scope) {

	drawChart();

	function drawChart() {
		var data1 = google.visualization.arrayToDataTable([
				[ 'Fire Type', 'Count' ], [ 'Type E', 4 ], [ 'Type A', 2 ],
				[ 'Type B', 1 ], [ 'Type C', 0  ] ]);

		var options1 = {
			/*legend : 'none',*/
			/*legend : {position: 'left', textStyle: { color: 'white', fontSize: 10}},*/
			legend : {position: 'bottom', textStyle: { color: 'white', fontSize: 12}},
			//pieSliceText : 'label',
			pieHole : 0.3,
			backgroundColor : '#262626',
			is3D : true,

			chartArea : {
				width : '90%',
				height : '75%'
			},
			pieSliceText: 'label',
	         /* slices: {  3: {offset: 0.2},
	                     1: {offset: 0.1},
	                     5: {offset: 0.2},
	                   
	          }*/
		};

		var chart = new google.visualization.PieChart(document
				.getElementById('fireTypedonutchart'));
		chart.draw(data1, options1);
	}

});





app.controller('InvOffvsReptSubBarChartCntr', function($scope) {

	drawChart();

	function drawChart() {
		var data4 = google.visualization.arrayToDataTable([
                            ['Investigating Officer', 'Submitted', 'Pending'],
                            ['Admin01', 2,1],
                            ['Admin02', 3,1]]);		
		var options4 = {
				title : '',
				 is3D:true,
				/*legend : {
					position : 'none'
					
				},*/
				 legend : {position: 'bottom', textStyle: { color: 'white'}},
				hAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',
				isStacked: true,		  
				chartArea:{                   //top: 10,left:65,
		        	width:'70%',height:'65%'
		        		}
			};

		var chart = new google.visualization.BarChart(document
				.getElementById('InvOffvsReptSubBarChart'));
		chart.draw(data4, options4);
	}

});




app.controller('fireTableCtrl', function($scope, $filter, fireTableService) {
		
	$scope.FireAllTableData = fireTableService.getAllFireReading();
	
	console.log($scope.FireAllTableData);
	
	$scope.allFireOptions = { data: 'FireAllTableData', enableSorting: true,
            columnDefs: [
                     	 {field:'incdentId', displayName:'Incident ID', headerCellClass:'ui-grid-header-cell-blue', enableSorting: true},	
                         {field:'summary', displayName:'Summary', headerCellClass:'ui-grid-header-cell-blue', enableSorting: true}, 
                         {field:'location', displayName:'Location', headerCellClass:'ui-grid-header-cell-blue', enableSorting: true},  
            			 {field:'date', displayName:'Date/Time', headerCellClass:'ui-grid-header-cell-blue', enableSorting: true},
            		   	 {field:'fireType', displayName:'Type of Fire', headerCellClass:'ui-grid-header-cell-blue'},
            			 {field:'invstOfficer', displayName:'Investigating Officer', headerCellClass:'ui-grid-header-cell-blue', enableSorting: true},
            			 {field:'extngUsed', displayName:'Extinguisher Used', headerCellClass:'ui-grid-header-cell-blue', enableSorting: true},
            			 {field:'reportSub', displayName:'Report Submitted', headerCellClass:'ui-grid-header-cell-blue', enableSorting: true},
            			 {field:'viewReport', displayName:'View Report', cellTemplate: $.get('app/partials/dashboards/facilityFireManagement/switchReport.html'),
         	 				headerCellClass:'ui-grid-header-cell-blue', enableSorting: false}, 
                        ],

                         
    };
	
});



app.controller('popupFireReportCtrl', function($scope, $filter, $uibModal, $http, fireTableService) {

	$scope.FireReport = fireTableService.getAllFireReading();
	console.log($scope.FireReport);
	$scope.popUpFireReport = function(viewReport) {
		
		console.log(viewReport)
		
		if(viewReport=="Fr001")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityFireManagement/fireIncidentOne.html',
				controller : 'viewFireReportCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}	
		
		if(viewReport=="Fr003")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityFireManagement/fireIncidentTwo.html',
				controller : 'viewFireReportCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}
		
		if(viewReport=="Fr002")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityFireManagement/fireIncidentOne.html',
				controller : 'viewFireReportCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}
		if(viewReport=="Fr004")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityFireManagement/fireIncidentOne.html',
				controller : 'viewFireReportCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}
		if(viewReport=="Fr005")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityFireManagement/fireIncidentOne.html',
				controller : 'viewFireReportCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}
		if(viewReport=="Fr006")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityFireManagement/fireIncidentTwo.html',
				controller : 'viewFireReportCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}
		if(viewReport=="Fr007")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityFireManagement/fireIncidentOne.html',
				controller : 'viewFireReportCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}
		

		
	}
});
	