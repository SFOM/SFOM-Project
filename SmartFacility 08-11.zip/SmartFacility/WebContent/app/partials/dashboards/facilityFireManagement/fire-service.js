app.service('fireTableService', function($http) {
	
		
		var fireAllTableReading =[
		                           {
		                        	   "incdentId": "Fr001",
		                        		"summary": "Short Circuit",
		                        		"location": "S2-2F",
		                        		"date": "14-09-2016",
		                        		"fireType": "Type E",
		                        		"invstOfficer": "Admin01",
		                        		"extngUsed": "Co2",
		                        		"reportSub":  "Yes",
		                        		"viewReport": "Fr001"
		                        			
		                           },
		                           
		                           {
		                        	   "incdentId": "Fr002",
		                        		"summary": "Papers Catches Fire",
		                        		"location": "Canteen",
		                        		"date": "11-10-2016",
		                        		"fireType": "Type A",
		                        		"invstOfficer": "Admin01",
		                        		"extngUsed": "DCP",
		                        		"reportSub":  "Yes",
		                        		"viewReport": "Fr002"
		                           },
		                           
		                           {
		                        	   "incdentId": "Fr003",
		                        		"summary": "Petrol Tank Leakage",
		                        		"location": "Parking",
		                        		"date": "18-08-2016",
		                        		"fireType": "Type B",
		                        		"invstOfficer": "Admin02",
		                        		"extngUsed": "Foam",
		                        		"reportSub":  "No",
		                        		"viewReport": "Fr003"
		                        		
		                           },
		                           
		                           {
		                        	   "incdentId": "Fr004",
		                        		"summary": "Faulty Protection Devices",
		                        		"location": "S2-5F",
		                        		"date": "28-05-2016",
		                        		"fireType": "Type E",
		                        		"invstOfficer": "Admin02",
		                        		"extngUsed": "Co2",
		                        		"reportSub":  "Yes",
		                        		"viewReport": "Fr004"
		                           },
		                           
		                           {
		                        	   "incdentId": "Fr005",
		                        		"summary": "Short Circuit",
		                        		"location": "S2-GF",
		                        		"date": "09-01-2016",
		                        		"fireType": "Type E",
		                        		"invstOfficer": "Admin02",
		                        		"extngUsed": "DCP",
		                        		"reportSub":  "Yes",
		                        		"viewReport": "Fr005"
		                           },
		                           
		                           {
		                        	   "incdentId": "Fr006",
		                        		"summary": "Clothes Catch Fire",
		                        		"location": "Canteen",
		                        		"date": "17-02-2016",
		                        		"fireType": "Type A",
		                        		"invstOfficer": "Admin01",
		                        		"extngUsed": "Water",
		                        		"reportSub":  "No",
		                        		"viewReport": "Fr006"
		                           },
		                           
		                           {
		                        	   "incdentId": "Fr007",
		                        		"summary": "Wet Electric Devices",
		                        		"location": "S2-3F",
		                        		"date": "04-07-2016",
		                        		"fireType": "Type E",
		                        		"invstOfficer": "Admin02",
		                        		"extngUsed": "Co2",
		                        		"reportSub":  "Yes",
		                        		"viewReport": "Fr007"
		                           }
		                          		                      	                           
   	                             ];
		 
		this.getAllFireReading = function() {
			return fireAllTableReading;
		};
});



