app.controller('viewFireReportCtrls', function($scope, $uibModalInstance) {
console.log("hello");
	$scope.close = function () {
		$uibModalInstance.dismiss('close');
	};
	
	
	$scope.title= 'Fire Incident Report';
});

