
//Controller for AQI

app.controller('AQICtrl', function($scope, $filter,airQualityService) {
	
//	waterGasUsageService.getLastWeekWaterData().then(function (result) {
	var result = angular.copy(airQualityService.airQualityData);
	var graphData = [];
	for(var i=0;i<result.length;i++){
		if(i!=0)
		graphData.push(new Array(parseInt(result[i][0]),parseInt(result[i][1])));
		else
			graphData.push(new Array(result[i][0],result[i][1]));
			 
	}
	console.log(graphData);
		
		var data = new google.visualization.arrayToDataTable(graphData);
		var options = {
	    		title: '', //Last 7 Days
	    		hAxis : {
	    			//title : 'Days of week',
	    			//format: 'MMM dd', //'EEE, MMM dd',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'                     
	    			},
	    			gridlines: {
		                 color: 'grey'
		             },
	    		},
	    		vAxis : {
	    			title : 'Index',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'
	    			},
	    			gridlines: {
		                 color: 'transparent'
		             },
	    		},
	    		 bar: { gap: 0 },
	    		 
	    		colors: [ '#0066CC', '#fba651', '#336600', '#B00' ], // '#4566A3', '#DC3912', '#F98A1A', 
	    		backgroundColor : '#262626',
	    		legend: {position: 'none'},
//	    		seriesType: 'bars',
//	    		isStacked: true,
//	    		chartArea: {left: 50, width:'58%'},
	    		chartArea:{    
	    			left: "12%",
	                top: "6%",
	                bottom:"20%",
	                height: "35%",
	                width: "85%" },
	    };
		
		
	    var chart = {};
	    
	    chart.data = data;
	    chart.options = options;
	    $scope.chart = chart;

//	});
});

//PMI2.5
app.controller('pmiTwoPointFiveCtrl', function($scope, $filter,airQualityService) {
	
//	waterGasUsageService.getLastWeekWaterData().then(function (result) {
	var result = angular.copy(airQualityService.airQualityData);
	var graphData = [];
	for(var i=0;i<result.length;i++){
		if(i!=0)
		graphData.push(new Array(parseInt(result[i][0]),parseInt(result[i][4])));
		else
			graphData.push(new Array(result[i][0],result[i][4]));
			 
	}
	console.log(graphData);
		
		var data = new google.visualization.arrayToDataTable(graphData);
		var options = {
	    		title: '', //Last 7 Days
	    		hAxis : {
	    			//title : 'Days of week',
	    			//format: 'MMM dd', //'EEE, MMM dd',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'                     
	    			},
	    			gridlines: {
		                 color: 'grey'
		             },
	    		},
	    		vAxis : {
	    			title : '(ug/m3)',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'
	    			},
	    			gridlines: {
		                 color: 'transparent'
		             },
	    		},
	    		 bar: { gap: 0 },
	    		 
	    		colors: [  '#fba651', '#336600', '#B00' ], // '#4566A3', '#DC3912', '#F98A1A', 
	    		backgroundColor : '#262626',
	    		legend: {position: 'none'},
//	    		seriesType: 'bars',
//	    		isStacked: true,
//	    		chartArea: {left: 50, width:'58%'},
	    		chartArea:{    
	    			left: "12%",
	                top: "6%",
	                bottom:"20%",
	                height: "35%",
	                width: "85%" },
	    };
		
	    var chart = {};
	    
	    chart.data = data;
	    chart.options = options;
	    $scope.chart = chart;

//	});
});

//PMI10
app.controller('pmiTenCtrl', function($scope, $filter,airQualityService) {
	
//	waterGasUsageService.getLastWeekWaterData().then(function (result) {
	var result = angular.copy(airQualityService.airQualityData);
	var graphData = [];
	for(var i=0;i<result.length;i++){
		if(i!=0)
		graphData.push(new Array(parseInt(result[i][0]),parseInt(result[i][3])));
		else
			graphData.push(new Array(result[i][0],result[i][3]));
			 
	}
	console.log(graphData);
		
		var data = new google.visualization.arrayToDataTable(graphData);
		var options = {
	    		title: '', //Last 7 Days
	    		hAxis : {
	    			//title : 'Days of week',
	    			//format: 'MMM dd', //'EEE, MMM dd',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'                     
	    			},
	    			gridlines: {
		                 color: 'grey'
		             },
	    		},
	    		vAxis : {
	    			title : '(ug/m3)',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'
	    			},
	    			gridlines: {
		                 color: 'transparent'
		             },
	    		},
	    		 bar: { gap: 0 },
	    		 
	    		colors: [  '#336600', '#B00' ], // '#4566A3', '#DC3912', '#F98A1A', 
	    		backgroundColor : '#262626',
	    		legend: {position: 'none'},
//	    		seriesType: 'bars',
//	    		isStacked: true,
//	    		chartArea: {left: 50, width:'58%'},
	    		chartArea:{    
	    			left: "12%",
	                top: "6%",
	                bottom:"20%",
	                height: "35%",
	                width: "85%" },
	    };
		
	    var chart = {};
	    
	    chart.data = data;
	    chart.options = options;
	    $scope.chart = chart;

//	});
});

// Temperature

app.controller('TemperatureCtrl', function($scope, $filter,airQualityService) {
	
//	waterGasUsageService.getLastWeekWaterData().then(function (result) {
	var result = angular.copy(airQualityService.airQualityData);
	var graphData = [];
	for(var i=0;i<result.length;i++){
		if(i!=0)
		graphData.push(new Array(parseInt(result[i][0]),parseInt(result[i][2])));
		else
			graphData.push(new Array(result[i][0],result[i][2]));
			 
	}
	console.log(graphData);
		
		var data = new google.visualization.arrayToDataTable(graphData);
		var options = {
	    		title: '', //Last 7 Days
	    		hAxis : {
	    			//title : 'Days of week',
	    			//format: 'MMM dd', //'EEE, MMM dd',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'                     
	    			},
	    			gridlines: {
		                 color: 'grey'
		             },
	    		},
	    		vAxis : {
	    			title : '\xB0C',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'
	    			},
	    			gridlines: {
		                 color: 'transparent'
		             },
	    		},
	    		 bar: { gap: 0 },
	    		 
	    		colors: [  '#B00' ], // '#4566A3', '#DC3912', '#F98A1A', 
	    		backgroundColor : '#262626',
	    		legend: {position: 'none'},
//	    		seriesType: 'bars',
//	    		isStacked: true,
//	    		chartArea: {left: 50, width:'58%'},
	    		chartArea:{    
	    			left: "12%",
	                top: "6%",
	                bottom:"20%",
	                height: "35%",
	                width: "85%" },
	    };
		
	    var chart = {};
	    
	    chart.data = data;
	    chart.options = options;
	    $scope.chart = chart;

//	});
});
//Co2

app.controller('COtwoCtrl', function($scope, $filter,airQualityService) {
	console.log("InC02");
//	waterGasUsageService.getLastWeekWaterData().then(function (result) {
	var result = angular.copy(airQualityService.airQualityData);
	var graphData = [];
	for(var i=0;i<result.length;i++){
		if(i!=0)
		graphData.push(new Array(parseInt(result[i][0]),parseInt(result[i][6])));
		else
			graphData.push(new Array(result[i][0],result[i][6]));
			 
	}
	console.log(graphData);
		
		var data = new google.visualization.arrayToDataTable(graphData);
		var options = {
	    		title: '', //Last 7 Days
	    		hAxis : {
	    			title : '',
	    			//format: 'MMM dd', //'EEE, MMM dd',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'                     
	    			},
	    			gridlines: {
		                 color: 'grey'
		             },
	    		},
	    		vAxis : {
	    			title : 'PPM',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'
	    			},
	    			gridlines: {
		                 color: 'transparent'
		             },
	    		},
	    		 bar: { gap: 0 },
	    		 
	    		colors: [ '#11b6dc', '#fba651', '#336600', '#B00' ], // '#4566A3', '#DC3912', '#F98A1A', 
	    		backgroundColor : '#262626',
	    		legend: {position: 'none'},
//	    		seriesType: 'bars',
//	    		isStacked: true,
//	    		chartArea: {left: 50, width:'58%'},
	    		chartArea:{    
	    			left: "12%",
	                top: "6%",
	                bottom:"20%",
	                height: "35%",
	                width: "85%" },
	    };
		
	    var chart = {};
	    
	    chart.data = data;
	    chart.options = options;
	    $scope.chart = chart;

//	});
});
//Co

app.controller('COCtrl', function($scope, $filter,airQualityService) {
	
//	waterGasUsageService.getLastWeekWaterData().then(function (result) {
	var result = angular.copy(airQualityService.airQualityData);
	var graphData = [];
	for(var i=0;i<result.length;i++){
		if(i!=0)
		graphData.push(new Array(parseInt(result[i][0]),parseInt(result[i][7])));
		else
			graphData.push(new Array(result[i][0],result[i][7]));
			 
	}
	console.log(graphData);
		
		var data = new google.visualization.arrayToDataTable(graphData);
		var options = {
	    		title: '', //Last 7 Days
	    		hAxis : {
	    			//title : 'Days of week',
	    			//format: 'MMM dd', //'EEE, MMM dd',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'                     
	    			},
	    			gridlines: {
		                 color: 'grey'
		             },
	    		},
	    		vAxis : {
	    			title : 'PPM',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'
	    			},
	    			gridlines: {
		                 color: 'transparent'
		             },
	    		},
	    		 bar: { gap: 0 },
	    		 
	    		colors: [ '#800080', '#fba651', '#336600', '#B00' ], // '#4566A3', '#DC3912', '#F98A1A', 
	    		backgroundColor : '#262626',
	    		legend: {position: 'none'},
//	    		seriesType: 'bars',
//	    		isStacked: true,
//	    		chartArea: {left: 50, width:'58%'},
	    		chartArea:{    
	    			left: "12%",
	                top: "6%",
	                bottom:"20%",
	                height: "35%",
	                width: "85%" },
	    };
	    var chart = {};
	    
	    chart.data = data;
	    chart.options = options;
	    $scope.chart = chart;

//	});
});
//Humidity

app.controller('HumidityCtrl', function($scope, $filter,airQualityService) {
	
//	waterGasUsageService.getLastWeekWaterData().then(function (result) {
	var result = angular.copy(airQualityService.airQualityData);
	var graphData = [];
	for(var i=0;i<result.length;i++){
		if(i!=0)
		graphData.push(new Array(parseInt(result[i][0]),parseInt(result[i][5])));
		else
			graphData.push(new Array(result[i][0],result[i][5]));
			 
	}
	console.log(graphData);
		
		var data = new google.visualization.arrayToDataTable(graphData);
		var options = {
	    		title: '', //Last 7 Days
	    		hAxis : {
	    			title : 'Days of week',
	    			//format: 'MMM dd', //'EEE, MMM dd',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'                     
	    			},
	    			gridlines: {
		                 color: 'grey'
		             },
	    		},
	    		vAxis : {
	    			title : 'RH',
	    			
	    			textStyle : {
	    				color : '#fff',
	    				//size: '6px'
	    			},
	    			titleTextStyle : {
	    				color : '#fff',
	    				//	size: '6px'
	    			},
	    			gridlines: {
		                 color: 'transparent'
		             },
	    		},
	    		 bar: { gap: 0 },
	    		 
	    		colors: [ '#dc8e11' ], // '#4566A3', '#DC3912', '#F98A1A', 
	    		backgroundColor : '#262626',
	    		legend: {position: 'none'},
//	    		seriesType: 'bars',
//	    		isStacked: true,
//	    		chartArea: {left: 50, width:'58%'},
	    		chartArea:{    
	    			left: "12%",
	                top: "6%",
	                bottom:"35%",
	                height: "35%",
	                width: "85%" },
	    };
		
	    var chart = {};
	    
	    chart.data = data;
	    chart.options = options;
	    $scope.chart = chart;

//	});
});



/*app.controller('togglecntr', function($scope) {*/
	
	function show()
	 {
	       var div1 = document.getElementById("content");
	
	    div1.style.display = "block";
	
	 }
	
	function hide()
	 {
	       var div2 = document.getElementById("content");
	
	    div2.style.display = "none";
	
	 }
	
/*});*/
	
	

