app.controller('waterMgmtCtrl', function($scope, $filter, selLocationService, waterManagementService) {

	var generateChartWeekly = function () {


	var result = angular.copy(waterManagementService.LastWeekWaterData);

	result.splice(0, 1);
	var today = new Date();
	var dayOfWeek = today.getDay();  //Monday = 1
	dayOfWeek = dayOfWeek - 1; // Exclude today, show data starting from previous day
	// extract data from result
	// if dayOfWeek = 1 start with 0 th elmt in result array
	// if dayOfWeek = 2 start with 1
	// if dayOfWeek = 3 start with 2 
	// if dayOfWeek = 4 start with 3 
	// if dayOfWeek = 5 start with 4
	// if dayOfWeek = 6 start with 5 
	// if dayOfWeek = 0 start with 6 
	var lastWeekWaterData = new Array();
	var iStart = dayOfWeek >= 1 ? dayOfWeek - 1: 6;
	var newDate = new Date(today);
	newDate.setDate(today.getDate() - 1);

	for(var count=0; count<7; count++){
		// reducing 10% of drinking water from the total

		//	var totalIntake = parseFloat(result[iStart][1]) + parseFloat(result[iStart][2]) - 0.1*parseFloat(result[iStart][1]);

		lastWeekWaterData.push( new Array(angular.copy($filter('date')(newDate,'MMM dd')), 
		result[iStart][1], result[iStart][2], result[iStart][3], result[iStart][4] , result[iStart][5]));
		iStart = iStart == 6 ? 0 : iStart+1;
		newDate.setDate(newDate.getDate() - 1);
	}

	lastWeekWaterData = $filter('reverse')(lastWeekWaterData);
	//lastWeekWaterData.splice(0, 0, ['Date', 'Drinking Water(tonnes)', 'Water for Domestic Purpose(tonnes)' ]);
	lastWeekWaterData.splice(0, 0, ['Date', 'Drinking Water(klitres)' ,'Domestic Usage(klitres)','Total Intake Water(klitres)',
    'Waste Water (klitres)', 'Treated Water (klitres)']);
    console.log(lastWeekWaterData);

	var data = new google.visualization.arrayToDataTable(lastWeekWaterData);
	var options = {
			title: '', //Last 7 Days
			hAxis : {
				title : 'Days of week',
				//format: 'MMM dd', //'EEE, MMM dd',
				textStyle : {
					color : '#fff'
				},
				titleTextStyle : {
					color : '#fff'                     
				},
			},
			vAxis : {
				title : 'klitres ',
				textStyle : {
					color : '#fff'
				},
				titleTextStyle : {
					color : '#fff'
				},
			},
			colors: [ '#0066CC', '#fba651', '#336600', '#B00' , '#9ACD32'], // ,'#4566A3', '#DC3912', '#F98A1A', 
			//colors: [ '#33FFD4', '#FFCE33', '#B00' ], // '#4566A3', '#DC3912', '#F98A1A', '#d63303' 
			backgroundColor : '#262626',
			legend: {position: 'bottom' , textStyle : {
				color : '#fff',
				fontSize: 12
			},},
//			seriesType: 'bars',
//			isStacked: true,
//			chartArea: {left: 50, width:'58%'},
			chartArea:{ backgroundColor : '#262626', top: 15, width:'90%',height:'68%' }
	};

	var chart = {};

	chart.data = data;
	chart.options = options;
	$scope.chart = chart;

//	});
}


/**
 * Controller for Water Management for Last Month  
 **/


//app.controller('waterMgmtLastMonthCtrl', function($scope, $filter, selLocationService,waterManagementService) {
	var generateChartMonthly = function () {
	var result = angular.copy(waterManagementService.lastMonthWaterData);
	result.splice(0, 1);
	var today = new Date();
	var dayOfWeek = today.getDay();  //Monday = 1
	dayOfWeek = dayOfWeek - 1; // Exclude today, show data starting from previous day
	// extract data from result
	// if dayOfWeek = 1 start with 0 th elmt in result array
	// if dayOfWeek = 2 start with 1
	// if dayOfWeek = 3 start with 2 
	// if dayOfWeek = 4 start with 3 
	// if dayOfWeek = 5 start with 4
	// if dayOfWeek = 6 start with 5 
	// if dayOfWeek = 0 start with 6 
	var lastWeekWaterData = new Array();
	var iStart = dayOfWeek >= 1 ? dayOfWeek - 1: 6;
	var newDate = new Date(today);
	newDate.setDate(today.getDate() - 1);

	for(var count=0; count<31; count++){
		lastWeekWaterData.push( new Array(angular.copy($filter('date')(newDate,'dd')), 
				result[iStart][1], result[iStart][2], result[iStart][3], result[iStart][4] , result[iStart][5]));
		iStart = iStart == 30 ? 0 : iStart+1;
		newDate.setDate(newDate.getDate() - 1);
	}
	console.log(lastWeekWaterData);
	lastWeekWaterData = $filter('reverse')(lastWeekWaterData);
	lastWeekWaterData.splice(0, 0, ['Date', 'Drinking Water(klitres)' ,'Domestic Usage(klitres)','Total Intake Water(klitres)',
    'Waste Water(klitres)', 'Treated Water(klitres)']);
//	console.log(lastWeekWaterData);

	var data = new google.visualization.arrayToDataTable(lastWeekWaterData);
	var options = {
			title: '', //Last 7 Days
			hAxis : {
				title : 'Days of month',
				//format: 'MMM dd', //'EEE, MMM dd',
				textStyle : {
					color : '#fff'
				},
				titleTextStyle : {
					color : '#fff'                     
				},
			},
			vAxis : {
				title : 'klitres ',
				textStyle : {
					color : '#fff',
					fontSize: 14 
				},
				titleTextStyle : {
					color : '#fff',
					fontSize: 14
				},
			},
			colors: [ '#0066CC', '#fba651', '#336600', '#B00' , '#9ACD32'],  // '#4566A3', '#DC3912', '#F98A1A', '#d63303' 
			backgroundColor : '#262626',
			legend: {position: 'bottom' , textStyle : {
				color : '#fff',
				fontSize: 12 
			},},
//			seriesType: 'bars',
//			isStacked: true,
//			chartArea: {left: 50, width:'58%'},
			chartArea:{ backgroundColor : '#262626', top: 15, width:'90%',height:'68%' }
	};

	var chart = {};

	chart.data = data;
	chart.options = options;
	$scope.chart = chart;
	
	}
	
	$scope.updateChart = function() {
		//console.log("Selected " + $scope.radioModel);	
		if($scope.radioModel == 'weekly'){
			generateChartWeekly();
		} else if($scope.radioModel == 'montly'){
			generateChartMonthly();
		}
	}
	
	$scope.radioModel = 'weekly';
	$scope.updateChart();
	
//	});
});

