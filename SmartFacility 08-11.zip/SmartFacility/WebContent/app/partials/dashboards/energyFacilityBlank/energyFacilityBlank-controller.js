app.controller('energyFacilityBlankCtrl', function($scope) {

	

});

