/**
 *  Created by 1252807 -> Vishwajeet Bhide 
 */

app.controller('dashHomeCtrl', function($scope, $location, $rootScope, $state) {

	$scope.location = $location;
	$scope.state = state;

});

app.controller('DashboardHomeHeadingCtrl',function($scope, $rootScope, $location) {

	$rootScope.$on('$stateChangeSuccess',function() {

		if (location.hash == '#/dashbords')
			$scope.DashboardHomeHeading = "TCS Commercial Building Facility Dashboards";
		else
			$scope.DashboardHomeHeading = "TCS Commercial Building Equipment Monitoring";

	});
});


/*app.controller('dashboardButton',function($scope, $rootScope, $location) {*/
app.controller('dashboardButton',function($scope, $rootScope, $location, $filter, $state) {

/*	$rootScope.$on('$stateChangeSuccess',function() {

		if ((location.hash == '#/energyManagement') || (location.hash == '#/waterManagement') || (location.hash == '#/bioGasGeneration')
				|| (location.hash == '#/dashboardLinks') || (location.hash == '#/equipmentAnalysis'))
			$scope.dashboardGo = "dashboardLinksFirst";
		else
			$scope.dashboardGo = "energyManagement";

	});*/
	
		
		/*$rootScope.$on('$stateChangeSuccess',function() {*/
		
/*			$scope.getLinkUrl = function(){
*/		
			/*if ((location.hash == '#/energyManagement') || (location.hash == '#/waterManagement') || (location.hash == '#/bioGasGeneration')
					|| (location.hash == '#/dashboardLinks') || (location.hash == '#/equipmentAnalysis'))
				return 'dashboardLinksFirst';*/
			/*else
				return 'energyManagement';*/
			/*if (location.hash == '#/consumption') 
				return 'energyManagement';*/
	
	     /* $scope.dashButton= "energyManagement"*/
			
	
			if ((location.hash == '#/energyManagement') || (location.hash == '#/waterManagement') || (location.hash == '#/bioGasGeneration')
					|| (location.hash == '#/dashboardLinks') || (location.hash == '#/equipmentAnalysis')){
				/*location.reload();*/
				/*$scope.dashButton = "dashboardLinksFirst";*/
				/*dashButton = "dashboardLinksFirst";*/
				$state.go('dashboardLinksFirst');
				
			}
				
				
			/*else*/
			if (location.hash == '#/consumption'){
				/*location.reload();*/
				/*dashButton= "energyManagement";*/
				$state.go('energyManagement');
				
			}
				
			
			/*console.log(dashButton);
			
			return dashButton;*/
				

		/*});*/
		 
		/*};*/
	
});






/*app.controller('selectFloorCtrl', function($scope, $state, $location,  $filter, selectFloorService, fwdFloorService, 
		dashboardHomeService, selLocationService) {*/

app.controller('selectFloorCtrl', function($scope, $state, $location,  $filter, dashboardHomeService, selLocationService) {
	
	
	
	/** Added by #246292 (Lekha) for dependent Dropdown
	 * Ref: http://devzone.co.in/simple-example-of-dependable-dropdowns-cascading-dropdowns-using-angularjs/
	 * http://www.advancesharp.com/blog/1189/angularjs-cascading-dropdown-select-with-demo
	 * **/
	$scope.locationList = dashboardHomeService.locationList;
	
	/** * Call this function on dropdown value change */
	$scope.onChangeFloor = function() {  
		//console.log($scope.selLoc + "-"+ $scope.selSubLoc + "-"+$scope.selFloor);
		selLocationService.setSelFloor($scope.selLoc, $scope.selSubLoc, $scope.selFloor)
	};

	$scope.onChangeSubLocation = function() {  
		var filteredFloor = ($filter('filter')($scope.locationList, {locId:$scope.selLoc, subLocId:$scope.selSubLoc}));
		$scope.selFloor = filteredFloor.length > 0 ? filteredFloor[0].floorId:''; 
		$scope.onChangeFloor(); // call once by default
	}
	
	$scope.onChangeLocation = function() {  
		var filteredSubLoc = ($filter('filter')($scope.locationList, {locId:$scope.selLoc}));
		$scope.selSubLoc = filteredSubLoc.length > 0 ? filteredSubLoc[0].subLocId:''; 
		$scope.onChangeSubLocation(); // call once by default
	};
	
	$scope.selLoc = $scope.locationList[0].locId;
	$scope.onChangeLocation(); // call once by default
	
	/**   *End - Lekha Change*   **/
	
	
	
});
