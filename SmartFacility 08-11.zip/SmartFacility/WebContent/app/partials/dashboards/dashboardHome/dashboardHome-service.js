/** 
 * get/set selected location details (Place, Building, Floor)
 * selLocationService: Added by #246292 (Lekha)
 */
app.service('selLocationService', function() {						
	this.selLocation;
	
    return {
        getSelFloor: function () {
            return this.selLocation;
        },
        
        setSelFloor: function(loc, subLoc, floor) {
        	this.selLocation = new Array();
        	this.selLocation[0] = loc;
        	this.selLocation[1] = subLoc;
        	this.selLocation[2] = floor;
        },
    };
});

app.service('dashboardHomeService', function() {						
	this.locationList = [
             //S2
//             { locId: '1', locDesc:'TCS Pune', subLocId:'1.2', subLocDesc:'S2', floorId:'0', floorDesc:'Ground Floor'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.2', subLocDesc:'S2', floorId:'1', floorDesc:'Floor-1'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.2', subLocDesc:'S2', floorId:'2', floorDesc:'Floor-2'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.2', subLocDesc:'S2', floorId:'3', floorDesc:'Floor-3'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.2', subLocDesc:'S2', floorId:'4', floorDesc:'Floor-4'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.2', subLocDesc:'S2', floorId:'5', floorDesc:'Floor-5'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.2', subLocDesc:'S2', floorId:'6', floorDesc:'Floor-6'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.2', subLocDesc:'S2', floorId:'7', floorDesc:'Floor-7'},
             //S1
//             { locId: '1', locDesc:'TCS Pune', subLocId:'1.1', subLocDesc:'S1', floorId:'0', floorDesc:'Ground Floor'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.1', subLocDesc:'S1', floorId:'1', floorDesc:'Floor-1'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.1', subLocDesc:'S1', floorId:'2', floorDesc:'Floor-2'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.1', subLocDesc:'S1', floorId:'3', floorDesc:'Floor-3'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.1', subLocDesc:'S1', floorId:'4', floorDesc:'Floor-4'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.1', subLocDesc:'S1', floorId:'5', floorDesc:'Floor-5'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.1', subLocDesc:'S1', floorId:'6', floorDesc:'Floor-6'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.1', subLocDesc:'S1', floorId:'7', floorDesc:'Floor-7'},
             
//             { locId: '2', locDesc:'TCS Quadra', subLocId:'2.2', subLocDesc:'ABC', floorId:'7', floorDesc:'Floor-7'},
             ];
});


/******** ADD COMMENTS *********/ 
app.service('fwdFloorService', function($http) {						
	this.selFloor;
	this.deviceCount;
    return {
        getSelFloor: function () {
//        	console.log("Getter "+this.selFloor);
            return this.selFloor;
        },
        setSelFloor: function(value) {
//        	console.log("Setter "+value);
        	this.selFloor = value;
        },
        getDeviceCount: function () {
//        	console.log("Getter2 "+this.deviceCount);
            return this.deviceCount;
        },
        setDeviceCount: function (value) {
//        	console.log("Setter2 "+value);
        	this.deviceCount = value;
        }
        
    };
});


/******** ADD COMMENTS *********/ 

// This service is commented because its no longer required

/*app.service('selectFloorService', function($http) {
   this.getCsvData= function() { 
    	var response = $http.get('/IICTestBed/rest/consumptionTcs/');
    	return( response.then( function(data) {
    	  var result = data;
//    	  console.log("result =" +result);
    	 return result.data;
    	  }, 
    	  function(data, status, headers, config) {
    		  console.log("AJAX failed to get data, status=" + status);
        	}) );
	}
    
});*/




	

