/**
 * 
 */

app.service('tataSustainabiltyService', function() {		
	
	var tataSustainabiltyData = [
	                              	{
	                              		"name" : "Achieved PUE (Power utilization energy)",
	                              		"target" :	"1.65",
	                              		" actual" : "1.02"
	                              	},
	                              
	                              {
	                            	  "name" : "Renewable Procurement Energy",
	                            	  "target" : "20%",	
	                            	  " actual" : "16.5%"
	                              },
	                              {
	                            	  "name" : "Zero solid disposla to landfill",
	                            	  "target" : "<5%",	
	                            	  " actual" : "3.12%"
	                              },
	                              {
	                            	  "name" : "Electricity Consumptiom(Kwh/FTE/Monthly)",
	                            	  "target" : "186 kwh",	
	                            	  " actual" : "152 kwh"
	                              },
	                              {
	                            	  "name" : "Carbon FootPrint (tCO2/FTE/Annum)",
	                            	  "target" : "1.82",	
	                            	  " actual" : "1.07"
	                              },
	                              
	                              {
	                            	  "name" : "Fresh Water Consumption (Litres/FTE/Month)",
	                            	  "target" : "1077 ltrs",	
	                            	  " actual" : "983 ltrs"
	                              },
	                              
	                              {
	                            	  "name" : "Reused Water (KL)",
	                            	  "target" : "107130 kltrs",	
	                            	  " actual" : "10700 kltrs"
	                              },
	                              {
	                            	  "name" : "Waste Generated (Kg/FTE/Annum)",
	                            	  "target" : "18 kg",	 
	                            	  " actual" : "22 kg"
	                              },
	                              {
	                            	  "name" : "Paper Consumption (Reams/1000FTE/Month)",
	                            	  "target" : "50",	
	                            	  " actual" : "72",
	                              }
	                              ];
	
	this.gettataSustainabiltyData = function() {
		return tataSustainabiltyData;
	};
	
	
});