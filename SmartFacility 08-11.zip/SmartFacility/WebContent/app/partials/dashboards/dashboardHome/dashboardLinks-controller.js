app.controller('dashboardLinksCtrl', function($scope) {

	/*$scope.openLink = function (varLinkName){
		//consumptionCom
		if(varLinkName == 'equipMonitoring') {
			$scope.$parent.DashboardButton = true;
			//$scope.$parent.dashboardPageTitle = "";
		}
	}*/
	/* $scope.EqMonBtFun = function ($scope, $state, $location) {
			
			console.log("Hello");
			$state.go('consumptionCom');
	 }*/

});

app.controller('EqMonBtCtrl', function($scope, $state, $location, fwdFloorService) {

	$scope.EqMonBtFun = function() {
        
		chosedFloor = fwdFloorService.getSelFloor();
		console.log(chosedFloor);
			
		
		if ((chosedFloor == 1) || (chosedFloor == 5)) {
			$state.go('consumptionCom');

		}

		if ((chosedFloor == 2) || (chosedFloor == 4) || (chosedFloor == 6)) {
			$state.go('consumptionComThird');
		}

		if ((chosedFloor == 3) || (chosedFloor == 7)) {
			$state.go('consumptionComSeven');

		}
		else
			{
			$state.go('consumptionCom');
			}

	}

});

/*
 * app.controller('dialogBoxCtrl',function($scope, $filter, $uibModal, $http,
 * ExpectedActualService)
 */
app.controller('dialogBoxCtrl', function($scope, $filter, $uibModal, $http) {

	//PopUp for Expected VS Actual Generation  
	$scope.popUpEGvsAG = function() {

		var modalInstance = $uibModal.open({
			animation : true,
			templateUrl : 'app/partials/popUp/popup1.html',
			controller : 'popUpCtrls',
			windowClass : 'modal-chart',
			scope : $scope,

		/*  resolve: {
			  data: function () { 
				return ExpectedActualService.getData().then(function (resultData) {
				//	console.log("resultData " + resultData);

					//convert Object to Array
					var outputData = [];
				  var outputData= [ [ 12, 100.567 ],
									[ 87, 107.546 ],
									[ 88, 104.589 ],
									[ 21, 107.378 ],
									[ 97, 105.600 ],
									[ 56, 109.345 ],
									 ];
					for(var i = 0; i < resultData.length; i++) {
					    var input = resultData[i];
					    outputData.push(input);
					}


					//console.log(outputData);
					return outputData;

				});

			  },
		 	  options: function () {
		 		  return options = {
		 				  	title: 'Expected VS Actual Generation',
		 		    		vAxisTitle: 'MWHr',
		 		    		hAxisTitle: 'Time Period',
		 		    		legend: {position:'bottom'},
		 		    		seriesType: 'bars',
		 		    		isStacked: false,
		 		    		chartArea: {top:15, width:'70%'}
		    		};
		 	  }
		  }*/
		});
	}

});
/*app.controller('tataSustainCtrl', function($scope, $state, $location, tataSustainabiltyService) {
	tataSustainabiltyService.gettataSustainabiltyData().then(function(result) {*/

app.controller('tataSustainCtrl', function($scope) {
	/*	tataSustainabiltyService.gettataSustainabiltyData().then(function(result) {*/
			var result=new Array();
			result[0]=["Target","Actual"];										
			$scope.columnLabels = result[0];
			$scope.tableData2 = [["Achieved PUE (Power Utilization Efficiency)", "1.65",""],["Renewable Procurement Energy", "20%",""],["Zero Solid Disposal to Landfill","< 5%",""],["Electricity Consumptiom (Kwh/FTE/Monthly)","186 kWh",""],
			                     ["Carbon FootPrint (tCO2/FTE/Annum)", "1.82",""], ["Fresh Water Consumption (Litres/FTE/Month)", "1077 ltrs",""], ["Reused Water (KL)", "107130",""], ["Waste Generated (Kg/FTE/Annum)", "18 kg",""], 
			                     ["Paper Consumption (Reams/1000FTE/Month)", "50",""]];
		/*});*/

			var date = new Date();
			 $scope.month = ['Jan', 'Feb', 'Mar', 'Apr', 'May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
			 $scope.year = ['2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020'];
			 $scope.selectedMonth = $scope.month[date.getMonth()];
			
			 $scope.selectedYear =$scope.year[5] ;
			 
						//  $scope.mon = month[date.getMonth()];
						  // $scope.year = date.getFullYear();


	});
