app.controller('dashboardLinksFirstCtrl', function($scope) {

	/*$scope.openLink = function (varLinkName){
		//consumptionCom
		if(varLinkName == 'equipMonitoring') {
			$scope.$parent.DashboardButton = true;
			//$scope.$parent.dashboardPageTitle = "";
		}
	}*/
	/* $scope.EqMonBtFun = function ($scope, $state, $location) {
			
			console.log("Hello");
			$state.go('consumptionCom');
	 }*/

});


