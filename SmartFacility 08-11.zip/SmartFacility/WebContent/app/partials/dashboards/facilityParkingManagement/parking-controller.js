

app.controller('parkingMapCtrl', function($scope, $filter, parkingService, $interval) {
	
    
	//var selectedLocation = selLocationService.getSelFloor();
	
	var d = new Date();
	var weekday = new Array(7);
	weekday[0]=  "Sunday";
	weekday[1] = "Monday";
	weekday[2] = "Tuesday";
	weekday[3] = "Wednesday";
	weekday[4] = "Thursday";
	weekday[5] = "Friday";
	weekday[6] = "Saturday";

	var n = weekday[d.getDay()];
	
	$scope.gday=n;
	
	
    var n1 = d.getDate()+"/"+(d.getMonth()+1)+"/"+d.getFullYear();
    $scope.gdate=n1; 
	
	$scope.totalParkingSlots = 18;
	$scope.noOfAvailableParkingSlots = 2;
	$scope.nameOfAvailableSlots   ;
	
	var availableParkingSlots = [4,5];

	// Function to Generate Random Parking Slots
	var generateAvailableParkingSlot =  function(){

		var availableParkingSlotsData = [];
		var availableParkingSlots1 = [];
		
		var noOfAvailableParking =  (Math.floor(Math.random() * 3)) +1 ;
		
		console.log("noOfAvailableParking = "+noOfAvailableParking);
		
		for(var i =0; i< noOfAvailableParking; i++)
			availableParkingSlotsData[i] =  Math.floor(Math.random() * 19) ;
		
		console.log("availableParkingSlotsData = "+availableParkingSlotsData);
		
		var availableParkingSlots1 = availableParkingSlotsData.filter(function(elem, index, self) {
		    return index == self.indexOf(elem);
		});
		
		console.log("availableParkingSlots1 = "+availableParkingSlots1);
		
		//$scope.noOfAvailableParkingSlots = availableParkingSlots1.length;
		parkingService.setNoOfSlots(availableParkingSlots1.length);
		console.log(parkingService.noOfslots);
		availableParkingSlots = availableParkingSlots1;
		
		console.log("availableParkingSlots = "+availableParkingSlots);
		
		//return availableParkingSlots1;
	}
		
	
	// show name of the available slots 
	var showNameOfAvailableSlots = function(availableParkingSlots){
		var nameOfAvailableSlotsData = [];
		for(var i =0 ; i < parkingService.parkingCoordinates.length ; i++){
			// take coordinates for the rect area 
			// call function to draw rect a
		
		    var count = 0;
		    for(var j = 0 ; j < availableParkingSlots.length; j++  ){

		    	if(availableParkingSlots[j] == $scope.parkingCoordinates[i].slotId){
		    		count = j;
		    		nameOfAvailableSlotsData.push($scope.parkingCoordinates[i].slotName);
		    		break;
		    	}
		    }
		    
		    parkingService.slotsName = nameOfAvailableSlotsData;
		    console.log($scope.nameOfAvailableSlots);
		    // Fill color according to the parking availablity
		
		
		
	} 
		return nameOfAvailableSlotsData;
		
		console.log("nameOfAvailableSlotsData = "+nameOfAvailableSlotsData );
	}

	
	var drawRectangle = function(ctx, isParkingAvailableColor , varCoordinates){
		ctx.beginPath();
		ctx.rect(varCoordinates.rectX, varCoordinates.rectY, varCoordinates.width, varCoordinates.height);
		//ctx.rect(x, y, width, height);
		//ctx.fillStyle = 'rgba(255,255,255,0)'; // transparent
		ctx.fillStyle = isParkingAvailableColor;
		ctx.fill();
		//ctx.lineWidth = 1;
		ctx.strokeStyle =  'rgba(0,0,0,1)';
		ctx.stroke();
	};
	

	var drawParkingMap = function(availableParkingSlots){
		
		console.log("In the function....");
		var canvas = document.getElementById('canvasParkingMap');
		var ctx = document.getElementById('canvasParkingMap').getContext('2d');
		
		$scope.parkingMapList = parkingService.parkingMapList;
		$scope.parkingCoordinates = parkingService.parkingCoordinates;

		
		var background = new Image();
		
		//Determine the parking Area
		var parkingMapLink = $scope.parkingMapList[0].floorMap;
		// change background building wise
		background.src = parkingMapLink;

		background.onload = function(){
		ctx.drawImage(background,0,0);   
		
		//var availableParkingSlots = generateAvailableParkingSlot();
		console.log("availableParkingSlots = " +availableParkingSlots);
		
		//$scope.noOfAvailableParkingSlots = availableParkingSlots.length;
		//var nameOfAvailableSlotsData = []; 
			for(var i =0 ; i < $scope.parkingCoordinates.length ; i++){
					// take coordinates for the rect area 
					// call function to draw rect a
					
				
				    var isParkingAvailableColor = 'rgba(255,0,0,0.7)' ; // default red color for unavailable slot
				    var count = 0;
				    for(var j = 0 ; j < availableParkingSlots.length; j++  ){

				    	if(availableParkingSlots[j] == $scope.parkingCoordinates[i].slotId){
				    		isParkingAvailableColor = 'rgba(0, 255, 0, 0.6)'; // change color to green for available slot
				    		count = j;
				    		//nameOfAvailableSlotsData.push($scope.parkingCoordinates[i].slotName);
				    		break;
				    	}
				    }
				    
				  //  parkingService.slotsName = nameOfAvailableSlotsData;
				    console.log($scope.nameOfAvailableSlots);
				    // Fill color according to the parking availablity
				    console.log("")
					drawRectangle(ctx, isParkingAvailableColor, $scope.parkingCoordinates[i]);
				
				
			} 
			
	
		}
	};
	
	drawParkingMap(availableParkingSlots);	
	 
	$interval(generateAvailableParkingSlot,6000);

	$scope.$watch(function(){return parkingService.noOfslots}, function()
	{
		console.log("In watch...");
		$scope.nameOfAvailableSlots = showNameOfAvailableSlots(availableParkingSlots);
		$scope.noOfAvailableParkingSlots = parkingService.getNoOfSlots();
		drawParkingMap(availableParkingSlots);
		
	});
		


});
	
	

	


