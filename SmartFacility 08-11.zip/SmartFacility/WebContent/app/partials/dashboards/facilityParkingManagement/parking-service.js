app.service('parkingService', function($http) {
	
	var parkingTableData = [
	                        {Block: '1', A: 'occupied', B: 'occupied', C: 'occupied', D: 'occupied'},
	                        {Block: '2', A: 'occupied', B: 'occupied', C: 'occupied', D: 'occupied'},
	                        {Block: '3', A: 'occupied', B: 'occupied', C: 'occupied', D: 'empty'},
	                        {Block: '4', A: 'occupied', B: 'occupied', C: 'occupied', D: 'empty'},
	                        {Block: '5', A: 'occupied', B: 'empty', C: 'occupied', D: 'empty'},
	                        {Block: '6', A: 'occupied', B: 'empty', C: 'occupied', D: 'empty'}
	                    ];
	
	this.getparkingTableData = function() {
		return parkingTableData;
	};
	
	
	this.parkingMapList = [
	                     //S2
	                     { locId: '1', locDesc:'TCS Pune', subLocId:'1.2', subLocDesc:'S2', floorMap:'app/assets/images/Parking_Diagram_v8.jpg'}
	                    
	                     
	                     
	                 ];
	        	
	        	
	this.parkingCoordinates= [
	               		{ slotId: '1',  slotName: 'A1',  rectX:60, rectY:0, width:60, height:60 },
	               		{ slotId: '2',  slotName: 'A2', rectX:120, rectY:0, width:60, height:60 },
	               		{ slotId: '3',  slotName: 'A3', rectX:180, rectY:0, width:60, height:60 },
	        	        { slotId: '4',  slotName: 'A4', rectX:240, rectY:0, width:60, height:60 },
	        	        { slotId: '5',  slotName: 'A5', rectX:300, rectY:0, width:60, height:60 },
	        	        { slotId: '6',  slotName: 'A6', rectX:360, rectY:0, width:60, height:60 },
	        	        { slotId: '7',  slotName: 'B1', rectX:60, rectY:180, width:60, height:60 },
	        	        { slotId: '8',  slotName: 'B2', rectX:120, rectY:180, width:60, height:60 },
	        	        { slotId: '9',  slotName: 'B3', rectX:180, rectY:180, width:60, height:60 },
	        	        { slotId: '10', slotName: 'B4', rectX:240, rectY:180, width:60, height:60 },
	        	        { slotId: '11', slotName: 'B5', rectX:300, rectY:180, width:60, height:60 },
	        	        { slotId: '12', slotName: 'B6', rectX:360, rectY:180, width:60, height:60 },
	        	        { slotId: '13', slotName: 'C1', rectX:60,  rectY:240, width:60, height:60 },
	        	        { slotId: '14', slotName: 'C2', rectX:120, rectY:240, width:60, height:60 },
	        	        { slotId: '15', slotName: 'C3', rectX:180, rectY:240, width:60, height:60 },
	        	        { slotId: '16', slotName: 'C4', rectX:240, rectY:240, width:60, height:60 },
	        	        { slotId: '17', slotName: 'C5', rectX:300, rectY:240, width:60, height:60 },
	        	        { slotId: '18', slotName: 'C6', rectX:360, rectY:240, width:60, height:60 },
	        	       /* { slotId: '19', slotName: 'D1', rectX:60,  rectY:480, width:60, height:60 },
	        	        { slotId: '20', slotName: 'D2', rectX:120, rectY:480, width:60, height:60 },
	        	        { slotId: '21', slotName: 'D3', rectX:180, rectY:480, width:60, height:60 },
	        	        { slotId: '22', slotName: 'D4', rectX:240, rectY:480, width:60, height:60 },
	        	        { slotId: '23', slotName: 'D5', rectX:300, rectY:480, width:60, height:60 },
	        	        { slotId: '24', slotName: 'D6', rectX:360, rectY:480, width:60, height:60 }	*/
	               		 
	               ];      
	
	  this.noOfslots = 2;
	  this.slotsName = ['A4', 'A5'];
      this.setNoOfSlots = function(noOfslots){
    	  this.noOfslots = noOfslots;
      }
	  
      this.getNoOfSlots = function(){
    	  return  this.noOfslots;
      }   
      
	        	/*this.AHU_ZoneCoordinates = [
	        	                        //S2   ///////   crlX = width/2 + rectX, crlY = height/2 + rectY                     
	        	        { rectX:60, rectY:180, width:60, height:60 },
	        	        { rectX:120, rectY:180, width:60, height:60 },
	        	        { rectX:180, rectY:180, width:60, height:60 },
	        	        { rectX:240, rectY:180, width:60, height:60 },
	        	        { rectX:300, rectY:180, width:60, height:60 },
	        	        { rectX:360, rectY:180, width:60, height:60 },
	        	        { rectX:60, rectY:240, width:60, height:60 },
	        	        { rectX:120, rectY:240, width:60, height:60 },
	        	        { rectX:180, rectY:240, width:60, height:60 },
	        	        { rectX:240, rectY:240, width:60, height:60 },
	        	        { rectX:300, rectY:240, width:60, height:60 },
	        	        { rectX:360, rectY:240, width:60, height:60 },
	        	        { rectX:60, rectY:420, width:60, height:60 },
	        	        { rectX:120, rectY:420, width:60, height:60 },
	        	        { rectX:180, rectY:420, width:60, height:60 },
	        	        { rectX:240, rectY:420, width:60, height:60 },
	        	        { rectX:300, rectY:420, width:60, height:60 },
	        	        { rectX:360, rectY:420, width:60, height:60 },
	        	        { rectX:60, rectY:480, width:60, height:60 },
	        	        { rectX:120, rectY:480, width:60, height:60 },
	        	        { rectX:180, rectY:480, width:60, height:60 },
	        	        { rectX:240, rectY:480, width:60, height:60 },
	        	        { rectX:300, rectY:480, width:60, height:60 },
	        	        { rectX:360, rectY:480, width:60, height:60 }	        	        
	                ];*/
	        	
	        	
	        		
});



