app.controller('performanceCtrls', function($scope, $uibModalInstance) {

	$scope.close = function () {
		$uibModalInstance.dismiss('close');
	};
	
	
	$scope.title= 'Performance Dashboard';
});

app.controller('gaugeAvailabilityCtrl1', function($scope) {

		var chartSource = new Array([ 'Label', 'Value' ], [ '', 96] );
		var data = new google.visualization.arrayToDataTable(chartSource);

		var options = {
			label : {
				position : 'bottom'
			},
			//width: 175, height: 175,
			top: 100,left:2000,
			redFrom : 0,
			redTo : 33,
			yellowFrom : 33,
			yellowTo : 66,
			greenFrom : 66,
			greenTo : 100,
			
			minorTicks : 30,
			max : 100,
			min : 0,
   		
		};

		var chart = {};

		chart.data = data;
		chart.options = options;
		$scope.chart = chart;

});

app.controller('gaugePerformanceCtrl1', function($scope) {

	var chartSource = new Array([ 'Label', 'Value' ], [ '', 98] );
	var data = new google.visualization.arrayToDataTable(chartSource);

	var options = {
		label : {
			position : 'bottom'
		},
		//width: 175, height: 175,
		top: 100,left:2000,
		redFrom : 0,
		redTo : 33,
		yellowFrom : 33,
		yellowTo : 66,
		greenFrom : 66,
		greenTo : 100,
		minorTicks : 30,
		max : 100,
		min : 0,
		
	};

	var chart = {};

	chart.data = data;
	chart.options = options;
	$scope.chart = chart;

});

app.controller('gaugeAvailabilityCtrl2', function($scope) {

	var chartSource = new Array([ 'Label', 'Value' ], [ '', 97] );
	var data = new google.visualization.arrayToDataTable(chartSource);

	var options = {
		label : {
			position : 'bottom'
		},
		//width: 175, height: 175,
		top: 100,left:2000,
		redFrom : 0,
		redTo : 33,
		yellowFrom : 33,
		yellowTo : 66,
		greenFrom : 66,
		greenTo : 100,
		
		minorTicks : 30,
		max : 100,
		min : 0,
		
	};

	var chart = {};

	chart.data = data;
	chart.options = options;
	$scope.chart = chart;

});

app.controller('gaugePerformanceCtrl2', function($scope) {

var chartSource = new Array([ 'Label', 'Value' ], [ '', 95] );
var data = new google.visualization.arrayToDataTable(chartSource);

var options = {
	label : {
		position : 'bottom'
	},
	//width: 175, height: 175,
	top: 100,left:2000,
	redFrom : 0,
	redTo : 33,
	yellowFrom : 33,
	yellowTo : 66,
	greenFrom : 66,
	greenTo : 100,
	minorTicks : 30,
	max : 100,
	min : 0,
	
};

var chart = {};

chart.data = data;
chart.options = options;
$scope.chart = chart;

});

app.controller('gaugeAvailabilityCtrl3', function($scope) {

	var chartSource = new Array([ 'Label', 'Value' ], [ '', 97] );
	var data = new google.visualization.arrayToDataTable(chartSource);

	var options = {
		label : {
			position : 'bottom'
		},
		//width: 175, height: 175,
		top: 100,left:2000,
		redFrom : 0,
		redTo : 33,
		yellowFrom : 33,
		yellowTo : 66,
		greenFrom : 66,
		greenTo : 100,
		
		minorTicks : 30,
		max : 100,
		min : 0,
		
	};

	var chart = {};

	chart.data = data;
	chart.options = options;
	$scope.chart = chart;

});

app.controller('gaugePerformanceCtrl3', function($scope) {

var chartSource = new Array([ 'Label', 'Value' ], [ '', 96] );
var data = new google.visualization.arrayToDataTable(chartSource);

var options = {
	label : {
		position : 'bottom'
	},
	//width: 175, height: 175,
	top: 100,left:2000,
	redFrom : 0,
	redTo : 33,
	yellowFrom : 33,
	yellowTo : 66,
	greenFrom : 66,
	greenTo : 100,
	minorTicks : 30,
	max : 100,
	min : 0,
	
};

var chart = {};

chart.data = data;
chart.options = options;
$scope.chart = chart;

});

app.controller('gaugeAvailabilityCtrl4', function($scope) {

	var chartSource = new Array([ 'Label', 'Value' ], [ '', 97] );
	var data = new google.visualization.arrayToDataTable(chartSource);

	var options = {
		label : {
			position : 'bottom'
		},
		//width: 175, height: 175,
		top: 100,left:2000,
		redFrom : 0,
		redTo : 33,
		yellowFrom : 33,
		yellowTo : 66,
		greenFrom : 66,
		greenTo : 100,
		
		minorTicks : 30,
		max : 100,
		min : 0,
		
	};

	var chart = {};

	chart.data = data;
	chart.options = options;
	$scope.chart = chart;

});

app.controller('gaugePerformanceCtrl4', function($scope) {

var chartSource = new Array([ 'Label', 'Value' ], [ '', 98] );
var data = new google.visualization.arrayToDataTable(chartSource);

var options = {
	label : {
		position : 'bottom'
	},
	//width: 175, height: 175,
	top: 100,left:2000,
	redFrom : 0,
	redTo : 33,
	yellowFrom : 33,
	yellowTo : 66,
	greenFrom : 66,
	greenTo : 100,
	minorTicks : 30,
	max : 100,
	min : 0,
	
};

var chart = {};

chart.data = data;
chart.options = options;
$scope.chart = chart;

});

app.controller('gaugeAvailabilityCtrl5', function($scope) {

	var chartSource = new Array([ 'Label', 'Value' ], [ '', 92] );
	var data = new google.visualization.arrayToDataTable(chartSource);

	var options = {
		label : {
			position : 'bottom'
		},
		//width: 175, height: 175,
		top: 100,left:2000,
		redFrom : 0,
		redTo : 33,
		yellowFrom : 33,
		yellowTo : 66,
		greenFrom : 66,
		greenTo : 100,
		
		minorTicks : 30,
		max : 100,
		min : 0,
		
	};

	var chart = {};

	chart.data = data;
	chart.options = options;
	$scope.chart = chart;

});

app.controller('gaugePerformanceCtrl5', function($scope) {

var chartSource = new Array([ 'Label', 'Value' ], [ '', 91] );
var data = new google.visualization.arrayToDataTable(chartSource);

var options = {
	label : {
		position : 'bottom'
	},
	//width: 175, height: 175,
	top: 100,left:2000,
	redFrom : 0,
	redTo : 33,
	yellowFrom : 33,
	yellowTo : 66,
	greenFrom : 66,
	greenTo : 100,
	minorTicks : 30,
	max : 100,
	min : 0,
	
};

var chart = {};

chart.data = data;
chart.options = options;
$scope.chart = chart;

});
