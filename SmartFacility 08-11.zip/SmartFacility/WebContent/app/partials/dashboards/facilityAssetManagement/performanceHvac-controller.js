app.controller('performanceHvacCtrls', function($scope, $uibModalInstance) {
console.log("hello");
	$scope.close = function () {
		$uibModalInstance.dismiss('close');
	};
	
	
	$scope.title= 'Equipment Performance';
});

/*app.controller('gaugeAvailabilityCtrl', function($scope) {

		var chartSource = new Array([ 'Label', 'Value' ], [ '%', 96] );
		var data = new google.visualization.arrayToDataTable(chartSource);

		var options = {
			label : {
				position : 'bottom'
			},
			//width: 175, height: 175,
			top: 100,left:2000,
			greenFrom : 0,
			greenTo : 33,
			redFrom : 66,
			redTo : 100,
			yellowFrom : 33,
			yellowTo : 66,
			minorTicks : 30,
			max : 100,
			min : 0,
   		
		};

		var chart = {};

		chart.data = data;
		chart.options = options;
		$scope.chart = chart;

});*/


