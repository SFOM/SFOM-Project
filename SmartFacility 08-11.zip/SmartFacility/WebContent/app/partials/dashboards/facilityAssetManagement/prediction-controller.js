app.controller('predictionCtrls', function($scope, $uibModalInstance) {

	$scope.close = function () {
		$uibModalInstance.dismiss('close');
	};
	
	
	$scope.title= 'Equipment Failure Prediction';
});

app.controller('gaugeProbFailCtrl1', function($scope) {

		var chartSource = new Array([ 'Label', 'Value' ], [ '', 3] );
		var data = new google.visualization.arrayToDataTable(chartSource);

		var options = {
			label : {
				position : 'bottom'
			},
			//width: 175, height: 175,
			top: 100,left:2000,
			greenFrom : 0,
			greenTo : 33,
			redFrom : 66,
			redTo : 100,
			yellowFrom : 33,
			yellowTo : 66,
			minorTicks : 30,
			max : 100,
			min : 0,
   		
		};

		var chart = {};

		chart.data = data;
		chart.options = options;
		$scope.chart = chart;

});

app.controller('gaugeProbFailCtrl2', function($scope) {

	var chartSource = new Array([ 'Label', 'Value' ], [ '', 1] );
	var data = new google.visualization.arrayToDataTable(chartSource);

	var options = {
		label : {
			position : 'bottom'
		},
		//width: 175, height: 175,
		top: 100,left:2000,
		greenFrom : 0,
		greenTo : 33,
		redFrom : 66,
		redTo : 100,
		yellowFrom : 33,
		yellowTo : 66,
		minorTicks : 30,
		max : 100,
		min : 0,
		
	};

	var chart = {};

	chart.data = data;
	chart.options = options;
	$scope.chart = chart;

});

app.controller('gaugeProbFailCtrl3', function($scope) {

	var chartSource = new Array([ 'Label', 'Value' ], [ '', 2] );
	var data = new google.visualization.arrayToDataTable(chartSource);

	var options = {
		label : {
			position : 'bottom'
		},
		//width: 175, height: 175,
		top: 100,left:2000,
		greenFrom : 0,
		greenTo : 33,
		redFrom : 66,
		redTo : 100,
		yellowFrom : 33,
		yellowTo : 66,
		minorTicks : 30,
		max : 100,
		min : 0,
		
	};

	var chart = {};

	chart.data = data;
	chart.options = options;
	$scope.chart = chart;

});

app.controller('gaugeProbFailCtrl4', function($scope) {

	var chartSource = new Array([ 'Label', 'Value' ], [ '', 4] );
	var data = new google.visualization.arrayToDataTable(chartSource);

	var options = {
		label : {
			position : 'bottom'
		},
		//width: 175, height: 175,
		top: 100,left:2000,
		greenFrom : 0,
		greenTo : 33,
		redFrom : 66,
		redTo : 100,
		yellowFrom : 33,
		yellowTo : 66,
		minorTicks : 30,
		max : 100,
		min : 0,
		
	};

	var chart = {};

	chart.data = data;
	chart.options = options;
	$scope.chart = chart;

});

app.controller('gaugeProbFailCtrl5', function($scope) {

	var chartSource = new Array([ 'Label', 'Value' ], [ '', 2] );
	var data = new google.visualization.arrayToDataTable(chartSource);

	var options = {
		label : {
			position : 'bottom'
		},
		//width: 175, height: 175,
		top: 100,left:2000,
		greenFrom : 0,
		greenTo : 33,
		redFrom : 66,
		redTo : 100,
		yellowFrom : 33,
		yellowTo : 66,
		minorTicks : 30,
		max : 100,
		min : 0,
		
	};

	var chart = {};

	chart.data = data;
	chart.options = options;
	$scope.chart = chart;

});
