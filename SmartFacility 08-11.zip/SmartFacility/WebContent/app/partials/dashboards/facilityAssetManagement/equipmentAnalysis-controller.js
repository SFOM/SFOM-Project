
app.controller('equipmentAnalysisCtrl', function($scope, $filter, equipmentAnalysisService) {
	  
	$scope.eqptsData = equipmentAnalysisService.getEqptData();
	
	/*this.openknowledgeBase = function (knowledgeBase) {
		
		console.log("Knowld Base" +knowledgeBase);
		console.log("Knowld Base opn" +openknowledgeBase);
		
		if(knowledgeBase=="HVAC")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/equipmentAnalysis/knowledgeBaseHvac.html',
				controller : 'knowledgeBaseHvacCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}		
	  };
		
		if(knowledgeBase=="Pump")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/knowledgeBaseWaterPump.html',
				controller : 'knowledgeBaseHvacCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}	
		
		if(knowledgeBase=="HVAC")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/knowledgeBaseHvac.html',
				controller : 'knowledgeBaseHvacCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}
		
		
	  };*/
		
	
	
//	console.log($scope.eqptsData);
		
	$scope.eqptGridOptions = { data: 'eqptsData',
			 enableSorting: true,
			 
            columnDefs: [{field:'eqptId', displayName:'Equipment ID', headerCellClass:'ui-grid-header-cell-eqptAnalysis',
            	            enableSorting: true,
            	           },
                         {field:'eqptNm', displayName:'Equipment Name', headerCellClass:'ui-grid-header-cell-eqptAnalysis', 
            				enableSorting: false}, 
                         {field:'eqptType', displayName:'Equipment Type', headerCellClass:'ui-grid-header-cell-eqptAnalysis'}, 
                         {field:'model', displayName:'Model', headerCellClass:'ui-grid-header-cell-eqptAnalysis'},
                         
                        // {field:'makeYr', displayName:'Make Year', headerCellClass:'ui-grid-header-cell-eqptAnalysis', 
                    	// 	resizable: true}, 
                         {field:'purchaseDate', displayName:'Purchase Date', headerCellClass:'ui-grid-header-cell-eqptAnalysis',
                	 		enableSorting: false},
                    	 {field:'warrantyExp', displayName:'Warranty Expiry', headerCellClass:'ui-grid-header-cell-eqptAnalysis',
                    	 		enableSorting: false},
                    	 {field:'performance', displayName:'Performance', cellTemplate: $.get('app/partials/dashboards/facilityAssetManagement/switchPerformance.html'), 
                    	 			headerCellClass:'ui-grid-header-cell-eqptAnalysis', enableSorting: false},   
                    	 {field:'prediction', displayName:'Prediction', cellTemplate: $.get('app/partials/dashboards/facilityAssetManagement/switchPrediction.html'),
                    	 				headerCellClass:'ui-grid-header-cell-eqptAnalysis', enableSorting: false}, 
                         {field:'knowledgeBase', displayName:'Knowledge Base', cellTemplate: $.get('app/partials/dashboards/facilityAssetManagement/switchknowledgeBase.html'),
                    	 					headerCellClass:'ui-grid-header-cell-eqptAnalysis', enableSorting: false},
                    	 {field:'generateMaintanenceRequest', displayName : 'Maintanence Request',
                    	 						 cellTemplate: '<input type="checkbox" ng-model="row.entity.generateMaintanenceRequest" ">'	, headerCellClass:'ui-grid-header-cell-eqptAnalysis',enableSorting: false },
                    	 {field:'maintanenceReport', displayName : ' Maintanence Report',
                        	 						 cellTemplate: '<input type="checkbox" ng-model="row.entity.maintanenceReport" ">'	,headerCellClass:'ui-grid-header-cell-eqptAnalysis',enableSorting: false},
                    	 					
                         ],                          
                         
                         
    };
	
});



app.controller('popupPerformanceCtrl', function($scope, $filter, $uibModal, $http, equipmentAnalysisService) {
	
	$scope.eqptsData = equipmentAnalysisService.getEqptData();
	console.log($scope.eqptsData);

	$scope.popUpPerformance = function(performance) {

		/*var modalInstance = $uibModal.open({
			animation : true,
			templateUrl : 'app/partials/dashboards/facilityAssetManagement/performance.html',
			controller : 'performanceCtrls',
			windowClass : 'modal-dashboard',
			scope : $scope,

		});*/
		
		if(performance=="001")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/performanceHvac.html',
				controller : 'knowledgeBaseHvacCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}	
		
		if(performance=="005")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/performanceWaterPump.html',
				controller : 'knowledgeBaseHvacCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}
		
		if(performance=="004")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/performanceLift.html',
				controller : 'knowledgeBaseHvacCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}
		
		if(performance=="002")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/performanceLight.html',
				controller : 'knowledgeBaseHvacCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}
		
		if(performance=="003")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/performanceUPS.html',
				controller : 'predictionHvacCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}
	}
});


app.controller('popupPredictionCtrl', function($scope, $filter, $uibModal, $http, equipmentAnalysisService) {

	$scope.eqptsData = equipmentAnalysisService.getEqptData();
	console.log($scope.eqptsData);
	$scope.popUpPrediction = function(prediction) {
		
		console.log(prediction)
		
		/*var modalInstance = $uibModal.open({
			animation : true,
			templateUrl : 'app/partials/dashboards/facilityAssetManagement/prediction.html',
			controller : 'predictionCtrls',
			windowClass : 'modal-dashboard-small',
			scope : $scope,

		});*/
		
		if(prediction=="AC")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/predictionHvac.html',
				controller : 'knowledgeBaseHvacCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}	
		
		if(prediction=="Crompton")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/predictionWaterPump.html',
				controller : 'knowledgeBaseHvacCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}
		
		if(prediction=="Schindler")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/predictionLift.html',
				controller : 'knowledgeBaseHvacCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}
		
		if(prediction=="Bulb")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/predictionLight.html',
				controller : 'knowledgeBaseHvacCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}
		
		if(prediction=="Luminous")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/predictionUPS.html',
				controller : 'predictionHvacCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}
		
	}
});


app.controller('popupKnowledgeBaseCtrl', function($scope, $filter, $uibModal, $http, equipmentAnalysisService) {

	$scope.eqptsData = equipmentAnalysisService.getEqptData();
	console.log($scope.eqptsData);
	
	$scope.popUpKnowledgeBase = function(knowledgeBase) {
		console.log(knowledgeBase);
		
		if(knowledgeBase=="HVAC")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/knowledgeBaseHvac.html',
				controller : 'knowledgeBaseHvacCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}	
		
		if(knowledgeBase=="Pump")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/knowledgeBaseWaterPump.html',
				controller : 'knowledgeBaseHvacCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}
		
		if(knowledgeBase=="Lift")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/knowledgeBaseLift.html',
				controller : 'knowledgeBaseHvacCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}
		
		if(knowledgeBase=="Light")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/knowledgeBaseLight.html',
				controller : 'knowledgeBaseHvacCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}
		
		if(knowledgeBase=="UPS")
		{
			var modalInstance = $uibModal.open({
				animation : true,
				templateUrl : 'app/partials/dashboards/facilityAssetManagement/knowledgeBaseUPS.html',
				controller : 'knowledgeBaseHvacCtrls',
				windowClass : 'modal-chart',
				scope : $scope,

			});
		}
		

	/*	var modalInstance = $uibModal.open({
			animation : true,
			templateUrl : 'app/partials/dashboards/equipmentAnalysis/knowledgeBaseHvac.html',
			controller : 'knowledgeBaseHvacCtrls',
			windowClass : 'modal-dashboard',
			scope : $scope,

		});*/
	}
});
