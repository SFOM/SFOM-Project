
app.service('equipmentAnalysisService', function($http) {
	
	var eqptData = [
	                  {
	                      "eqptId": "001", 
	                      "eqptNm": "AC",
	                      "eqptType": "HVAC",
	                      "model": 101, 
	                      "makeYr": 2011,
	                      "purchaseDate": "2011-05-09",
	                      "warrantyExp": "2016-07-30",
	                      "performance": "001",
	                      "prediction": "AC",
	                      "knowledgeBase":"HVAC",
	                  },
	                  {
	                      "eqptId": "002", 
	                      "eqptNm": "Bulb",
	                      "eqptType": "Light",
	                      "model": 91, 
	                      "makeYr": 2010,
	                      "purchaseDate": "2010-05-09",
	                      "warrantyExp": "2016-07-30",
	                      "performance": "002",
	                      "prediction": "Bulb",
	                      "knowledgeBase":"Light",
	                      
	                  },
	                  {
	                      "eqptId": "003", 
	                      "eqptNm": "Luminous Zelo",
	                      "eqptType": "UPS",
	                      "model": 1100, 
	                      "makeYr": 2014,
	                      "purchaseDate": "2014-05-09",
	                      "warrantyExp": "2017-07-30",
	                      "performance": "003",
	                      "prediction": "Luminous",
	                      "knowledgeBase":"UPS",
	                      
	                  },
	                  {
	                      "eqptId": "004", 
	                      "eqptNm": "Schindler",
	                      "eqptType": "Lift",
	                      "model": 7000, 
	                      "makeYr": 2014,
	                      "purchaseDate": "2014-05-09",
	                      "warrantyExp": "2019-07-30",
	                      "performance": "004",
	                      "prediction": "Schindler",
	                      "knowledgeBase":"Lift",
	                      
	                  },
	                  {
	                      "eqptId": "005", 
	                      "eqptNm": "Crompton Greaves",
	                      "eqptType": "Water Pump",
	                      "model": 1010, 
	                      "makeYr": 2015,
	                      "purchaseDate": "2015-12-12",
	                      "warrantyExp": "2017-07-30",
	                      "performance": "005",
	                      "prediction": "Crompton",
	                      "knowledgeBase":"Pump",
	                      
	                  },
	                 
	              ];
	
	this.getEqptData = function() {
		//console.log(eqptData);
		return eqptData;
	};
	

});
