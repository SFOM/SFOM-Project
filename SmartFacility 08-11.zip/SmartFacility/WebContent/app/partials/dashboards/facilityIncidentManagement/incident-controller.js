app.controller('incidentCtrl',function($scope, $state, $location, fwdFloorService){
	

});

app.controller('IncidentMonthlyDonutChartCntr', function($scope) {

	drawChart();

	function drawChart() {
		var data1 = google.visualization.arrayToDataTable([
				[ 'Incident', 'Count' ], [ 'Slippery Floor', 32 ], [ 'Collision with Door', 37 ],
				[ 'Staircase Slip', 17 ], [ 'Broken Glass', 12  ], [ 'Stuck in Lift', 28 ] ]);

		var options1 = {
			/*legend : 'none',*/
			legend : {position: 'left', textStyle: { color: 'white', fontSize: 10}},
			//pieSliceText : 'label',
			pieHole : 0.3,
			backgroundColor : '#262626',
			is3D : true,

			chartArea : {
				width : '90%',
				height : '95%'
			},
			/*pieSliceText: 'label',
	          slices: {  3: {offset: 0.2},
	                     1: {offset: 0.1},
	                     5: {offset: 0.2},
	                   
	          }*/
		};

		var chart = new google.visualization.PieChart(document
				.getElementById('incidentdonutchart'));
		chart.draw(data1, options1);
	}

});

app.controller('AccidentMonthlyDonutChartCntr', function($scope) {

	drawChart();

	function drawChart() {
		var data2 = google.visualization.arrayToDataTable([
				[ 'Accident', 'Count' ], [ 'Bike Skids', 32 ], [ 'Collision with Wall', 27 ],
				[ 'Collision with another Vehicle', 13 ], [ 'Tire Burst', 07 ] ]);

		var options2 = {
			legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
			//pieSliceText : 'label',   /*we get the slice label in text instead of % number */
			
			pieHole : 0.3,
			backgroundColor : '#262626',
			is3D : true,

			chartArea : {
				width : '90%',
				height : '95%'
			}
						 
		};

		var chart = new google.visualization.PieChart(document
				.getElementById('accidentdonutchart'));
		chart.draw(data2, options2);
		
		 /*google.visualization.events.addListener(chart, 'select', selectHandler);*/
	}

});


app.controller('IncidentSeverityDonutChartCntr', function($scope) {

	drawChart();

	function drawChart() {
		var data3 = google.visualization.arrayToDataTable([
				[ 'Severity', 'Count' ], [ 'Warning', 28 ], [ 'Critical',17 ],
				[ 'Clear', 55 ]]);

		var options3 = {
			legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
			//pieSliceText : 'label',   /*we get the slice label in text instead of % number */
			
			pieHole : 0.3,
			backgroundColor : '#262626',
			is3D : true,

			chartArea : {
				width : '90%',
				height : '95%'
			}
						 
		};

		var chart = new google.visualization.PieChart(document
				.getElementById('incidentSeveritydonutchart'));
		chart.draw(data3, options3);
	}

});



app.controller('EscalationIncidentStatusBarChartCntr', function($scope) {

	drawChart();

	function drawChart() {
		var data4 = google.visualization.arrayToDataTable([
                            ['Not Escalated', 'Open', 'Closed'],
                            ['Not Escalated', 12,17] ]);		
		var options4 = {
				title : '',
				 is3D:true,
				legend : {
					position : 'none'
				},
				hAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',
				isStacked: true,		  
				chartArea:{                   //top: 10,left:65,
		        	width:'55%',height:'55%'
		        		}
			};

		var chart = new google.visualization.BarChart(document
				.getElementById('EscalationIncidentStatusBarChart'));
		chart.draw(data4, options4);
	}

});


app.controller('IncidentOwnersAcknowledgementBarChartCntr2', function($scope) {

	drawChart();

	function drawChart() {
		
		var data5 = google.visualization.arrayToDataTable([
                            ['Admin1', 'Admin2', 'Admin3', 'Admin4'],
                            [2, 3, 7, 5] ]);	
		
	
		/*data5.addColumn('string', 'Incident Owner');
	      data5.addColumn('number', 'Unassigned');

	      data5.addRows([
	        ['Admin1', 2],
	        ['Admin2', 3],
	        ['Admin3', 7],
	        ['Admin4', 5]
        
	       ]);*/
	      	      
		var options5 = {
				title : '',
				 is3D:true,
				legend : {
					position : 'none'
				},
				hAxis : {
					title : 'Incident Owner',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : 'Unassigned',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',
				//isStacked: true,		  
				chartArea:{                   //top: 10,left:65,
		        	width:'85%',height:'75%'
		        		}
			};

		var chart = new google.visualization.ColumnChart(document
				.getElementById('IncidentOwnersAcknowledgementBarChart'));
		chart.draw(data5, options5);
	}

});


app.controller('incidentAgeIncidentStatusBarChartCntr', function($scope) {

	drawChart();

	function drawChart() {
		
		var data6 = google.visualization.arrayToDataTable([
		                                                   ['Age', 'Closed', 'New'],
		                                                   ['', 15,12] ]);	
	      	      
		var options6 = {
				title : '',
				 is3D:true,
				 legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
				hAxis : {
					title : '1-7 Days',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',
				//isStacked: true,		  
				chartArea:{                   //top: 10,left:65,
		        	width:'50%',height:'75%'
		        		}
			};

		var chart = new google.visualization.ColumnChart(document
				.getElementById('incidentAgeIncidentStatusBarChart'));
		chart.draw(data6, options6);
	}

});

app.controller('incidentStatusAcknowChartCntr', function($scope) {

	drawChart();

	function drawChart() {
		
		var data7 = google.visualization.arrayToDataTable([
		                                                   ['Status', 'Unassigned'],
		                                                   ['New', 16], ['Closed', 11] ]);	
	      	      
		var options7 = {
				title : '',
				 is3D:true,
				 legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
				hAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',
				//isStacked: true,		  
				chartArea:{                   //top: 10,left:65,
		        	width:'40%',height:'75%'
		        		}
			};

		var chart = new google.visualization.ColumnChart(document
				.getElementById('incidentStatusAcknowChart'));
		chart.draw(data7, options7);
	}

});




app.controller('IncidentCategorySaverityBarChartCntr', function($scope) {

	drawChart();

	function drawChart() {
		var data8 = google.visualization.arrayToDataTable([
                            ['Saverity', 'Critical', 'Clear', 'Warning'],
                            ['Diagnostics', 5, 7, 3],
                            ['Error', 2, 3, 4],
                            ['Capacity', 3, 2, 5],
                            ['Performance', 3, 4, 2],
                            ['Availability', 5, 2, 3]]);		
		var options8 = {
				title : '',
				 is3D:true,
				 legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
				hAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : '',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',
				isStacked: true,		  
				chartArea:{                   //top: 10,left:65,
		        	width:'45%',height:'55%'
		        		}
			};

		var chart = new google.visualization.BarChart(document
				.getElementById('IncidentCategorySaverityBarChart'));
		chart.draw(data8, options8);
	}

});





app.controller('incidentTableCtrl', function($scope, $filter, incidentTableService) {
	
	/*$scope.tableDataModel = 0;*/
	  
	/*$scope.monthlyIncidentData = incidentTableService.getmonthlyIncidentReading();
	
	$scope.yearlyIncidentData = incidentTableService.getyearlyIncidentReading();*/ 
	
	$scope.IncidentAllTableData = incidentTableService.getAllIncidentReading();
	
	console.log($scope.IncidentAllTableData);
	
	$scope.allIncidentOptions = { data: 'IncidentAllTableData', enableSorting: true,
            columnDefs: [
                     	 {field:'incdentId', displayName:'Incident ID', headerCellClass:'ui-grid-header-cell-blue'},	
                         {field:'summary', displayName:'Summary', headerCellClass:'ui-grid-header-cell-blue'}, 
                         {field:'Priority', displayName:'Priority', headerCellClass:'ui-grid-header-cell-blue',},  
            			 {field:'Status', displayName:'Status', headerCellClass:'ui-grid-header-cell-blue'},
            		   	 {field:'incidentAge', displayName:'Incident Age', headerCellClass:'ui-grid-header-cell-blue'},
            			 {field:'lastupdated', displayName:'Last Updated', headerCellClass:'ui-grid-header-cell-blue'},
            			 {field:'owner', displayName:'Owner', headerCellClass:'ui-grid-header-cell-blue'},
            			 {field:'acknowledged', displayName:'Acknowledge', headerCellClass:'ui-grid-header-cell-blue'},
            			 {field:'escalated', displayName:'Escalated', headerCellClass:'ui-grid-header-cell-blue',
            				 enableSorting: false},
            			 {field:'type', displayName:'Type', headerCellClass:'ui-grid-header-cell-blue'},
            			 {field:'category', displayName:'Category', headerCellClass:'ui-grid-header-cell-blue',
            				 enableSorting: false},
                        ],

                         
    };
	
});
	
	
	
	
	
	
	//the below code is for monthly and yearly Incident/Accident Table
	
	/*$scope.monthIncidentOptions = { data: 'monthlyIncidentData',
			 enableSorting: true,
            columnDefs: [{field:'srNo', displayName:'Sr. No', headerCellClass:'ui-grid-header-cell-blue'}, 
                         {field:'date', displayName:'Incident Date', headerCellClass:'ui-grid-header-cell-blue', }, 
                         {field:'incType', displayName:'Incident Type', headerCellClass:'ui-grid-header-cell-blue'}, 
                         {field:'loc', displayName:'Incident Location', headerCellClass:'ui-grid-header-cell-blue'},                   
                         ],

    };*/
	
	/*$scope.yearIncidentOptions = { data: 'yearlyIncidentData',
            columnDefs: [
                     	 {field:'month', displayName:'Meter Title', headerCellClass:'ui-grid-header-cell-green'},	
                         {field:'incidentType', displayName:'Daily Forecast', headerCellClass:'ui-grid-header-cell-green'}, 
                         {field:'totalIncidents', displayName:'Monthly Forecast', headerCellClass:'ui-grid-header-cell-green', 
            				enableSorting: false},                   
                        ],

                         enableHorizontalScrollbar : 1, 
    };*/






//this is unnecessary code below (column chart)


/*app.controller('ColChartCntr1',
		function($scope, $stateParams, selLocationService) {
			
			$scope.$watch(function(){ return selLocationService.selLocation; }, function() {
				
				var selectedLocation = selLocationService.getSelFloor();
				$scope.selectedFloor = selectedLocation[2];
	
			});
			
			Date.prototype.getWeek = function() {
				var determinedate = new Date();
				determinedate.setFullYear(this.getFullYear(), this.getMonth(),
						this.getDate());
				var D = determinedate.getDay();
				if (D == 0)
					D = 7;
				determinedate.setDate(determinedate.getDate() + (4 - D));
				var YN = determinedate.getFullYear();
				var ZBDoCY = Math.floor((determinedate.getTime() - new Date(YN,
						0, 1, -6)) / 86400000);
				var WN = 1 + Math.floor(ZBDoCY / 7);

//				console.log(WN);
				return WN;

			}

			function updateChart(selectedType) {

				drawColumnChart(selectedType);
			}

			updateChart("Week");

			$('#div_clmnChart_btns button').click(function(e) {
				var selectedType = $(this).text();
				updateChart(selectedType);
				return false;
			});

			function drawColumnChart(sel_view) {
				var curDate = new Date();
				var day = curDate.getDate();
				var dayArr = [];
				var i = 1;
				var j = 1;
				var day1 = curDate.getDate();
				var month = curDate.getMonth();
				var month1 = curDate.getMonth();
				var monthArr = [];
				var monthArr1 = [];
				var monthNames = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun",
						"Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan" ];
				for (; i < 30;) {
					if (day1 == 1) {
						day = 31;
						i = 1;
					}
					dayArr.push(day1);
					day1 = day - i;
					i++;
				}

				for (; j < 10;) {
					if (month1 == 1) {
						month = 13;
						j = 1;
					}

					monthArr.push(month1);
					monthArr1.push(monthNames[month1]);
					month1 = month - j;
					j++;
				}

				try {
					var curDate = new Date();
					if (sel_view === 'Week') {
						var data = new google.visualization.DataTable();
						data.addColumn('string', 'Days of week');
						data.addColumn('number', 'KWhr');

						var todayDay = curDate.getDate();
						data.addRows([ [ (dayArr[6]).toString(), 112.5 ],
								[ (dayArr[5]).toString(), 109.8 ],
								[ (dayArr[4]).toString(), 120.3 ],
								[ (dayArr[3]).toString(), 118.1 ],
								[ (dayArr[2]).toString(), 105.7 ],
								[ (dayArr[1]).toString(), 91.5 ],
								[ (dayArr[0]).toString(), 102.6 ], ]);

						var options = {
							title : '',
							is3D : true,
							legend : {
								position : 'none'
							},
							hAxis : {
								title : 'Days of week',
								textStyle : {
									color : '#00B539'
								},
								titleTextStyle : {
									color : '#00B539'
								},
							},
							vAxis : {
								title : 'KWhr',
								textStyle : {
									color : '#00B539'
								},
								titleTextStyle : {
									color : '#00B539'
								},
							},
							backgroundColor : '#262626',
							colors : [ '#00B539' ],
							chartArea : {
								top : 10,
								left : 65,
								width : '85%',
								height : '75%'
							}
						};

						$('#btntd').removeClass('btnSelected');
						$('#btnwk').addClass('btnSelected');
						$('#btnmt').removeClass('btnSelected');
					} else if (sel_view === 'Month') {
						var data = new google.visualization.DataTable();
						data.addColumn('string', 'Days of Month');
						data.addColumn('number', 'KWhr');
						var todayMonth = curDate.getDate();

						data.addRows([ [ (dayArr[29]).toString(), 100.567 ],
								[ (dayArr[28]).toString(), 107.546 ],
								[ (dayArr[27]).toString(), 104.589 ],
								[ (dayArr[26]).toString(), 107.378 ],
								[ (dayArr[25]).toString(), 105.600 ],
								[ (dayArr[24]).toString(), 109.345 ],
								[ (dayArr[23]).toString(), 106.060 ],
								[ (dayArr[22]).toString(), 100.567 ],
								[ (dayArr[21]).toString(), 107.546 ],
								[ (dayArr[20]).toString(), 104.589 ],
								[ (dayArr[19]).toString(), 107.378 ],
								[ (dayArr[18]).toString(), 105.600 ],
								[ (dayArr[17]).toString(), 109.345 ],
								[ (dayArr[16]).toString(), 106.060 ],
								[ (dayArr[15]).toString(), 100.567 ],
								[ (dayArr[14]).toString(), 107.546 ],
								[ (dayArr[13]).toString(), 104.589 ],
								[ (dayArr[12]).toString(), 107.378 ],
								[ (dayArr[11]).toString(), 105.600 ],
								[ (dayArr[10]).toString(), 109.345 ],
								[ (dayArr[9]).toString(), 106.060 ],
								[ (dayArr[8]).toString(), 100.567 ],
								[ (dayArr[7]).toString(), 107.546 ],
								[ (dayArr[6]).toString(), 104.589 ],
								[ (dayArr[5]).toString(), 107.378 ],
								[ (dayArr[4]).toString(), 105.600 ],
								[ (dayArr[3]).toString(), 109.345 ],
								[ (dayArr[2]).toString(), 106.060 ],
								[ (dayArr[1]).toString(), 100.567 ],
								[ (dayArr[0]).toString(), 107.546 ] ]);

						var options = {
							title : '',
							legend : {
								position : 'none'
							},
							hAxis : {
								title : 'Days of Month',
								textStyle : {
									color : '#a52714'
								},
								titleTextStyle : {
									color : '#a52714'
								},
							},
							vAxis : {
								title : 'KWhr',
								textStyle : {
									color : '#a52714'
								},
								titleTextStyle : {
									color : '#a52714'
								},
							},
							backgroundColor : '#262626',
							colors : [ '#a52714' ],

							chartArea : {
								top : 10,
								left : 65,
								width : '85%',
								height : '75%'
							}
						};
//						console.log(data);

						$('#btntd').removeClass('btnSelected');
						$('#btnwk').removeClass('btnSelected');
						$('#btnmt').addClass('btnSelected');
					} else if (sel_view === 'Today') {

						var tm = new Date();
						var hr = tm.getHours();
						var dayCom = new Array();
						var hrVal = new Array();
						var valArr = new Array();
						var data = new google.visualization.DataTable();
						data.addColumn('string', 'Hours');
						data.addColumn('number', 'KWhr');

						for (var m = hr; m >= 0; m--) {

							var y = Math.floor((Math.random() * 15) + 1);

							dayCom[m] = y;
							hrVal[m] = m.toString();
							valArr[m] = [ hrVal[m], dayCom[m] ];

						}

						console.log(valArr);
						data.addRows(valArr);
						console.log(data)

						var options = {
							title : '',
							legend : {
								position : 'none'
							},
							hAxis : {
								title : 'Hours',
								textStyle : {
									color : '#B57C00'
								},
								titleTextStyle : {
									color : '#B57C00'
								},
							},
							vAxis : {
								title : 'KWhr',
								textStyle : {
									color : '#B57C00'
								},
								titleTextStyle : {
									color : '#B57C00'
								},
							},
							backgroundColor : '#262626',
							colors : [ '#B57C00' ],
							is3D : true,

							chartArea : {
								top : 10,
								left : 65,
								width : '85%',
								height : '75%'
							}
						};

						$('#btntd').addClass('btnSelected');
						$('#btnwk').removeClass('btnSelected');
						$('#btnmt').removeClass('btnSelected');
					}

					var chart = new google.visualization.AreaChart(document
							.getElementById("chart_column"));
					chart.draw(data, options);

				} catch (err) {
					alert("An error occured in Charts.\n" + err.message());
				}
			}

		});*/



