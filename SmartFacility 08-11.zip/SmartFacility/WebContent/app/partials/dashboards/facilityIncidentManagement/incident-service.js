app.service('incidentTableService', function($http) {
	
	var monthlyIncidentReading = [
	                  {
	                      "srNo": 1, 
	                      "date": "12-09-2016",
	                      "incType": "Slip on Wet Floor",
	                      "loc": "S2 - Ground Floor", 
	                  },
	                  {
	                      "srNo": 2, 
	                      "date": "14-09-2016",
	                      "incType": "Glassfaced Brokage",
	                      "loc": "S2 - Fourth Floor", 
	                  },
	                  {
	                      "srNo": 3, 
	                      "date": "15-09-2016",
	                      "incType": "Skid from the Bike",
	                      "loc": "S2 - Sixth Floor", 
	                  },
	                  {
	                      "srNo": 4, 
	                      "date": "18-09-2016",
	                      "incType": "Accident due to Tire Burst",
	                      "loc": "S2 - Third Floor", 
	                  },
	                  {
	                      "srNo": 5, 
	                      "date": "21-09-2016",
	                      "incType": "Slip from Staircases",
	                      "loc": "S2 - Second Floor", 
	                  },
	                  {
	                      "srNo": 6, 
	                      "date": "29-09-2016",
	                      "incType": "Accident due to collision of two Cars",
	                      "loc": "S2 - Seventh Floor", 
	                  },
	                  {
	                      "srNo": 7, 
	                      "date": "30-09-2016",
	                      "incType": "Collision with Door",
	                      "loc": "S2 - Fourth Floor", 
	                  },
	                  {
	                      "srNo": 8, 
	                      "date": "05-10-2016",
	                      "incType": "Stuck in the Lift",
	                      "loc": "S2 - Fifth Floor", 
	                  }
	                  
	              ];
	
	this.getmonthlyIncidentReading = function() {
		return monthlyIncidentReading;
	};
	
	var yearlyIncidentReading = [
		                  {
		                      "month": "Sept-2016", 
		                      "incidentType": "Stuck in the Lift",
		                      "totalIncidents": 13,
		                      
		                  },
		                  {
		                      "month": "Sept-2016", 
		                      "incidentType": "Collision with Door",
		                      "totalIncidents": 17,
		                      
		                  },
		                  {
		                      "month": "Sept-2016", 
		                      "incidentType": "Slip on Wet Floor",
		                      "totalIncidents": 11,
		                      
		                  },
		                  {
		                      "month": "Sept-2016", 
		                      "incidentType": "Slip from Staircases",
		                      "totalIncidents": 08,
		                      
		                  },
		                  {
		                      "month": "Sept-2016", 
		                      "incidentType": "Glassfaced Brokage",
		                      "totalIncidents": 1,
		                      
		                  },
		                  {
		                      "month": "Oct-2016", 
		                      "incidentType": "Stuck in the Lift",
		                      "totalIncidents": 3,
		                      
		                  },
		                  {
		                      "month": "Oct-2016", 
		                      "incidentType": "Collision with Door",
		                      "totalIncidents": 2,
		                      
		                  },
		                  
		              ];
		
		this.getyearlyIncidentReading = function() {
			return yearlyIncidentReading;
		};
		
		
		var incidentAllTableReading =[
		                           {
		                        	   "incdentId": "Inc001",
		                        		"summary": "Slip on Wet Floor",
		                        		"Priority": "Medium",
		                        		"Status": "closed",
		                        		"incidentAge": "10 days",
		                        		"lastupdated": "07-10-2016",
		                        		"owner": "Admin01",
		                        		"acknowledged":  "yes",
		                        		"escalated":  "no", 
		                        		"category":   "incident",
		                        		"type": "moderate"
		                           },
		                           
		                           {
		                        	   "incdentId" : "Inc002",
		                        		"summary" : "Collision with Door",
		                        		"Priority" : "Low",
		                        		"Status" :  "open",
		                        		"incidentAge":  "3 days",
		                        		"lastupdated":  "11-10-2016",
		                        		"owner"		 :  "Admin02" ,
		                        		"acknowledged": "no",
		                        		"escalated" :  "no",
		                        		"category"	: "incident",
		                        		"type"	  : "mild"
		                           },
		                           
		                           {
		                        	   "incdentId"   : "Inc003",
		                        		"summary"    : "Stuck in the Lift",
		                        		"Priority"   :	"High",
		                        		"Status"     :  "Closed",
		                        		"incidentAge":  "7 days",
		                        		"lastupdated":  "08-10-2016",
		                        		"owner"		 :   "Admin01",
		                        		"acknowledged":  "yes",
		                        		"escalated" :  "no",
		                        		"category"		  : "incident",
		                        		"type"	  : "moderate"
		                           },
		                           
		                           {
		                        	   "incdentId"   : "Acc001",
		                        		"summary"    : "Skid from the Bike",
		                        		"Priority"   :	"High",
		                        		"Status"     :  "open",
		                        		"incidentAge":  "20 days",
		                        		"lastupdated":  "29-09-2016",
		                        		"owner"		 :  "Admin02",
		                        		"acknowledged": "yes",
		                        		"escalated" : "no",
		                        		"category" : "accident",
		                        		"type"	  : "moderate"
		                           },
		                           
		                           {
		                        	   "incdentId"   : "Inc004",
		                        		"summary"    : "Slip on Wet Floor",
		                        		"Priority"   :	"Medium",
		                        		"Status"     :  "open",
		                        		"incidentAge": "56 days",
		                        		"lastupdated":  "21-09-2016",
		                        		"owner"		 :  "Admin03",
		                        		"acknowledged": "yes",
		                        		"escalated" : "no",
		                        		"category" : "incident",
		                        		"type"	  : "mild"
		                           },
		                           
		                           {
		                        	   "incdentId"   : "Inc005",
		                        		"summary"    : "Collision with Door",
		                        		"Priority"   :	"Low",
		                        		"Status"     : "closed",
		                        		"incidentAge": "13 days",
		                        		"lastupdated":  "03-10-2016",
		                        		"owner"		 :  "Admin04",
		                        		"acknowledged": "yes",
		                        		"escalated" : "no",
		                        		"category" : "incident",
		                        		"type"	  : "mild"
		                           },
		                           
		                           {
		                        	   "incdentId"   : "Inc006",
		                        		"summary"    : "Glassfaced Brokage",
		                        		"Priority"   :	"High",
		                        		"Status"     :  "Open",
		                        		"incidentAge":  "25 days",
		                        		"lastupdated":   "yes",
		                        		"owner"		 :   "Admin01",
		                        		"acknowledged":  "yes",
		                        		"escalated" :  "no", 
		                        		"category": "incident",
		                        		"type"	  : "moderate"
		                           },
		                           {
		                        	   "incdentId"   : "Inc007",
		                        		"summary"    : "Slip on Wet Floor",
		                        		"Priority"   :	"Medium",
		                        		"Status"     :  "closed",
		                        		"incidentAge":  "35 days",
		                        		"lastupdated":  "28-08-2016",
		                        		"owner"		 :  "Admin02",
		                        		"acknowledged": "yes",
		                        		"escalated" : "no",
		                        		"category"	 : "incident",
		                        		"type"	  : "moderate"
		                           }, 
		                           
		                           {
		                        	   "incdentId"   : "Inc008",
		                        		"summary"    : "Stuck in the Lift",
		                        		"Priority"   :	"High",
		                        		"Status"     :  "Closed",
		                        		"incidentAge":  "17 days",
		                        		"lastupdated":  "20-09-2016",
		                        		"owner"		 :   "Admin03",
		                        		"acknowledged":  "yes",
		                        		"escalated" :  "no",
		                        		"category"	 : "incident",
		                        		"type"	  : "moderate"
		                           },
		                           
		                           {
		                        	   "incdentId"   : "Inc009",
		                        		"summary"    : "Slipped on stairs",
		                        		"Priority"   :	"Medium",
		                        		"Status"     :  "open",
		                        		"incidentAge":  "7 days",
		                        		"lastupdated":   "07-10-2016",
		                        		"owner"		 :   "not assignded",
		                        		"acknowledged":  "no",
		                        		"escalated" :  "no", 
		                        		"category"	 :  "incident",
		                        		"type"	  : "mild"
		                           },
		                           
		                           {
		                        	   "incdentId"   : "Inc010",
		                        		"summary"    : "Stuck in the Lift",
		                        		"Priority"   :	"High",
		                        		"Status"     :  "closed",
		                        		"incidentAge":  "10 days",
		                        		"lastupdated":   "07-10-2016",
		                        		"owner"		 :   "Admin01",
		                        		"acknowledged":  "yes",
		                        		"escalated" :  "no", 
		                        		"category"	:  "incident",
		                        		"type"	  : "moderate"
		                           },
		                           
		                           {
		                        	   "incdentId"   : "Acc002",
		                        		"summary"    : "Skid from the Bike",
		                        		"Priority"   :	"High",
		                        		"Status"     :  "open",
		                        		"incidentAge":  "15 days",
		                        		"lastupdated":  "30-09-2016",
		                        		"owner"		 :  "Admin02",
		                        		"acknowledged": "yes",
		                        		"escalated" : "no",
		                        		"category"	: "accident",
		                        		"type"	  : "moderate"
		                           },
		                           
		                           {
		                        	   "incdentId"   : "Inc011",
		                        		"summary"    : "Slip on Wet Floor",
		                        		"Priority"   :	"Medium",
		                        		"Status"     :  "closed",
		                        		"incidentAge":  "10 days",
		                        		"lastupdated":   "07-10-2016",
		                        		"owner"		 :   "Admin03",
		                        		"acknowledged":  "yes",
		                        		"escalated" :  "no", 
		                        		"category" : "incident",
		                        		"type"	  : "moderate"
		                           },
		                           
		                           
		                           {
		                        	   "incdentId"   : "Inc0012",
		                        		"summary"    : "Collision with Door",
		                        		"Priority"   :	"Low",
		                        		"Status"     : "closed",
		                        		"incidentAge": "21 days",
		                        		"lastupdated":  "22-09-2016",
		                        		"owner"		 :  "Admin04",
		                        		"acknowledged": "yes",
		                        		"escalated" : "no",
		                        		"category" : "incident",
		                        		"type"	  : "mild"
		                           },
		                           
		                           {
		                        	   "incdentId"   : "Inc0012",
		                        		"summary"    : "Stuck in the lift",
		                        		"Priority"   :	"High",
		                        		"Status"     : "closed",
		                        		"incidentAge": "4 days",
		                        		"lastupdated":  "11-10-2016",
		                        		"owner"		 :  "Admin04",
		                        		"acknowledged": "yes",
		                        		"escalated" : "no",
		                        		"category" : "incident",
		                        		"type"	  : "moderate"
		                           },
		                           
		                           {
		                        	   "incdentId"   : "Acc003",
		                        		"summary"    : "collison with Bike",
		                        		"Priority"   :	"High",
		                        		"Status"     :  "open",
		                        		"incidentAge":  "32 days",
		                        		"lastupdated":  "12-09-2016",
		                        		"owner"		 :  "Admin02",
		                        		"acknowledged": "yes",
		                        		"escalated" : "no",
		                        		"category"  : "accident",
		                        		"type"	  : "moderate"
		                           },
		                           
		                           {
		                        	   "incdentId"   : "Inc009",
		                        		"summary"    : "Slipped on stairs",
		                        		"Priority"   :	"Medium",
		                        		"Status"     :  "closed",
		                        		"incidentAge":  "22 days",
		                        		"lastupdated":   "17-09-2016",
		                        		"owner"	:  "Admin03",
		                        		"acknowledged":  "yes",
		                        		"escalated" :  "no", 
		                        		"category":  "incident",
		                        		"type"	  : "mild"
		                           }
		                      	                           
		                           ];
		
		this.getAllIncidentReading = function() {
			return incidentAllTableReading;
		};
});



