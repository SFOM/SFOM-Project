app.controller('foodWastageLastWeekCtrl', function($scope, $filter, selLocationService,bioGasGenService) {
	
//	waterGasUsageService.getLastWeekWaterData().then(function (result) {
	var result = angular.copy(bioGasGenService.lastWeekData);
		result.splice(0, 1);
		var today = new Date();
		var dayOfWeek = today.getDay();  //Monday = 1
		dayOfWeek = dayOfWeek - 1; // Exclude today, show data starting from previous day

		// extract data from result
		// if today = 1(Monday) start with 0 th elmt in result array
		// if today = 2(Tuesday) start with 1
		// if today = 3(Wednesday) start with 2 and so on
 
		var lastWeekFoodData = new Array();
		var iStart = dayOfWeek >= 0 ? dayOfWeek: 6;// - 1
		var newDate = new Date(today);
		newDate.setDate(today.getDate() - 1);
		
		for(var count=0; count<7; count++){
			lastWeekFoodData.push( new Array(angular.copy($filter('date')(newDate,'MMM dd')), 
									result[iStart][1], result[iStart][2]));
			//iStart = iStart == 6 ? 0 : iStart+1;
			iStart = iStart == 0 ? 6 : iStart-1;
			newDate.setDate(newDate.getDate() - 1);
		}
		
		lastWeekFoodData = $filter('reverse')(lastWeekFoodData);
		lastWeekFoodData.splice(0, 0, ['Date', 'Canteen1(kg)', 'Canteen2(kg)']);
		console.log(lastWeekFoodData);
		
		var data = new google.visualization.arrayToDataTable(lastWeekFoodData);
		var options = {
	    		title: '', //Last 7 Days
	    		hAxis : {
	    			title : 'Days of week',
	    			//format: 'MMM dd', //'EEE, MMM dd',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'                     
	    			},
	    		},
	    		vAxis : {
	    			title : 'Kg',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'
	    			},
	    		},
	    		colors: [ '#0066CC', '#fba651', '#336600', '#B00' ], // '#4566A3', '#DC3912', '#F98A1A', 
	    		backgroundColor : '#262626',
	    		legend: {position: 'none'},
//	    		seriesType: 'bars',
//	    		isStacked: true,
//	    		chartArea: {left: 50, width:'58%'},
	    		chartArea:{top: 10,left:65, width:'85%',height:'75%' }
	    };
		
	    var chart = {};
	    
	    chart.data = data;
	    chart.options = options;
	    $scope.chart = chart;

//	});
});

app.controller('bioGasLastWeekCtrl', function($scope, $filter, selLocationService, bioGasGenService) {
	
//	waterGasUsageService.getLastWeekWaterData().then(function (result) {
	var result = angular.copy(bioGasGenService.lastWeekData);
		result.splice(0, 1);
		var today = new Date();
		var dayOfWeek = today.getDay();  //Monday = 1
		dayOfWeek = dayOfWeek - 1; // Exclude today, show data starting from previous day
		
		var lastWeekBioGasData = new Array();
		var iStart = dayOfWeek >= 1 ? dayOfWeek: 6;
		var newDate = new Date(today);
		newDate.setDate(today.getDate() - 1);
		
		for(var count=0; count<7; count++){
			lastWeekBioGasData.push( new Array(angular.copy($filter('date')(newDate,'MMM dd')), 
									result[iStart][3]));
			iStart = iStart == 0 ? 6 : iStart-1;
			newDate.setDate(newDate.getDate() - 1);
		}
		
//		console.log(lastWeekBioGasData);
		lastWeekBioGasData = $filter('reverse')(lastWeekBioGasData)
//		console.log(lastWeekBioGasData);
		
		lastWeekBioGasData.splice(0, 0, ['Date', 'Gas generated(cubic meters)']);
		
		var data = new google.visualization.arrayToDataTable(lastWeekBioGasData);
		var options = {
	    		title: '', //Last 7 Days
	    		hAxis : {
	    			title : 'Days of week',
	    			//format: 'MMM dd', //'EEE, MMM dd',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'                     
	    			},
	    		},
	    		vAxis : {
	    			title : 'Cubic Meters',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'
	    			},
	    		},
	    		colors: [ '#0066CC', '#fba651', '#336600', '#B00' ], // '#4566A3', '#DC3912', '#F98A1A', 
	    		backgroundColor : '#262626',
	    		legend: {position: 'none'},
	    		chartArea:{top: 10,left:65, width:'85%',height:'75%' }
	    };
		
	    var chart = {};
	    
	    chart.data = data;
	    chart.options = options;
	    $scope.chart = chart;

//	});
});

/**
 * food Wastage Last MONTH
 */
app.controller('foodWastageLastMonthCtrl', function($scope, $filter, selLocationService,bioGasGenService) {
	
//	waterGasUsageService.getLastWeekWaterData().then(function (result) {
	var result = angular.copy(bioGasGenService.lastMonthData);
		result.splice(0, 1);
		var today = new Date();
		var dayOfWeek = today.getDay();  //Monday = 1
		dayOfWeek = dayOfWeek - 1; // Exclude today, show data starting from previous day
		// extract data from result
		// if dayOfWeek = 1 start with 0 th elmt in result array
		// if dayOfWeek = 2 start with 1
		// if dayOfWeek = 3 start with 2 
		// if dayOfWeek = 4 start with 3 
		// if dayOfWeek = 5 start with 4
		// if dayOfWeek = 6 start with 5 
		// if dayOfWeek = 0 start with 6 
		var lastWeekFoodData = new Array();
		var iStart = dayOfWeek >= 1 ? dayOfWeek: 6;
		var newDate = new Date(today);
		newDate.setDate(today.getDate() - 1);
		
		for(var count=0; count<31; count++){
			lastWeekFoodData.push( new Array(angular.copy($filter('date')(newDate,'dd')), 
									result[iStart][1], result[iStart][2]));
			//iStart = iStart == 30 ? 0 : iStart+1;
			iStart = iStart == 0 ? 30 : iStart-1;
			newDate.setDate(newDate.getDate() - 1);
		}
		
		lastWeekFoodData = $filter('reverse')(lastWeekFoodData);
		lastWeekFoodData.splice(0, 0, ['Date', 'Canteen1(kg)', 'Canteen2(kg)']);
//		console.log(lastWeekFoodData);
		
		var data = new google.visualization.arrayToDataTable(lastWeekFoodData);
		var options = {
	    		title: '', //Last 7 Days
	    		hAxis : {
	    			title : 'Days of month',
	    			//format: 'MMM dd', //'EEE, MMM dd',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'                     
	    			},
	    		},
	    		vAxis : {
	    			title : 'Kg',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'
	    			},
	    		},
	    		colors: [ 'f5620d', '#336600', '#B00' ], // '#4566A3', '#DC3912', '#F98A1A', '#d63303' 
	    		backgroundColor : '#262626',
	    		legend: {position: 'none'},
//	    		seriesType: 'bars',
//	    		isStacked: true,
//	    		chartArea: {left: 50, width:'58%'},
	    		chartArea:{top: 10,left:65, width:'85%',height:'75%' }
	    };
		
	    var chart = {};
	    
	    chart.data = data;
	    chart.options = options;
	    $scope.chart = chart;

//	});
});

/**
 * Bio Gas Last MONTH
 */
app.controller('bioGasLastMonthCtrl', function($scope, $filter, selLocationService, bioGasGenService) {
	
//	waterGasUsageService.getLastWeekWaterData().then(function (result) {
	var result = angular.copy(bioGasGenService.lastMonthData);
		result.splice(0, 1);
		var today = new Date();
		var dayOfWeek = today.getDay();  //Monday = 1
		dayOfWeek = dayOfWeek - 1; // Exclude today, show data starting from previous day
		
		var lastWeekBioGasData = new Array();
		var iStart = dayOfWeek >= 1 ? dayOfWeek: 6;
		var newDate = new Date(today);
		newDate.setDate(today.getDate() - 1);
		
		for(var count=0; count<31; count++){
			lastWeekBioGasData.push( new Array(angular.copy($filter('date')(newDate,'dd')), 
									result[iStart][3]));
			//iStart = iStart == 30 ? 0 : iStart+1;
			iStart = iStart == 0 ? 30 : iStart-1;
			newDate.setDate(newDate.getDate() - 1);
		}
		
//		console.log(lastWeekBioGasData);
		lastWeekBioGasData = $filter('reverse')(lastWeekBioGasData)
//		console.log(lastWeekBioGasData);
		
		lastWeekBioGasData.splice(0, 0, ['Date', 'Gas generated(cubic meters)']);
		
		var data = new google.visualization.arrayToDataTable(lastWeekBioGasData);
		var options = {
	    		title: '', //Last 7 Days
	    		hAxis : {
	    			title : 'Days of month',
	    			//format: 'MMM dd', //'EEE, MMM dd',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'                     
	    			},
	    		},
	    		vAxis : {
	    			title : 'Cubic Meters',
	    			textStyle : {
	    				color : '#fff'
	    			},
	    			titleTextStyle : {
	    				color : '#fff'
	    			},
	    		},
	    		colors: [ '#336600' ], // '#4566A3', '#DC3912', '#F98A1A', 
	    		backgroundColor : '#262626',
	    		legend: {position: 'none'},
	    		chartArea:{top: 10,left:65, width:'85%',height:'75%' }
	    };
		
	    var chart = {};
	    
	    chart.data = data;
	    chart.options = options;
	    $scope.chart = chart;

//	});
});

app.filter('reverse', function() {
	  return function(items) {
	    return items.slice().reverse();
	  };
	});
