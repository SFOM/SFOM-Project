app.controller('occupancyAnalysisCtrl', function($scope, $filter, $state) {

	/**
	 * handles side bar menu
	 * 
	 * Code taken from : https://angular-ui.github.io/bootstrap/
	 */

	$scope.groups = [
	                 {
	                	 title: 'OccupancyAnalysisMonthly',
	                	 link: 'occupancyAnalysis.occupancyAnalysisMonthly',
	                	 isOpen: false
	                 },
	                 {
	                	 title: 'OccupancyHeatMap',
	                	 link: 'occupancyAnalysis.occupancyAnalysisHeatMap',
	                	 isOpen: true
	                 },
	                 {
	                	 title: 'OccupancyAnalysisWeekly',
	                	 link: 'occupancyAnalysis.occupancyAnalysisWeekly',
	                	 isOpen: false
	                 }
	                 ];

	$scope.status = {
			isFirstOpen: true,
			isFirstDisabled: false
	};

	// Default: open  '  by default when 
	$state.go('occupancyAnalysis.occupancyAnalysisHeatMap');
	// Another redirection code:
	//http://stackoverflow.com/questions/29491079/redirect-a-state-to-default-substate-with-ui-router-in-angularjs
	//http://stackoverflow.com/questions/24960288/angular-js-ui-router-how-to-redirect-to-a-child-state-from-a-parent
	//http://plnkr.co/edit/I88iqp7bElh1wNgBGU9f?p=preview
});







