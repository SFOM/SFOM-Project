app.controller('occupancyAnalysisHeatMapCtrl', function($scope, $filter, selLocationService, occupancyAnalysisService) {
$scope.viewDataModel = 0;      // default value
	
	
	// get data
	$scope.floorMapList = occupancyAnalysisService.floorMapList;
	$scope.meterCoordinates = occupancyAnalysisService.meterCoordinates;
	$scope.occupancyData = occupancyAnalysisService.occupancyData;
	
	
	
	
	/** Assumption : showing Occupancy , 
	 * Range: 0 to 50 - green,  50 to 150 - yellow, Above 150 - Red
	 */
	var getZoneBorderColor = function(varOccupancy){
		if(varOccupancy == "" || varOccupancy == undefined){
			return '#5276b3';
		} else if(varOccupancy > 0 && varOccupancy <= 50){
			return '#319831'; //'rgba(0, 255, 0, 1)';
		}else if(varOccupancy > 50 && varOccupancy <= 150){
			return 'rgba(255, 194, 0, 1)';
		}else if(varOccupancy > 150){
			return 'rgba(255, 0, 0, 1)';
		}
	};
	
	/** Assumption : showing Occupancy , 
	 * Range: 0 to 50 - green,  50 to 150 - yellow, Above 150 - Red
	 */
	var getZoneConsumptionColor = function(varOccupancy){
		if(varOccupancy == "" || varOccupancy == undefined){
			return '#6ea0f5';
		} else if(varOccupancy > 0 && varOccupancy <= 50){
			return 'rgba(20, 204, 20, 0.6)'; //'rgba(49, 150, 49, 0.5)';
		}else if(varOccupancy > 50 && varOccupancy <= 150){
			return 'rgba(255, 194, 0, 0.7)';
		}else if(varOccupancy > 150){
			return 'rgba(255, 0, 0, 0.6)';
		}
	};
	
	var drawRectangle = function(ctx, varOccupancy, varCoordinates){
		ctx.beginPath();
		ctx.rect(varCoordinates.rectX, varCoordinates.rectY, varCoordinates.width, varCoordinates.height);
		//ctx.rect(x, y, width, height);
		ctx.fillStyle = 'rgba(255,255,255,0)'; // transparent
		ctx.fill();
		ctx.lineWidth = 3;
		ctx.strokeStyle = getZoneBorderColor(varOccupancy);
		ctx.stroke();
	};
	
	var drawCircle = function(ctx, varOccupancy, varCoordinates){
		var maxRadius = 27;
		var radius = varCoordinates.height < varCoordinates.width? varCoordinates.height:varCoordinates.width;
		radius = maxRadius > radius/4? radius/4:maxRadius;
		var lineWidth = radius > 7?  radius - 7: 1; 
		ctx.beginPath();
	    ctx.arc(varCoordinates.crlX, varCoordinates.crlY, radius, 0, 2 * Math.PI, false);
	    //ctx.arc(x, y, radius, startAngle, endAngle, counterClockwise);
	    ctx.fillStyle ='rgba(255,255,255,0)'; // transparent
	    ctx.fill();
	    ctx.lineWidth = lineWidth; //20;
	    ctx.strokeStyle = getZoneConsumptionColor(varOccupancy);
	    ctx.stroke();
	};
	
	var createTooltip = function(evt, canvas, filteredMeterOccupancy, tipCanvas, tipCtx){
        
		var rect = canvas.getBoundingClientRect();
		var mouseX = evt.clientX - rect.left;
		var mouseY =  evt.clientY - rect.top;
	    
		var tipCanvasLeft = evt.clientX - rect.left + canvas.offsetLeft;
		var tipCanvasTop = evt.clientY - rect.top + canvas.offsetTop;
        var tooltipCurrent = '', tooltipMin = '', tooltipMax = '';
        
        angular.forEach(filteredMeterOccupancy, function(iVal, iIdx){
        	if(mouseX > iVal.rectX && mouseX < iVal.rectX +  iVal.width && mouseY > iVal.rectY && mouseY < iVal.rectY +  iVal.height){
        		if(iVal.current == "" || iVal.current == undefined){ 
        			tooltipCurrent = 'Data';
        			tooltipMin = 'Not'; 
        			tooltipMax = 'Available';
        		} else {
        			tooltipCurrent = 'Current: ' + iVal.current;
        			tooltipMin = 'Min: ' + iVal.Min; 
        			tooltipMax = 'Max: ' + iVal.Max; 
        		}
        	}
  
            if(tooltipCurrent == ''){
            	tipCanvas.style.left = "-200px";
            } else {
	            tipCanvas.style.left = (tipCanvasLeft + 5) + "px"; //(evt.clientX + 05) + "px";
	            tipCanvas.style.top = (tipCanvasTop + 5) + "px"; //(evt.clientY + 10) + "px";
	            tipCtx.clearRect(0, 0, tipCanvas.width, tipCanvas.height);
	            
	            tipCtx.fillStyle = '#fff';//'#000'; //'#0099f9';
	            tipCtx.font = 'bold 11px arial'; //  'normal 12px arial';
	            tipCtx.fillText(tooltipCurrent, 10, 15);
	            tipCtx.fillText(tooltipMin, 10, 30);
	            tipCtx.fillText(tooltipMax, 10, 45);
            }
        });
	};
	/**** END - Supporting Functions ****/
	
	
	/**** Floor wise heat map  ****/
	var drawFloorWiseHeatmap = function(selectedLocation){
		var canvas = document.getElementById('canvasFloorMap');
		var ctx = document.getElementById('canvasFloorMap').getContext('2d');
		
		var tipCanvas = document.getElementById('tooltipCanvas');
		var tipCtx = tipCanvas.getContext('2d');
		
		var background = new Image();
		
		var floorMapLink =  ($filter('filter')($scope.floorMapList, 
				{locId:selectedLocation[0], subLocId:selectedLocation[1], floorId:selectedLocation[2]}))[0].floorMap;
		
		// change background floor wise
		background.src = floorMapLink;

		background.onload = function(){
		    ctx.drawImage(background,0,0);   
		    
		    // get meterId list from meterCoordinates with floor filter
		    
		    
		    // for each meter, filter occupancyData for today till current time
		    // take 3 values (1) current (2) Max (3) Min
		    var filteredMeterOccupancy = new Array();
		    var floorOccupancyMeters = $filter('filter')($scope.meterCoordinates, 
					{locId:selectedLocation[0], subLocId:selectedLocation[1], floorId:selectedLocation[2]});
		    
		    angular.forEach(floorOccupancyMeters, function(iValue, iIndex){
		    	var coordinatesData = iValue;
		    	
		    	var today = new Date();
		    	//******** need to update as per data source - START  ********//
		    	///// set according to data , need to update when correct data received
		    	var todayFormatted = $filter('date')(today,'yyyy-06-dd');   
		    	//console.log(iValue);
		    	var meterOccupancyData = ($filter('filter')($scope.occupancyData, 
						{	meterId: iValue.meterId, dateTime: todayFormatted }));
		    	
		    	
		    	//console.log(meterOccupancyData);
		    	//******** need to update as per data source - END  ********//
		    	var currentOccupancy, min = 25000, max = 0;
		    	
		    	if(meterOccupancyData.length > 0){
			    	angular.forEach(meterOccupancyData, function(val, idx){
			    		// check till current time
			    		var rowDateTime = new Date((today.getMonth()+1) + "/" + today.getDate() + "/" + today.getFullYear() + 
								" " + val.dateTime.split(" ")[1]); 
			    		if(rowDateTime < today){   
			    			// instead above condition can be modified to check time difference between last reading and 
			    			// current time is less than 1 hour to make sure that it is latest reading received  
			    			currentOccupancy = Number(val.occupancy);
			    			min = val.occupancy < min ? Number(val.occupancy) : min;
			    			max = val.occupancy > max ? Number(val.occupancy) : max;
			    		}
			    	});
		    	} else {
		    		currentOccupancy = ""; min = ""; max = "";
		    	}
	    		
		    	drawRectangle(ctx, currentOccupancy, iValue);
				///////   crlX = width/2 + rectX, crlY = height/2 + rectY
		    	if(currentOccupancy != "" && currentOccupancy != undefined){
		    		drawCircle(ctx, currentOccupancy, iValue);
		    	}
				
		    	filteredMeterOccupancy.push( { meterId: iValue.meterId, 
		    									current: currentOccupancy, Min: min, Max: max,
		    									rectX:iValue.rectX, rectY:iValue.rectY, width:iValue.width, 
		    									height:iValue.height, crlX:iValue.crlX, crlY:iValue.crlY } );
		    									
		    });
		    
		   // console.log(filteredMeterOccupancy);
		    
		    
		    
		    
			canvas.addEventListener('mousemove', function(evt) {
				createTooltip(evt, canvas, filteredMeterOccupancy, tipCanvas, tipCtx);
			}, false); // END - addEventListener
		}
	}
		
	$scope.$watch(function(){ return selLocationService.selLocation; }, function() {
		var selectedLocation = selLocationService.getSelFloor();   
		drawFloorWiseHeatmap(selectedLocation);
	}); // END- $watch

	$scope.$watch('[ZoneId_lastMonth]', function() {
		var selectedLocation = selLocationService.getSelFloor();
		drawFloorWiseHeatmap(selectedLocation);
	}); 
	
	/*drawFloorWiseHeatmap(selectedLocation);*/
});
	
