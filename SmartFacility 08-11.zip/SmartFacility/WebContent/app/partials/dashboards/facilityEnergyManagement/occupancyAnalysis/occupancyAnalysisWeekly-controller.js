/******************------$$$$$$$$$$$$$$------############------############------$$$$$$$$$$$$$$------******************/
	
	/*********************************************************************************
	 *  Draw bar chart for min and max occupancy  for Last 7 days 
	 */
app.controller('occupancyWeeklyAnalysisCtrl', function($scope, $filter, selLocationService, occupancyAnalysisService) {
	
	$scope.floorMapList = occupancyAnalysisService.floorMapList;
	$scope.meterCoordinates = occupancyAnalysisService.meterCoordinates;
	$scope.occupancyData = occupancyAnalysisService.occupancyData;
	var selectedLocation = selLocationService.getSelFloor();   	
    
	var generateFloorwiseWeeklyOccupancyChart = function(selectedLocation){
		//var filteredMeterOccupancy = new Array();
		var floorOccupancyMeters = $filter('filter')($scope.meterCoordinates, 
				{locId:selectedLocation[0], subLocId:selectedLocation[1], floorId:selectedLocation[2]});

		$scope.lblZoneId= new Array();

		var floorZoneWiseOccupancyWeeklyData = new Array();

		angular.forEach(floorOccupancyMeters,function(floorValue,key){


			$scope.lblZoneId.push(floorValue.meterId);

			//var floorOccupancyData = new Array();

			var newDate = new Date(); 
			var todayFormatted ;
			/*newDate.setDate(today.getDate() - 1);
			todayFormatted = $filter('date')(newDate,'yyyy-06-dd');*/
			//var total = 0 , min = 0, max = 0;

			for(var i= 0 ; i < 7 ; i ++ ){

				var	total =  min =  max = 0;

				newDate.setDate(newDate.getDate() - 1);
				todayFormatted = $filter('date')(newDate,'yyyy-06-dd');

				var floorZoneWiseOccupancyData = ($filter('filter')($scope.occupancyData, 
						{	meterId:floorValue.meterId , dateTime:todayFormatted }));

			    
				//console.log(floorZoneWiseOccupancyData);
				console.log(floorValue.meterId);
				console.log(todayFormatted);
				max = min =  Number(floorZoneWiseOccupancyData[0].occupancy);
				//min = Number(floorZoneWiseOccupancyData[0].occupancy);
				
				for(var j =1 ; j < floorZoneWiseOccupancyData.length ;  j++){
                     
					total += parseInt( floorZoneWiseOccupancyData[j].occupancy);
					min = Number(floorZoneWiseOccupancyData[j].occupancy) < min ? Number(floorZoneWiseOccupancyData[j].occupancy) : min;
					max = Number(floorZoneWiseOccupancyData[j].occupancy) > max ? Number(floorZoneWiseOccupancyData[j].occupancy) : max;
				}


				//console.log("date  " +  newDate +"   Zone Id " + floorValue.meterId + "  total " + total + "  min  " + min + "  max  " + max  );
				floorZoneWiseOccupancyWeeklyData.push({ date:$filter('date')(newDate,'MMM dd'), meterId:floorValue.meterId , avg:total/floorZoneWiseOccupancyData.length , min:min , max:max});
			}

		});

		//var filteredZoneWiseOccupancy = new Array();

		var filteredZoneWiseOccupancy = ($filter('filter')(floorZoneWiseOccupancyWeeklyData, 
				{	meterId:$scope.lblZoneId[$scope.ZoneId_lastWeek]  }));

		var filteredfloorZoneWiseOccupancyWeeklyData = new Array();

		angular.forEach(filteredZoneWiseOccupancy,function(floorValue,key){
			filteredfloorZoneWiseOccupancyWeeklyData.push(new Array(floorValue.date , floorValue.min , floorValue.max ,floorValue.avg));
		});

		//console.log(filteredfloorZoneWiseOccupancyWeeklyData);

		filteredfloorZoneWiseOccupancyWeeklyData.splice(0, 0, ['Date', 'Min' , 'Max' ,'Average']);

		console.log(filteredfloorZoneWiseOccupancyWeeklyData);
		var data = new google.visualization.arrayToDataTable(filteredfloorZoneWiseOccupancyWeeklyData);


		var options = {
				title: '', //Last 7 Days
				hAxis : {
					title : 'Days of week',
					//format: 'MMM dd', //'EEE, MMM dd',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'                     
					},
				},
				vAxis : {
					title : 'Occupancy',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				colors: [ '#0066CC', '#fba651', '#336600', '#B00' ], // '#4566A3', '#DC3912', '#F98A1A', 
				backgroundColor : '#262626',
				legend: {position: 'none'},
				seriesType: 'bars',
				series: {2: {type: 'line'}},

//				isStacked: true,
//				chartArea: {left: 50, width:'58%'},
				chartArea:{top: 10,left:65, width:'90%',height:'75%' }
		};
		   
		   var chart = {};

		   chart.data = data;
		    chart.options = options;
		    $scope.chart = chart;
	
	}
	
	$scope.$watch(function(){ return selLocationService.selLocation; }, function() {
		$scope.ZoneId_lastWeek = '0';
		var selectedLocation = selLocationService.getSelFloor();   
		generateFloorwiseWeeklyOccupancyChart(selectedLocation);
	}); // END- $watch

	$scope.$watch('[ZoneId_lastWeek]', function() {
		var selectedLocation = selLocationService.getSelFloor();
		generateFloorwiseWeeklyOccupancyChart(selectedLocation);
	}); 
	
	generateFloorwiseWeeklyOccupancyChart(selectedLocation);
});