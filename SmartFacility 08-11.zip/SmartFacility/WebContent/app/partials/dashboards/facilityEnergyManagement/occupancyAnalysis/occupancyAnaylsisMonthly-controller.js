
/*********************************************************************************
 *  Draw bar chart for min and max occupancy  for Last 30 days 
 */
app.controller('occupancyMonthlyAnalysisCtrl', function($scope, $filter, selLocationService, occupancyAnalysisService) {

	$scope.floorMapList = occupancyAnalysisService.floorMapList;
	$scope.meterCoordinates = occupancyAnalysisService.meterCoordinates;
	$scope.occupancyData = occupancyAnalysisService.occupancyData;
	var selectedLocation = selLocationService.getSelFloor();   
	
	var generateFloorwiseMonthlyOccupancyChart = function(selectedLocation){
	console.log($scope.ZoneId_lastMonth);

	var floorOccupancyMeters = $filter('filter')($scope.meterCoordinates, 
			{locId:selectedLocation[0], subLocId:selectedLocation[1], floorId:selectedLocation[2]});

	console.log("floorOccupancyMeters" +floorOccupancyMeters);

	$scope.lblZoneIdMonth= new Array();

	var floorZoneWiseOccupancyMonthlyData = new Array();

	var count = 0 ;
	angular.forEach(floorOccupancyMeters,function(floorValue,key){
		var newDate = new Date(); 
		var todayFormatted ;
		$scope.lblZoneIdMonth.push(floorValue.meterId);

		//console.log(floorValue.meterId);
		/*newDate.setDate(today.getDate() - 1);
			todayFormatted = $filter('date')(newDate,'yyyy-06-dd');*/
		//var total = 0 , min = 0, max = 0;
		for(var i= 0 ; i < 30 ; i ++ ){

			var	  min =  max = 0;

			newDate.setDate(newDate.getDate() - 1);

			if(newDate.getDate() == 31)
			{
				var tempDate = new Date();
				tempDate.setDate(newDate.getDate() - 1);
				todayFormatted = $filter('date')(tempDate,'yyyy-06-dd');
			}
			else
				todayFormatted = $filter('date')(newDate,'yyyy-06-dd');

			var floorZoneWiseOccupancyData = ($filter('filter')($scope.occupancyData, 
					{	meterId:floorValue.meterId , dateTime:todayFormatted }));


			max =  min = Number(floorZoneWiseOccupancyData[0].occupancy);

			var maxDateTime = minDateTime = floorZoneWiseOccupancyData[0].dateTime;
			for(var j =1 ; j < floorZoneWiseOccupancyData.length ;  j++){

				/*if(Number(floorZoneWiseOccupancyData[j].occupancy) < min )
						minTime = floorZoneWiseOccupancyData[j].dateTime;
					if(Number(floorZoneWiseOccupancyData[j].occupancy) > max )
						maxTime = floorZoneWiseOccupancyData[j].dateTime;*/

				minDateTime = Number(floorZoneWiseOccupancyData[j].occupancy) <= minDateTime ?  floorZoneWiseOccupancyData[j].dateTime : minDateTime;
				min = Number(floorZoneWiseOccupancyData[j].occupancy) < min ? Number(floorZoneWiseOccupancyData[j].occupancy) : min;

				maxDateTime = Number(floorZoneWiseOccupancyData[j].occupancy) > max ?  floorZoneWiseOccupancyData[j].dateTime : maxDateTime;
				max = Number(floorZoneWiseOccupancyData[j].occupancy) > max ? Number(floorZoneWiseOccupancyData[j].occupancy) : max;
			}

			var maxTime = maxDateTime.split(" ")[1];
			var minTime = minDateTime.split(" ")[1];
			//console.log("date  " +  newDate +"   Zone Id " + floorValue.meterId +  "  min  " + min + "  max  " + max  );
			floorZoneWiseOccupancyMonthlyData.push({ ReadingDate:$filter('date')(newDate,'MMM dd'), meterId:floorValue.meterId ,  min:min ,  minTime : minTime , max:max , maxTime : maxTime});
		}

	});
//	console.log(floorZoneWiseOccupancyMonthlyData);
//	console.log($scope.ZoneId_lastMonth);
//	console.log($scope.lblZoneIdMonth[$scope.ZoneId_lastMonth]);
	$scope.filteredZoneWiseOccupancy = ($filter('filter')(floorZoneWiseOccupancyMonthlyData, 
			{	meterId:$scope.lblZoneIdMonth[$scope.ZoneId_lastMonth]  }));

	console.log($scope.filteredZoneWiseOccupancy);


	$scope.occupancyGridOptions = { data: 'filteredZoneWiseOccupancy',
			columnDefs: [
			             {field:'ReadingDate', displayName:'Date', headerCellClass:'ui-grid-header-cell-blue'},
//			             {field:'meterId', displayName:'MeterId', headerCellClass:'ui-grid-header-cell-blue'},
			             {field:'min', displayName:'Minimum Occupancy', headerCellClass:'ui-grid-header-cell-blue'}, 
			             {field:'minTime', displayName:'Time of Minimum Occupancy', headerCellClass:'ui-grid-header-cell-blue'}, 
			             {field:'max', displayName:'Maximum Occupancy', headerCellClass:'ui-grid-header-cell-blue'},
			             {field:'maxTime', displayName:'Time of Maximum Occupancy', headerCellClass:'ui-grid-header-cell-blue'}
			             ]                    

	};  
	
	}
	
	$scope.$watch(function(){ return selLocationService.selLocation; }, function() {
		$scope.ZoneId_lastMonth = '0';
		var selectedLocation = selLocationService.getSelFloor();   
		generateFloorwiseMonthlyOccupancyChart(selectedLocation);
	}); // END- $watch

	$scope.$watch('[ZoneId_lastMonth]', function() {
		var selectedLocation = selLocationService.getSelFloor();
		generateFloorwiseMonthlyOccupancyChart(selectedLocation);
	}); 
	
	generateFloorwiseMonthlyOccupancyChart(selectedLocation);
});