app.service('weatherapiService', function($http) {
   this.getWeatherApiData= function() { 
    	var response = $http.get('http://api.openweathermap.org/data/2.5/weather?q=Pune&APPID=2d075d1e3b63eb6a21e9f3bd5eb6aed7');
    	return( response.then( function(data) {
    	  var result = data;
//    	  console.log(result);
    	  return result.data;
    	
    	  }, 
    	  function(data, status, headers, config) {
        	  alert("AJAX failed to get data, status=" + status);
        	}) );
	}

});


app.service('maintainanceStaffService', function(){
	
	this.getWeeklyTemp= function(dayArr)
	{
		var WeeklyTempArr = new Array();
		console.log("dayArr = "+ dayArr);

		WeeklyTempArr = [ [ (dayArr[6]).toString(), 22.5 ],
							[ (dayArr[5]).toString(), 21.7 ],
							[ (dayArr[4]).toString(), 23.3 ],
							[ (dayArr[3]).toString(), 21.9 ],
							[ (dayArr[2]).toString(), 22.8 ],
							[ (dayArr[1]).toString(), 23.1 ],
							[ (dayArr[0]).toString(), 21.6 ], ];
		
		return WeeklyTempArr;
		
	}
	
	
});
