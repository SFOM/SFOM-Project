app.service('energyManagerDashboardService', function() {
	
	
	this.getWeeklyEnergyConsm= function(dayArr)
	{
		var sevenDaysEnergyConsm = new Array();
		console.log("dayArr = "+ dayArr);
	
		sevenDaysEnergyConsm = [ [ (dayArr[6]).toString(), 10304.5 ],
		 						[ (dayArr[5]).toString(), 3710.8 ],
								[ (dayArr[4]).toString(), 6300.3 ],
								[ (dayArr[3]).toString(), 10999.1 ],
								[ (dayArr[2]).toString(), 9660.25],
								[ (dayArr[1]).toString(), 9506.58 ],
								[ (dayArr[0]).toString(), 9940.52 ], ];
		
		return sevenDaysEnergyConsm;
		
	}
	
	
	this.getWeeklyConsCost= function(dayArr)
	{
		var sevenDaysConsCost = new Array();
		console.log("dayArr = "+ dayArr);
	
		sevenDaysConsCost = [ [ (dayArr[6]).toString(), 61824 ],
									[ (dayArr[5]).toString(), 22260 ],
									[ (dayArr[4]).toString(), 37800 ],
									[ (dayArr[3]).toString(), 65994 ],
									[ (dayArr[2]).toString(), 57960 ],
									[ (dayArr[1]).toString(), 57036 ],
									[ (dayArr[0]).toString(), 59640 ], ];
		
		return sevenDaysConsCost;
		
	}
	

});