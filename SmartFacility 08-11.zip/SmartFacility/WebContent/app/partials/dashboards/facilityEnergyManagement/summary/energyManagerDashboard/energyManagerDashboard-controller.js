app.controller('energyManagerDashboardCtrl', function($scope) {

		
});

app.controller('enrMgrDashColConsChartCntr1', function($scope, energyManagerDashboardService) {
		
	drawConsumpColumnChart();
	
	function drawConsumpColumnChart() {
		var curDate = new Date();
		var day = curDate.getDate();
		var dayArr = [];
		var i = 1;
		var j = 1;
		var day1 = curDate.getDate();
		var month = curDate.getMonth();
		var month1 = curDate.getMonth();
		var monthArr = [];
		var monthArr1 = [];
		var monthNames = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
				"Aug", "Sep", "Oct", "Nov", "Dec", "Jan" ];
		for (; i < 30;) {
			if (day1 == 1) {
				day = 31;
				i = 1;
			}
			dayArr.push(day1);
			day1 = day - i;
			i++;
		}

		for (; j < 10;) {
			if (month1 == 1) {
				month = 13;
				j = 1;
			}

			monthArr.push(month1);
			monthArr1.push(monthNames[month1]);
			month1 = month - j;
			j++;
		}

		try {
			    var curDate = new Date();
				var data = new google.visualization.DataTable();
				data.addColumn('string', 'Days of Month');
				data.addColumn('number', 'kWh');

				var todayDay = curDate.getDate();
				var consWeek = energyManagerDashboardService.getWeeklyEnergyConsm(dayArr);
				data.addRows(consWeek);
				
				/*data.addRows([ [ (dayArr[6]).toString(), 10304.5 ],
						[ (dayArr[5]).toString(), 3710.8 ],
						[ (dayArr[4]).toString(), 6300.3 ],
						[ (dayArr[3]).toString(), 10999.1 ],
						[ (dayArr[2]).toString(), 9660.25],
						[ (dayArr[1]).toString(), 9506.58 ],
						[ (dayArr[0]).toString(), 9940.52 ], ]);*/

				var options = {
					title : '',
					 is3D:true,					 
					legend : {
						position : 'none'
					},
					hAxis : {
						title : 'Days of Month',
						textStyle : {
							color : '#fff'
						},
						titleTextStyle : {
							color : '#fff'                     //    777D06
						},
					},
					vAxis : {
						title : 'kWh',
						textStyle : {
							color : '#fff'
						},
						titleTextStyle : {
							color : '#fff'
						},
					},
					backgroundColor : '#262626',    
					colors : [ '#4566A3' ],			//#AD2626		
					chartArea:{top: 10,left:65, width:'85%',height:'75%' }
				};

			var chart = new google.visualization.ColumnChart(document.getElementById("consColChart"));
			chart.draw(data, options);

		} catch (err) {
			alert("An error occured in Charts.\n" + err.message());
		}
	}	
});



app.controller('enrMgrDashCostColChartCntr2', function($scope, energyManagerDashboardService) {
		
	    drawCostColumnChart();
	    
		function drawCostColumnChart() {
			var curDate = new Date();
			var day = curDate.getDate();
			var dayArr = [];
			var i = 1;
			var j = 1;
			var day1 = curDate.getDate();
			var month = curDate.getMonth();
			var month1 = curDate.getMonth();
			var monthArr = [];
			var monthArr1 = [];
			var monthNames = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
					"Aug", "Sep", "Oct", "Nov", "Dec", "Jan" ];
			for (; i < 30;) {
				if (day1 == 1) {
					day = 31;
					i = 1;
				}
				dayArr.push(day1);
				day1 = day - i;
				i++;
			}

			for (; j < 10;) {
				if (month1 == 1) {
					month = 13;
					j = 1;
				}

				monthArr.push(month1);
				monthArr1.push(monthNames[month1]);
				month1 = month - j;
				j++;
			}

			try {
				    var curDate = new Date();
					var data = new google.visualization.DataTable();
					data.addColumn('string', 'Days of Month');
					data.addColumn('number', 'Rupees');

					var todayDay = curDate.getDate();
					
					var costWeek = energyManagerDashboardService.getWeeklyConsCost(dayArr);
					data.addRows(costWeek);
					
					
					/*data.addRows([ [ (dayArr[6]).toString(), 61824 ],
							[ (dayArr[5]).toString(), 22260 ],
							[ (dayArr[4]).toString(), 37800 ],
							[ (dayArr[3]).toString(), 65994 ],
							[ (dayArr[2]).toString(), 57960 ],
							[ (dayArr[1]).toString(), 57036 ],
							[ (dayArr[0]).toString(), 59640 ], ]);*/

					var options = {
						title : '',
						 is3D:true,
						legend : {
							position : 'none'
						},
						hAxis : {
							title : 'Days of Month',
							textStyle : {
								color : '#fff'
							},
							titleTextStyle : {
								color : '#fff'
							},
						},
						vAxis : {
							title : 'Cost',
							textStyle : {
								color : '#fff'
							},
							titleTextStyle : {
								color : '#fff'
							},
						},
						backgroundColor : '#262626',
						colors : [ '#A19564' ],				  //#027514    777D06   529E69	
						chartArea:{top: 10,left:65,
				        	width:'85%',height:'75%'
				        		}
					};

				var chart = new google.visualization.ColumnChart(document.getElementById("costColChart"));
				chart.draw(data, options);

			} catch (err) {
				alert("An error occured in Charts.\n" + err.message());
			}
		}	
	});


app.controller('GaugePeakCtrl3', function($scope) {

		var chartSource = new Array([ 'Label', 'Value' ], [ 'MW', 12.20] );
		var data = new google.visualization.arrayToDataTable(chartSource);

		var options = {
			label : {
				position : 'bottom'
			},
			width: 175, height: 175,
			top: 100,left:2000,
			greenFrom : 0,
			greenTo : 10,
			redFrom : 20,
			redTo : 30,
			yellowFrom : 10,
			yellowTo : 20,
			minorTicks : 30,
			max : 30,
			min : 0,
   		
		};

		var chart = {};

		chart.data = data;
		chart.options = options;
		$scope.chart = chart;

});









