app.controller('executiveDashboardCtrl', function($scope) {

});

app.controller('exeDashboardCtrl', function($scope, fwdFloorService,
		exeDashboardService) {

//	console.log("In exeDashboardCtrl");

	chosedFloor = fwdFloorService.getSelFloor();
	deviceCount = fwdFloorService.getDeviceCount();

	if (chosedFloor == undefined) {
		chosedFloor = 1;
	}

	if (deviceCount == undefined) {
		deviceCount = 4;
	}


	var ArrayOfCosts = exeDashboardService.getCostData(chosedFloor);
	var ArrayOfCosts = exeDashboardService.getCostData();

	$scope.exeDashboardVal = ArrayOfCosts;

});