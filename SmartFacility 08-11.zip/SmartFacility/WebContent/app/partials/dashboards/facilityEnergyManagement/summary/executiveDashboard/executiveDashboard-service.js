app.service('exeDashboardService', function() {
	

		this.getCostData = function(floorVal){
		console.log(floorVal);
		
	
	var ArrayOfCosts={};
	
	
	ArrayOfCosts=[ {heading: "Overall Cost- 7 Days", subHeading: "Last 7 Days", val1: "48.25 K"},	    	            	                   
	               {heading: "Overall Cost- Last Week", subHeading: "Last Week", val1: "50.12 K"},
	               {heading: "Overall Cost- 28 Days", subHeading: "Last 28 Days", val1: "198.72 K"},
	               {heading: "Overall Cost- Last Month", subHeading: "Last Month", val1: "202.54 K"}
	               ];
	
	/*{heading: "Overall Cost- 7 Days", subHeading: "Last 7 Days", val1: "402.25", perc:"-03"},*/
	
	
	console.log(ArrayOfCosts);
	
  	 return ArrayOfCosts;
  	 
  	
	
	}

});







































