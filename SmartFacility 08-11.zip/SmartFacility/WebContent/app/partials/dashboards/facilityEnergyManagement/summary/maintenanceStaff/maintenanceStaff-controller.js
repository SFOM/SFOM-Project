app.controller('maintenanceStaffCtrl', function($scope) {
		
});

app.controller('mainStaffLineChartCntr', function($scope, maintainanceStaffService) {
	
    drawMainStaffAvgTempLineChart();
    
	function drawMainStaffAvgTempLineChart() {
		var curDate = new Date();
		var day = curDate.getDate();
		var dayArr = [];
		var i = 1;
		var j = 1;
		var day1 = curDate.getDate();
		var month = curDate.getMonth();
		var month1 = curDate.getMonth();
		var monthArr = [];
		var monthArr1 = [];
		var monthNames = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
				"Aug", "Sep", "Oct", "Nov", "Dec", "Jan" ];
		for (; i < 30;) {
			if (day1 == 1) {
				day = 31;
				i = 1;
			}
			dayArr.push(day1);
			day1 = day - i;
			i++;
		}

		for (; j < 10;) {
			if (month1 == 1) {
				month = 13;
				j = 1;
			}

			monthArr.push(month1);
			monthArr1.push(monthNames[month1]);
			month1 = month - j;
			j++;
		}

		try {
			    var curDate = new Date();
				var data = new google.visualization.DataTable();
				data.addColumn('string', 'Days of week');
				data.addColumn('number', 'Average Temperature');

				var todayDay = curDate.getDate();
				
				var avgTempWeek = maintainanceStaffService.getWeeklyTemp(dayArr);
				data.addRows(avgTempWeek);
				
				/*data.addRows([ [ (dayArr[6]).toString(), 22.5 ],
						[ (dayArr[5]).toString(), 21.7 ],
						[ (dayArr[4]).toString(), 23.3 ],
						[ (dayArr[3]).toString(), 21.9 ],
						[ (dayArr[2]).toString(), 22.8 ],
						[ (dayArr[1]).toString(), 23.1 ],
						[ (dayArr[0]).toString(), 21.6 ], ]);*/

				var options = {
					title : '',
					 is3D:true,
					// curveType: 'function',
					legend : {
						position : 'none'
					},
					hAxis : {
						title : 'Days of week',
						textStyle : {
							color : '#fff'
						},
						titleTextStyle : {
							color : '#fff'
						},
					},
					vAxis : {
						title : 'Average Temperature',
						textStyle : {
							color : '#fff'
						},
						titleTextStyle : {
							color : '#fff'
						},
					},
					backgroundColor : '#262626',
					colors : [ '#4566A3' ],					
					chartArea:{top: 10,left:55,
			        	width:'85%',height:'75%'
			        		}
				};

			var chart = new google.visualization.LineChart(document.getElementById("avgTempLineChart"));
			chart.draw(data, options);

		} catch (err) {
			alert("An error occured in Charts.\n" + err.message());
		}
	}	
});


app.controller('mainStaffSuppDemdLineChartCntr', function($scope) {
	
    drawMainStaffSuppDemdLineChart();
    
	function drawMainStaffSuppDemdLineChart() {

		var tm = new Date();
		var hr = tm.getHours();
		var dayCom = new Array();
		var hrVal = new Array();
		var valArr = new Array();
		var data = new google.visualization.DataTable();
		data.addColumn('string', 'Demand');
		data.addColumn('number', 'Supply');

		try {
			for (var m = hr; m >= 0; m--) {

				var y = Math.floor((Math.random() * 15) + 1);

				dayCom[m] = y;
				hrVal[m] = m.toString();
				valArr[m] = [ hrVal[m], dayCom[m] ];

			}

			data.addRows(valArr);
			

			var options = {
				title : '',
				legend : {
					position : 'none'
				},
				hAxis : {
					title : 'Demand',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : 'Supply',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',
				colors : [ '#A19564' ],                         //#B57C00
				is3D: true,

				
				chartArea:{top: 10,left:45,
		        	width:'85%',height:'75%'
		        		}
			};

			var chart = new google.visualization.LineChart(document.getElementById("suppDemdLineChart"));
			chart.draw(data, options);

		} catch (err) {
			alert("An error occured in Charts.\n" + err.message());
		}
	}
		
});


app.controller('GaugeMainLCtrl', function($scope) {

	var chartSource = new Array([ 'Label', 'Value' ], [ 'MWh', 1.54] );
	var data = new google.visualization.arrayToDataTable(chartSource);

	var options = {
		/*width: 160, height: 160,*/
			greenFrom : 0,
			greenTo : 1.6,
			redFrom : 3.2,
			redTo : 4.8,
			yellowFrom : 1.6,
			yellowTo : 3.2,
			minorTicks : 30,
			max : 5.0,
			min : 0,
		chartArea:{top: 10,left:200
        	
        		}
		
	};

	var chart = {};
	chart.data = data;
	chart.options = options;
	$scope.chart = chart;
});

app.controller('GaugeHvacLCtrl', function($scope) {

	var chartSource = new Array([ 'Label', 'Value' ], [ 'MWh', 0.51] );
	var data = new google.visualization.arrayToDataTable(chartSource);

	var options = {
		greenFrom : 0,
		greenTo : 0.4,
		redFrom : 0.8,
		redTo : 1.2,
		yellowFrom : 0.4,
		yellowTo : 0.8,
		minorTicks : 30,
		max : 1.2,
		min : 0,
	};

	var chart = {};
	chart.data = data;
	chart.options = options;
	$scope.chart = chart;
});

app.controller('GaugeLightLCtrl', function($scope) {

	var chartSource = new Array([ 'Label', 'Value' ], [ 'MWh', 0.24] );
	var data = new google.visualization.arrayToDataTable(chartSource);

	var options = {
			greenFrom : 0,
			greenTo : 0.4,
			redFrom : 0.8,
			redTo : 1.2,
			yellowFrom : 0.4,
			yellowTo : 0.8,
			minorTicks : 30,
			max : 1.2,
			min : 0,
		};

	var chart = {};
	chart.data = data;
	chart.options = options;
	$scope.chart = chart;
});

app.controller('GaugeUPSLCtrl', function($scope) {

	var chartSource = new Array([ 'Label', 'Value' ], [ 'MWh', 0.27] );
	var data = new google.visualization.arrayToDataTable(chartSource);

	var options = {
			greenFrom : 0,
			greenTo : 0.4,
			redFrom : 0.8,
			redTo : 1.2,
			yellowFrom : 0.4,
			yellowTo : 0.8,
			minorTicks : 30,
			max : 1.2,
			min : 0,
		};

	var chart = {};
	chart.data = data;
	chart.options = options;
	$scope.chart = chart;
});

app.controller('GaugeOtherLCtrl', function($scope) {

	var chartSource = new Array([ 'Label', 'Value' ], [ 'MWh', 0.32] );
	var data = new google.visualization.arrayToDataTable(chartSource);

	var options = {
			greenFrom : 0,
			greenTo : 0.4,
			redFrom : 0.8,
			redTo : 1.2,
			yellowFrom : 0.4,
			yellowTo : 0.8,
			minorTicks : 30,
			max : 1.2,
			min : 0,
		};

	var chart = {};
	chart.data = data;
	chart.options = options;
	$scope.chart = chart;
});

app.controller('weatherapiCtrl', function($scope, weatherapiService) {

	// console.log("in weatherapiCtrl");
	weatherapiService.getWeatherApiData().then(function(weatherData) {

		// console.log(weatherData);
		// console.log(weatherData.main.temp);
		tempInKelvin = weatherData.main.temp;
		tempInCelsius = tempInKelvin - 273.15;
		tempInCelsiusUpto2Decimal = tempInCelsius.toFixed(2);
		// console.log(tempInCelsius);
		$scope.temperature = tempInCelsiusUpto2Decimal;

		humid = weatherData.main.humidity;
		$scope.humidity = humid;

	});

});

app.controller('backCtrl', function($scope){
});


app.directive('backImg', function(){
    return function(scope, element, attrs){
        var url = attrs.backImg;
        element.css({
            'background-image': 'url(' + url +')',
            'background-size' : 'cover'
        });
    };
});


