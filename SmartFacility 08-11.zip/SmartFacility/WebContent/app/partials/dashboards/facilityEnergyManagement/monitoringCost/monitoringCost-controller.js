/*** Created by Vishwajeet  ***/

app.controller('monitoringCostCtrl', function($scope) {
		
});

app.controller('eqptWiseColChartCntr', function($scope, monitoringCostService) {
		
	draweqptWiseColumnChart();
	
	function draweqptWiseColumnChart() {
				
		/*var data=[['string','number'],['HVAC', 18360],['Light', 9930],['UPS', 3216],['Pump', 2301],['Lift', 5450]];*/
		var data= monitoringCostService.getArrayOfDailyEqptCosts();
		var chartData = new google.visualization.arrayToDataTable(data);
		
		var chartOptions = {
				  
				title : '',
				 is3D:true,					 
				legend : {
					position : 'none'
				},
				hAxis : {
					title : 'Equipments',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'                     //    777D06
					},
				},
				vAxis : {
					title : 'Cost in Rupees',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				backgroundColor : '#262626',    
				colors : [ '#4566A3' ],			//#AD2626		
				chartArea:{top: 10,left:65,
		        	width:'85%',height:'75%'
	    }
		};

		var chart = new google.visualization.ColumnChart(document.getElementById("eqptWiseColChart"));
		chart.draw(chartData, chartOptions);
		
	}	
});



app.controller('hourlyEqptLineChartCntr', function($scope, monitoringCostService) {
	
	
	drawChart();
	
	function drawChart() {
	/*var data = google.visualization.arrayToDataTable
			([
              ['Equipments', 'HVAC', 'Light', 'UPS', 'Lift', 'Pump', { role: 'annotation' }],
              ['07 am', 1585.2, 926.42, 536.14, 564.45, 681.85, ''],
              ['08 am', 1525.2, 956.42, 546.14, 764.45, 652.85, ''],
              ['09 am', 1645.2, 826.42, 16.14, 964.45, 581.85, ''],
              ['10 am', 1725.3, 816.42, 36.14, 864.45, 481.85, ''],
              ['11 am', 1745.2, 823.42, 436.14, 784.45, 281.85, ''],
              ['12 am', 1785.2, 847.42, 586.14, 794.45, 181.85, ''],
              ['01 pm', 1798.2, 816.32, 36.14, 984.45, 23.85, ''],
              ['02 pm', 1802.2, 798.42, 16.14, 864.45, 121.85, '']
            ]);*/
		
		var data2= monitoringCostService.getArrayOfHourlyEqptCosts();
		var chartData = new google.visualization.arrayToDataTable(data2);
	        
	        var options = {
	        		isStacked: true,
	        		legend: { position: 'right', textStyle: {color: '#fff', fontSize: 10}},
					title : '',					
					hAxis : {
						title : 'Time',
						textStyle : {
							color : '#fff'
						},
						titleTextStyle : {
							color : '#fff'
						},
					},
					vAxis : {
						title : 'Cost in Rupees',
						textStyle : {
							color : '#fff'
						},
						titleTextStyle : {
							color : '#fff'
						},
					},
					backgroundColor : '#262626',
					//colors : [ '#A19564' ],                         //#B57C00
					is3D: true,
					bar: { groupWidth: '40%' },

					
					chartArea:{top: 10,left:95,
			        	width:'70%',height:'75%'
			        		}
				};
	        
	        var chart = new google.visualization.ColumnChart(document.getElementById("hourlyLineChart"));
			chart.draw(chartData, options);
	                                                
	}

  	
	});


//google Line Material Chart
/*function drawChart() {

var data = new google.visualization.DataTable();
data.addColumn('number', 'Equipments');
data.addColumn('number', 'HVAC');
data.addColumn('number', 'Light');
data.addColumn('number', 'UPS');

data.addRows([
  [0,  35.3, 21.8, 17.5],
  [1,  37.8, 80.8, 41.8],
  [2,  30.9, 69.5, 32.4],
  [3,  25.4,   57, 25.7],
  [4,  11.7, 18.8, 10.5],
  [5,  11.9, 17.6, 10.4],
  [6,   8.8, 13.6,  7.7],
  [7,   7.6, 12.3,  9.6],
  [8,  12.3, 29.2, 10.6],
  [9,  16.9, 42.9, 14.8],
  [10, 12.8, 30.9, 11.6],
  [11,  5.3,  7.9,  4.7],
  [12,  6.6,  8.4,  5.2],
  [13,  4.8,  6.3,  3.6],
  [14,  4.2,  6.2,  3.4]
]);

var options = {
  chart: {
    title: '',
    //subtitle: 'in millions of dollars (USD)'
  },
  width: '85%',
  height: '75%',
  top: 10,
  left: 45,
  backgroundColor : '#262626',
  
};

var chart = new google.charts.Line(document.getElementById('hourlyLineChart'));

chart.draw(data, options);
}*/