app.service('monitoringCostService', function() {
	

	//	this.getCostData = function(floorVal){
	//	console.log(floorVal);
		
	
	//var ArrayOfDailyEqptCosts= function();
	
	
	ArrayOfDailyEqptCosts=[['string','number'],['HVAC', 18360],['Light', 9930],['UPS', 3216],['Pump', 2301],['Lift', 5450]];
	
	/*{heading: "Overall Cost- 7 Days", subHeading: "Last 7 Days", val1: "402.25", perc:"-03"},*/
	
	
	this.getArrayOfDailyEqptCosts = function() {
		return ArrayOfDailyEqptCosts;
	};
	
	ArrayofHourlyEqptCosts= [
	                         ['Equipments', 'HVAC', 'Light', 'UPS', 'Lift', 'Pump', { role: 'annotation' }],
	                         ['07 am', 1585.2, 926.42, 536.14, 564.45, 681.85, ''],
	                         ['08 am', 1525.2, 956.42, 546.14, 764.45, 652.85, ''],
	                         ['09 am', 1645.2, 826.42, 16.14, 964.45, 581.85, ''],
	                         ['10 am', 1725.3, 816.42, 36.14, 864.45, 481.85, ''],
	                         ['11 am', 1745.2, 823.42, 436.14, 784.45, 281.85, ''],
	                         ['12 am', 1785.2, 847.42, 586.14, 794.45, 181.85, ''],
	                         ['01 pm', 1798.2, 816.32, 36.14, 984.45, 23.85, ''],
	                         ['02 pm', 1802.2, 798.42, 16.14, 864.45, 121.85, '']
	                       ];
	
	this.getArrayOfHourlyEqptCosts = function() {
		return ArrayofHourlyEqptCosts;
	};
  	 
  	
	
	

});