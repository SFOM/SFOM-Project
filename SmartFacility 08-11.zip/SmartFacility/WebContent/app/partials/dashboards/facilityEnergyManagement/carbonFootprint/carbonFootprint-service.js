
app.service(' ', function($http) {
	
	this.lastWeekData = [
								['Date', 'Canteen1(kg)', 'Canteen2(kg)', 'BioGas(cubic meters)'],
								['2016-08-07', 4, 5, 0.46], //Sun
								['2016-08-08', 45, 53, 0.34], //Mon
								['2016-08-09', 75, 59, 3.7], //Tue
								['2016-08-10', 69, 77, 5.1], //Wed
								['2016-08-11', 72, 61, 5.6], //Thur
								['2016-08-12', 55, 67, 5.11], //Fri
								['2016-08-13', 5, 7, 4.6], //Sat
							];
	
	this.getLastWeekWaterData = function() {
		return lastWeekWaterData;
	};
	
	this.lastMonthData = [
								['Date', 'Water(k Ltrs)'],
								['2016-07-31', 4, 5, 0.52], //Sun
								['2016-08-01', 45, 53, 0.34], //Mon
								['2016-08-02', 71, 59, 3.7], //Tue
								['2016-08-03', 69, 77, 5.2], //Wed
								['2016-08-04', 72, 61, 5.6], //Thu
								['2016-08-05', 55, 67, 5.41], //Fri
								['2016-08-06', 5, 7, 5.1], //Sat
								
								

							];
	
	this.getLastMonthWaterData = function() {
		return lastMonthWaterData;
	};
});