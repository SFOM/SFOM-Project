/**
 * filter the dates greater than given date 
 */
app.filter('dateFromFilter', function() {

  // Create the return function and set the required parameter name to **input**
  return function(arrInput, property, startDate) {

    var arrOutput = [];
    // Using the angular.forEach method, go through the array of data and perform the operation of figuring out if the language is statically or dynamically typed.
    angular.forEach(arrInput, function(iValue, iKey) {

      if (iValue[property] >= startDate) {
    	  arrOutput.push(iValue);
      }
    })
    return arrOutput;
  }
});

/**
 * filter the dates before given date 
 */
app.filter('dateToFilter', function() {

	  return function(arrInput, property, endDate) {

	    var arrOutput = [];
	    angular.forEach(arrInput, function(iValue, iKey) {

	      if (iValue[property] <= endDate) {
	    	  arrOutput.push(iValue);
	      }
	    })
	    return arrOutput;
	  }
	});