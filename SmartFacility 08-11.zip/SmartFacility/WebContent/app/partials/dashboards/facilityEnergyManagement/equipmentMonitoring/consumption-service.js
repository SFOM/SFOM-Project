app.service('floorwiseDataService', function() {

	this.getFloorData = function(floorVal) {
//		console.log(floorVal);

		var ArrayOfDevices = {};

		/* var ArraySelectedFloor={}; */// we create here one JSON object for
										// storing details of floor which we
										// selected by dropdown box
		/*
		 * ArraySelectedFloorEquipment=[{"LOC_ID" : 1, "SUB_LOC_ID" : 1,
		 * "FLR_ID" : 1, "EQP_ID" : 1, "EQP_CD" : "HVAC"}, {"LOC_ID" : 1,
		 * "SUB_LOC_ID" : 1, "FLR_ID" : 1, "EQP_ID" : 2, "EQP_CD" : "Light"},
		 * {"LOC_ID" : 1, "SUB_LOC_ID" : 1, "FLR_ID" : 1, "EQP_ID" : 3, "EQP_CD" :
		 * "UPS"}, {"LOC_ID" : 1, "SUB_LOC_ID" : 1, "FLR_ID" : 1, "EQP_ID" : 4,
		 * "EQP_CD" : "DG"} ];
		 */

		/*ArrayOfDevices = [ [ { header : "HVAC", changeText : "23.58", para1 : "Operating Hours", val1 : "15", yest : "07" }, 
		                     { header : "Light", changeText : "21.58", para1 : "Operating Hours", val1 : "12", yest : "05" }, 
		                     { header : "UPS", changeText : "19.58", para1 : "Operating Hours", val1 : "11", yest : "03" }, 
		                     { header : "DG", changeText : "15.58", para1 : "Operating Hours", val1 : "04", yest : "01" },
		                   ], 
		                   [ { header : "HVAC", changeText : "23.58", para1 : "Operating Hours", val1 : "15", yest : "07" }, 
		                     { header : "Light", changeText : "20.58", para1 : "Operating Hours", val1 : "12", yest : "05" }, 
		                     { header : "Lift", changeText : "13.58", para1 : "Operating Hours", val1 : "11", yest : "03" }, 
		                   ], 
		                  [ { header : "HVAC", changeText : "23.58", para1 : "Operating Hours", val1 : "15", yest : "07" }, 
		                    { header : "Light", changeText : "13.72", para1 : "Operating Hours", val1 : "12", yest : "05"}, 
		                   ], 
		                  [ { header : "HVAC", para1 : "Operating Hours", changeText : "23.58", val1 : "15", yest : "07" }, 
		                    { header : "Light", para1 : "Operating Hours", changeText : "13.72", val1 : "12", yest : "05"}, 
		                    { header : "D.G", para1 : "Operating Hours", changeText : "10.30", val1 : "11", yest : "03"}, 
		                   ], 
		                  [ { header : "HVAC", para1 : "Operating Hours", changeText : "23.58", val1 : "15", yest : "07" }, 
		                    { header : "Light", para1 : "Operating Hours", changeText : "13.72", val1 : "12", yest : "05"}, 
		                    { header : "UPS", para1 : "Operating Hours", changeText : "10.30", val1 : "11", yest : "03" }, 
		                    { header : "Lift", para1 : "Operating Hours", changeText : "06.40", val1 : "04", yest : "01" }, 
		                   ], 
		                  [ { header : "HVAC", para1 : "Operating Hours", changeText : "23.58", val1 : "15", yest : "07" }, 
		                    { header : "Light", para1 : "Operating Hours", changeText : "13.72", val1 : "12", yest : "05" }, 
		                    { header : "Lift", para1 : "Operating Hours", changeText : "10.30", val1 : "11", yest : "03" }, 
		                   ], 
		                  [ { header : "HVAC", para1 : "Operating Hours", changeText : "23.58", val1 : "15", yest : "07" }, 
		                    { header : "Light", para1 : "Operating Hours", changeText : "13.72", val1 : "12", yest : "05" }, 
		                   ] 
		                ];*/
		
		
		ArrayOfDevices = [ [ { header : "HVAC", para1 : "Operating Hours :", val1 : "15", yest : "07", consVal : "42.52"  }, 
		                     { header : "Light", para1 : "Operating Hours :", val1 : "12", yest : "05", consVal : "19.71" }, 
		                     { header : "UPS", para1 : "Operating Hours :", val1 : "18", yest : "03", consVal : "22.34" }, 
		                     { header : "Water Pump", para1 : "Operating Hours :", val1 : "03", yest : "03", consVal : "31.98" },
		                   ], 
		                   [ { header : "HVAC", para1 : "Operating Hours :", val1 : "14", yest : "05", consVal : "47.11" }, 
		                     { header : "Light", para1 : "Operating Hours :", val1 : "11", yest : "03", consVal : "21.24" }, 
		                     { header : "Lift", para1 : "Operating Hours :", val1 : "12", yest : "01", consVal : "37.86" }, 
		                   ], 
		                  [ { header : "HVAC", para1 : "Operating Hours :", val1 : "16", yest : "02", consVal : "41.43" }, 
		                    { header : "Light", para1 : "Operating Hours :", val1 : "13", yest : "01", consVal : "19.76"}, 
		                   ], 
		                  [ { header : "HVAC", para1 : "Operating Hours :", val1 : "17", yest : "03", consVal : "44.80" }, 
		                    { header : "Light", para1 : "Operating Hours :", val1 : "15", yest : "04", consVal : "18.62"}, 
		                    /*{ header : "Water Pump", para1 : "Operating Hours", val1 : "11", yest : "03"}, */
		                   ], 
		                  [ { header : "HVAC", para1 : "Operating Hours :", val1 : "13", yest : "01", consVal : "47.95" }, 
		                    { header : "Light", para1 : "Operating Hours :", val1 : "11", yest : "02", consVal : "18.37"}, 
		                    { header : "UPS", para1 : "Operating Hours :", val1 : "16", yest : "04", consVal : "26.73" }, 
		                    /*{ header : "Lift", para1 : "Operating Hours", val1 : "04", yest : "01" }, */
		                   ], 
		                  [ { header : "HVAC", para1 : "Operating Hours :", val1 : "15", yest : "02", consVal : "44.58" }, 
		                    { header : "Light", para1 : "Operating Hours :", val1 : "13", yest : "03", consVal : "21.89" }, 
		                   /* { header : "Lift", para1 : "Operating Hours", val1 : "11", yest : "03" }, */
		                   ], 
		                  [ { header : "HVAC", para1 : "Operating Hours :", val1 : "17", yest : "02", consVal : "40.31" }, 
		                    { header : "Light", para1 : "Operating Hours :", val1 : "11", yest : "03", consVal : "18.32" }, 
		                   ] 
		                ];

console.log(ArrayOfDevices[floorVal - 1]);

		return ArrayOfDevices[floorVal - 1];
	}
	
	
	
	
	this.getmonthlyEnergyConsm= function(dayArr)
	{
		var monthlyEnergyConsm = new Array();
		console.log("dayArr = "+ dayArr);
		
		monthlyEnergyConsm = [ [ (dayArr[29]).toString(), 1326.567 ],
			[ (dayArr[28]).toString(), 541.546 ],
			[ (dayArr[27]).toString(), 860.589 ],
			[ (dayArr[26]).toString(), 1320.378 ],
			[ (dayArr[25]).toString(), 1256.600 ],
			[ (dayArr[24]).toString(), 1357.345 ],
			[ (dayArr[23]).toString(), 1266.060 ],
			[ (dayArr[22]).toString(), 1312.567 ],
			[ (dayArr[21]).toString(), 547.546 ],
			[ (dayArr[20]).toString(), 748.589 ],
			[ (dayArr[19]).toString(), 1282.378 ],
			[ (dayArr[18]).toString(), 1189.600 ],
			[ (dayArr[17]).toString(), 1327.345 ],
			[ (dayArr[16]).toString(), 1280.060 ],
			[ (dayArr[15]).toString(), 1387.567 ],
			[ (dayArr[14]).toString(), 585.546 ],
			[ (dayArr[13]).toString(), 878.589 ],
			[ (dayArr[12]).toString(), 1278.378 ],
			[ (dayArr[11]).toString(), 1354.600 ],
			[ (dayArr[10]).toString(), 1296.345 ],
			[ (dayArr[9]).toString(), 1356.060 ],
			[ (dayArr[8]).toString(), 1287.567 ],
			[ (dayArr[7]).toString(), 509.546 ],
			[ (dayArr[6]).toString(), 809.589 ],
			[ (dayArr[5]).toString(), 1274.378 ],
			[ (dayArr[4]).toString(), 1358.600 ],
			[ (dayArr[3]).toString(), 1278.345 ],
			[ (dayArr[2]).toString(), 1352.060 ],
			[ (dayArr[1]).toString(), 1298.567 ],
			[ (dayArr[0]).toString(), 1380.546 ] ];
		
		return monthlyEnergyConsm;
	};
	
	this.getWeeklyEnergyConsm= function(dayArr)
	{
		var WeeklyEnergyConsm = new Array();
		console.log("dayArr = "+ dayArr);
	
		WeeklyEnergyConsm = [ [ (dayArr[6]).toString(), 588.3 ],
					[ (dayArr[5]).toString(), 852.8 ],
					[ (dayArr[4]).toString(), 1321.5 ],
					[ (dayArr[3]).toString(), 1450.1 ],
					[ (dayArr[2]).toString(), 1352.7 ],
					[ (dayArr[1]).toString(), 1420.5 ],
					[ (dayArr[0]).toString(), 1380.6 ], ];
		
		return WeeklyEnergyConsm;
		
	}
	

});