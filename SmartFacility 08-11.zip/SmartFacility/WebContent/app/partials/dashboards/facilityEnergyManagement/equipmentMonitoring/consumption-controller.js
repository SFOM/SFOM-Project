app.controller('consCtrl',function($scope, $state, $location, fwdFloorService){
	
/*	chosedFloor = fwdFloorService.getSelFloor();
	console.log(chosedFloor);*/	
	
});


app.controller('deviceRepeatCtrl', function($scope, selLocationService, floorwiseDataService) {

//	console.log("In deviceRepeatCtrl");

	/*chosedFloor = fwdFloorService.getSelFloor();*/
	
	/*deviceCount = fwdFloorService.getDeviceCount();*/

/*	if (chosedFloor == undefined) {
		chosedFloor = 1;
	}

	if (deviceCount == undefined) {
		deviceCount = 4;
	}*/
	
	var chosedFloor = 1;
	
	$scope.$watch(function(){ return selLocationService.selLocation; }, function() {
				
		var selectedLocation = selLocationService.getSelFloor();
		chosedFloor = selectedLocation[2];
		
		console.log("User Select floor no: "+ chosedFloor);
		drawFloorwiseDevices(chosedFloor);
	});
	


	
	var drawFloorwiseDevices = function(chosedFloor){
		
		console.log(chosedFloor);
		
		if (chosedFloor == 1) {
			$scope.colLen = 2;
			$scope.marg = 0;
			$scope.costPerFloor = 8391.62;
			$scope.occPerFloor = 572;
						
		}

		if (chosedFloor == 2 ) {
			$scope.colLen = 2;
			$scope.marg = 37;
			$scope.costPerFloor = 7647.12;
			$scope.occPerFloor = 522;
		}
		
		if (chosedFloor == 5 ) {
			$scope.colLen = 2;
			$scope.marg = 37;
			$scope.costPerFloor = 6552.72;
			$scope.occPerFloor = 482;
		}

		if (chosedFloor == 3 ) {
			$scope.colLen = 3;
			$scope.marg = 55;
			$scope.costPerFloor = 4405.51;
			$scope.occPerFloor = 621;
		}
		
		if (chosedFloor == 4 ) {
			$scope.colLen = 3;
			$scope.marg = 55;
			$scope.costPerFloor = 4566.87;
			$scope.occPerFloor = 578;
		}
		
		if (chosedFloor == 6 ) {
			$scope.colLen = 3;
			$scope.marg = 55;
			$scope.costPerFloor = 4785.48;
			$scope.occPerFloor = 562;
		}
		
		if (chosedFloor == 7) {
			$scope.colLen = 3;
			$scope.marg = 55;
			$scope.costPerFloor = 4248.74;
			$scope.occPerFloor = 371;
		}

		$scope.arw = "up";
		$scope.arwClr = "red";
		
//		console.log("call floorwiseDataService");
		var ArrayOfDeviceValues = floorwiseDataService.getFloorData(chosedFloor);
		console.log(ArrayOfDeviceValues[0].header);
		/*var floorHeader = ($filter('filter')(ArrayOfDeviceValues, 
				{hvac:ArrayOfDeviceValues[0], light:ArrayOfDeviceValues[1], floorId:selectedLocation[2]}))[0].floorMap;*/
		
		$scope.numOfDevices = ArrayOfDeviceValues;
	}

	

});


/*app.controller('changeTextCtrl', function($scope, $interval , ArrayOfDeviceValues) {
  if(Array)
	  $scope.changeText = 40.11;
	  function update() {
		  if($scope.changeText < 48)
			  {
			    $scope.changeText = $scope.changeText + 0.27;
			  }
		  else 
			  {
			     $scope.changeText = 40.23;
			  }
		  	                                                           
	  }
	  $interval(update, 1000 * 5);
	});*/












//http://codepen.io/baliw/pen/GJydZM

//This code is used to generate random values @ every 5 sec 
/*app.controller('changeTextCtrl', function($scope, $interval) {
	  $scope.changeText = 0;
	  function update() {
		    $scope.changeText = ((Math.random() * 100)+1).toFixed(2);   // generate random value between 1 to 100 and upto 2 decimal points 
		  	                                                               // use toFixed(2) to fix decimal pt upto 2 use math.floor() to convert into whole number
		
		  $scope.changeText = (Math.floor(Math.random() * (39.78 - 35.2 + 1)) + 35.2).toFixed(2);
		  
	  }
	  $interval(update, 1000 * 3);
	});*/









			    	
	/*setInterval(function(){ 
	    return Math.floor((Math.random()*100)+1);
	    
	}, 1000);
	
	$scope.changeText=setinterval(getRandomValue,1000);
	
	function getRandomValue(min, max) {
	    return Math.random() * (max - min) + min;
	}
	
	var text = [ "21.23", "24.05", "17.37", "19.74" ];
	var counter = 0;
	var elem = document.getElementById("changeText");
	setInterval(change, 3000);
	function change() {
		elem.innerHTML = text[counter];
		counter++;
		if (counter >= text.length) {
			counter = 0;
		}
	}*/




	


app.controller('ColChartCntr2',
		function($scope, $stateParams, selLocationService, floorwiseDataService) {

//			console.log("in ColChartCntr");

/*			selectedFloor = fwdFloorService.getSelFloor();
			if (selectedFloor == undefined) {
				selectedFloor = 1;
			}
			$scope.selectedFloor = selectedFloor;*/
			
			
			$scope.$watch(function(){ return selLocationService.selLocation; }, function() {
				
				var selectedLocation = selLocationService.getSelFloor();
				$scope.selectedFloor = selectedLocation[2];
	
			});
			
			
			
			console.log("selected floor for column chart = " + $scope.selectedFloor);

			Date.prototype.getWeek = function() {
				var determinedate = new Date();
				determinedate.setFullYear(this.getFullYear(), this.getMonth(),
						this.getDate());
				var D = determinedate.getDay();
				if (D == 0)
					D = 7;
				determinedate.setDate(determinedate.getDate() + (4 - D));
				var YN = determinedate.getFullYear();
				var ZBDoCY = Math.floor((determinedate.getTime() - new Date(YN,
						0, 1, -6)) / 86400000);
				var WN = 1 + Math.floor(ZBDoCY / 7);

//				console.log(WN);
				return WN;

			}

			function updateChart(selectedType) {

				drawColumnChart(selectedType);
			}

			updateChart("Week");

			$('#div_clmnChart_btns button').click(function(e) {
				var selectedType = $(this).text();
				updateChart(selectedType);
				return false;
			});

			function drawColumnChart(sel_view) {
				var curDate = new Date();
				var day = curDate.getDate();
				var dayArr = [];
				var i = 1;
				var j = 1;
				var day1 = curDate.getDate();
				var month = curDate.getMonth();
				var month1 = curDate.getMonth();
				var monthArr = [];
				var monthArr1 = [];
				var monthNames = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun",
						"Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan" ];
				for (; i < 30;) {
					if (day1 == 1) {
						day = 31;
						i = 1;
					}
					dayArr.push(day1);
					day1 = day - i;
					i++;
				}

				for (; j < 10;) {
					if (month1 == 1) {
						month = 13;
						j = 1;
					}

					monthArr.push(month1);
					monthArr1.push(monthNames[month1]);
					month1 = month - j;
					j++;
				}

				try {
					var curDate = new Date();
					if (sel_view === 'Week') {
						var data = new google.visualization.DataTable();
						data.addColumn('string', 'Days of week');
						data.addColumn('number', 'KWhr');

						var todayDay = curDate.getDate();
						var consArrayWeek = floorwiseDataService.getWeeklyEnergyConsm(dayArr);
						data.addRows(consArrayWeek);
						/*data.addRows([ [ (dayArr[6]).toString(), 588.3 ],
								[ (dayArr[5]).toString(), 852.8 ],
								[ (dayArr[4]).toString(), 1321.5 ],
								[ (dayArr[3]).toString(), 1450.1 ],
								[ (dayArr[2]).toString(), 1352.7 ],
								[ (dayArr[1]).toString(), 1420.5 ],
								[ (dayArr[0]).toString(), 1380.6 ], ]);*/

						var options = {
							title : '',
							is3D : true,
							legend : {
								position : 'none'
							},
							hAxis : {
								title : 'Days of week',
								textStyle : {
									color : '#00B539'
								},
								titleTextStyle : {
									color : '#00B539'
								},
							},
							vAxis : {
								title : 'KWhr',
								textStyle : {
									color : '#00B539'
								},
								titleTextStyle : {
									color : '#00B539'
								},
							},
							backgroundColor : '#262626',
							colors : [ '#00B539' ],
							chartArea : {
								top : 10,
								left : 65,
								width : '85%',
								height : '75%'
							}
						};

						$('#btntd').removeClass('btnSelected');
						$('#btnwk').addClass('btnSelected');
						$('#btnmt').removeClass('btnSelected');
					} else if (sel_view === 'Month') {
						var data = new google.visualization.DataTable();
						data.addColumn('string', 'Days of Month');
						data.addColumn('number', 'KWhr');
						var todayMonth = curDate.getDate();
                        var consArrayMonth = floorwiseDataService.getmonthlyEnergyConsm(dayArr);
						data.addRows(consArrayMonth);

						var options = {
							title : '',
							legend : {
								position : 'none'
							},
							hAxis : {
								title : 'Days of Month',
								textStyle : {
									color : '#a52714'
								},
								titleTextStyle : {
									color : '#a52714'
								},
							},
							vAxis : {
								title : 'KWhr',
								textStyle : {
									color : '#a52714'
								},
								titleTextStyle : {
									color : '#a52714'
								},
							},
							backgroundColor : '#262626',
							colors : [ '#a52714' ],

							chartArea : {
								top : 10,
								left : 65,
								width : '85%',
								height : '75%'
							}
						};
//						console.log(data);

						$('#btntd').removeClass('btnSelected');
						$('#btnwk').removeClass('btnSelected');
						$('#btnmt').addClass('btnSelected');
					} else if (sel_view === 'Today') {

						var tm = new Date();
						var hr = tm.getHours();
						var dayCom = new Array();
						var hrVal = new Array();
						var valArr = new Array();
						var data = new google.visualization.DataTable();
						data.addColumn('string', 'Hours');
						data.addColumn('number', 'KWhr');

						for (var m = hr; m >= 0; m--) {

							var y = Math.floor(Math.random() * (125-115+1)) + 115;
							//return Math.random() * (max - min) + min;
							console.log("y val = " +y);

							dayCom[m] = y;
							hrVal[m] = m.toString();
							valArr[m] = [ hrVal[m], dayCom[m] ];

						}

						console.log(valArr);
						data.addRows(valArr);
						console.log(data)

						var options = {
							title : '',
							legend : {
								position : 'none'
							},
							hAxis : {
								title : 'Hours',
								textStyle : {
									color : '#B57C00'
								},
								titleTextStyle : {
									color : '#B57C00'
								},
							},
							vAxis : {
								title : 'KWhr',
								textStyle : {
									color : '#B57C00'
								},
								titleTextStyle : {
									color : '#B57C00'
								},
							},
							backgroundColor : '#262626',
							colors : [ '#B57C00' ],
							is3D : true,

							chartArea : {
								top : 10,
								left : 65,
								width : '85%',
								height : '75%'
							}
						};

						$('#btntd').addClass('btnSelected');
						$('#btnwk').removeClass('btnSelected');
						$('#btnmt').removeClass('btnSelected');
					}

					var chart = new google.visualization.AreaChart(document
							.getElementById("chart_column"));
					chart.draw(data, options);

				} catch (err) {
					alert("An error occured in Charts.\n" + err.message());
				}
			}

		});



app.controller('DonutChartCntr', function($scope) {

	drawChart();

	function drawChart() {
		var data = google.visualization.arrayToDataTable([
				[ 'Devices', 'Consumption' ], [ 'HVAC', 45 ], [ 'Light', 27 ],
				[ 'UPS', 13 ], [ 'DG', 07 ], [ 'Other', 08 ] ]);

		var options = {
			legend : 'none',
			pieSliceText : 'label',
			pieHole : 0.4,
			backgroundColor : '#262626',
			is3D : true,

			chartArea : {
				width : '100%',
				height : '100%'
			}
		};

		var chart = new google.visualization.PieChart(document
				.getElementById('donutchart'));
		chart.draw(data, options);
	}

});


app.controller('weatherApiConsCtrl', function($scope, weatherapiService) {

//	console.log("in weatherapiCtrl");
	weatherapiService.getWeatherApiData().then(function(weatherData) {

		console.log(weatherData);
		console.log(weatherData.main.temp);
		tempInKelvin = weatherData.main.temp;
		tempInCelsius = tempInKelvin - 273.15;
		tempInCelsiusUpto2Decimal = tempInCelsius.toFixed(2);
		console.log(tempInCelsius);
		$scope.temperature = tempInCelsiusUpto2Decimal;

		humid = weatherData.main.humidity;
		$scope.humidity = humid;

	});
});
