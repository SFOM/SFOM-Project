/***
 * Created By: #246292 - Lekha
 * Ref: 
 * data join = https://developers.google.com/chart/interactive/docs/reference#google_visualization_data_join
 * checkbox: http://output.jsbin.com/ImAqUC/1/
 */
app.controller('analysisConsumptionCtrl', function($scope, $filter, uiGridConstants, analysisConsumptionService) {

	$scope.equipmentList = analysisConsumptionService.equipmentList;

	// Checkbox - selected equipments
	$scope.chkboxSelectedEqpt = new Array();
	angular.forEach($scope.equipmentList, function(value, index){
		$scope.chkboxSelectedEqpt.push(value.eqptId);
	});

	// toggle selection for a given Equipment by name
	$scope.toggleCheckbox = function(varEqptId) {
		//if($scope.chkboxSelectedEqpt.length > 1){
			var idx = $scope.chkboxSelectedEqpt.indexOf(varEqptId);
			// is currently selected
			if (idx > -1) {
				$scope.chkboxSelectedEqpt.splice(idx, 1);
			}
			// is newly selected
			else {
				$scope.chkboxSelectedEqpt.push(varEqptId);
			}
			$scope.updateChart();
		/*} else {
			alert("At least one equipment should be selected to display chart.");
			$scope.$apply();
		}*/
	};
	
	$scope.dtFrom = "";
	$scope.dtTo = "";
	$scope.maxDate = new Date();
	$scope.dateFormat = "MM/dd/yyyy";
	
	$scope.dateOptions = {
		    formatYear: 'yy',
		    startingDay: 1,
		    showWeeks: false,
	};
	
	$scope.status = {
		    fromOpened: false,
		    toOpened: false
		  };
	
	$scope.open = function($event) {
		if($event.currentTarget.id == "btnDtFrom"){
			$scope.status.fromOpened = true;
		} else if($event.currentTarget.id == "btnDtTo"){
			$scope.status.toOpened = true;
		}
	};

	// Data Frequency - Button Bar settings
	$scope.radioModel = 'h';
	
	$scope.chartData;
	$scope.chartOptions;
	$scope.chart;
	
	/** Generate chart for 'h' - Hourly Data **/
	var generateChart_Hourly = function () {
		
		// Set default date in filter
		$scope.dtFrom = new Date("07/01/2016");
		$scope.dtTo = new Date("07/01/2016");
		
		//generate DataTable
		var chartData = new google.visualization.DataTable();
		var hourlyChartData = analysisConsumptionService.getHourlyChartData();
		
		angular.forEach( analysisConsumptionService.equipmentList, function(value, index){
			var dataForEqpt = $filter('eqptDataFilter')( hourlyChartData, 1, value.eqptId);
			angular.forEach( dataForEqpt, function(value, index){
				value[0] = new Date(value[0]); // string to date conversion
			});
			
			// {	$: value.eqptId	}, true);
			dataForEqpt.splice(0, 0, ['Date-Time', value.eqptName]);// add header to array
			var tempChartData = new google.visualization.arrayToDataTable(dataForEqpt);
			if(chartData.getNumberOfRows() == 0){
				chartData = new google.visualization.arrayToDataTable(dataForEqpt);
			} else {
				var chartDataColumns = new Array();
				for(var i = 1; i < chartData.getNumberOfColumns(); i++){
					chartDataColumns.push(i);
				}
				chartData = google.visualization.data.join(chartData, tempChartData, 'full', [[0, 0]], chartDataColumns, [1]);
				// ref : google.visualization.data.join(dt1, dt2, joinMethod, keys, dt1Columns, dt2Columns);
			}
			//console.log(chartData);
		});
		

	  	var options = {
	  			//title: 'Electricity Consumption', //$scope.selComponentName +' - Properties Trends',
				legend: { 	position: 'right',
							textStyle:{ color: '#fff'}
						},
				fontSize: 12,
				//colors: [ '#0066CC', '#DC3912', '#F98A1A', '#336600'], 
				//chartArea: {left:50}, // top:25, height:'80%', width:'90%'
				vAxis: {
							title: "KWh",
							textStyle:{ color: '#fff'},
							titleTextStyle:{ color: '#fff'},
							gridlines: {color: '#c5c5c5'}
						}, 
				hAxis: {	title: "Time",
							textStyle:{ color: '#fff'},
							titleTextStyle:{ color: '#fff'},
							gridlines: {color: '#c5c5c5'}
						},
				backgroundColor: '#494b54', //3E3E3E, A1A1A1, 777777, #636363
		};
		$scope.chartData = chartData;
		$scope.chartOptions = options;
	    //var chart = {};
	    //chart.data = chartData;
	    //chart.options = options;
	    //$scope.chart = chart;
	}
	
	/** Generate chart for 'd' - Daily Data **/
	var generateChart_Daily = function () {
		// Set default date in filter
		$scope.dtFrom = new Date("07/01/2016");
		$scope.dtTo = new Date("07/09/2016");
		
		var chartData = new google.visualization.DataTable();
		var dailyChartData = analysisConsumptionService.getDailyChartData();
		
		angular.forEach( analysisConsumptionService.equipmentList, function(value, index){
			var dataForEqpt = $filter('eqptDataFilter')( dailyChartData, 1, value.eqptId);
			angular.forEach( dataForEqpt, function(value, index){
				value[0] = new Date(value[0]);
			});
			
			dataForEqpt.splice(0, 0, ['Date-Time', value.eqptName]);
			var tempChartData = new google.visualization.arrayToDataTable(dataForEqpt);
			if(chartData.getNumberOfRows() == 0){
				chartData = new google.visualization.arrayToDataTable(dataForEqpt);
			} else {
				var chartDataColumns = new Array();
				for(var i = 1; i < chartData.getNumberOfColumns(); i++){
					chartDataColumns.push(i);
				}
				chartData = google.visualization.data.join(chartData, tempChartData, 'full', [[0, 0]], chartDataColumns, [1]);
				// ref : google.visualization.data.join(dt1, dt2, joinMethod, keys, dt1Columns, dt2Columns);
			}
			//console.log(chartData);
		});
		
	  	var options = {
				legend: { 	position: 'right',
							textStyle:{ color: '#fff'}
						},
				fontSize: 12,
				vAxis: {
							title: "KWh",
							textStyle:{ color: '#fff'},
							titleTextStyle:{ color: '#fff'},
							gridlines: {color: '#c5c5c5'}
						}, 
				hAxis: {	title: "Day",
							textStyle:{ color: '#fff'},
							titleTextStyle:{ color: '#fff'},
							gridlines: {color: '#c5c5c5'}
						},
				backgroundColor: '#494b54', //3E3E3E, A1A1A1, 777777, #636363
		};

		$scope.chartData = chartData;
		$scope.chartOptions = options;
	    //var chart = {};
	    //chart.data = chartData;
	    //chart.options = options;
	    //$scope.chart = chart;
	}
	
	/*** **/
	$scope.showHideEqptSeries = function () {
		var view = new google.visualization.DataView($scope.chartData);
		var columns = [0];
		angular.forEach($scope.chkboxSelectedEqpt, function(iValue, iIndex){
			for(var i=1; i < $scope.chartData.getNumberOfColumns(); i++) {
				var eqpmnt = $filter('filter')($scope.equipmentList, {eqptName:$scope.chartData.getColumnLabel(i)});
				//, comparator, anyPropertyKey
				if(eqpmnt.length > 0 && eqpmnt[0].eqptId == iValue){
						columns.push(i);
				}
			}
		})

		view.setColumns(columns);
		//$scope.chart.data = view;
		var chart = {};
		chart.data = view;
		chart.options = $scope.chartOptions;
		$scope.chart = chart;
		//$scope.chart.draw(view, $scope.chart.options);
	}
	
	$scope.updateChart = function() {
		console.log("Selected " + $scope.radioModel);	
		if($scope.radioModel == 'h'){
			generateChart_Hourly();
		} else if($scope.radioModel == 'd'){
			generateChart_Daily();
		} else if($scope.radioModel == 'w'){
			generateChart_Hourly();
		} else if($scope.radioModel == 'm'){
			generateChart_Daily();
		}
		$scope.showHideEqptSeries();
	}
	
	$scope.updateChart();

});