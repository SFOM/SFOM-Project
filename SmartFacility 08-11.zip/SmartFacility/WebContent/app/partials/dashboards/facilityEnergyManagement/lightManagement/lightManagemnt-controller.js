app.controller('LightCtrl', function($scope, $filter,$interval,lightingService) {
	//$scope.daylight;
	var date = new Date();
	var hours = date.getHours();
	if(hours>7 && hours <=17){
		$scope.daylight = "Active";
		$scope.light  ="32%";
	}
	else
		{
		$scope.daylight = "Not Active";
        $scope.light = "85%"
		}
	    
	
});

app.controller('LightFloorOneCtrl', function($scope, $filter,$interval,lightingService) {
	var count = 0;
	$scope.powerConsumption1;
	var rotate =function( array , times ){
		var array1=[];  
		while( times-- ){
			 
		    var temp = array.shift();
		    array.push( temp )
		  }
		  for(var i=0;i<array.length;i++){
			  array1.push(new Array(i*10,array[i]));
		  }
		  return array1;
		}
	var drawConsumptionGraph = function(){
	//var result = angular.copy(lightingService.energyConsumptionData);
	
	var graphData=[19.7,19.9,19.6,19.7,20.1,20.5,19.9,19.7,19.47,19.37,19.57,19.67,19.7,20,21.2,21.3,20.7,20.1,19.8,19.7,19.7,19.7,19.7,19.7,19.7,19.7,19.6,19.5,19.67,
	19.5,19.8,19.7,19.9,19.7,19.7,20.15,20.14,20.56,20.24,20.24,20.12,20.31,20.12,19.9,19.72,19.54,19.36,19.45,19.57,19.84,19.65,19.7,19.95,20.25,20.1,19.81,19.56,19.75,19.6,19.4];
	
	
	if(count==graphData.length)
		count=0;
	var graphData1=[];
	
	graphData1 = angular.copy(rotate(graphData,count));
	graphData1.splice(0, 0,['seconds','Energy Consumption']);
		var data = new google.visualization.arrayToDataTable(graphData1);
		var options = {
	    		title: '', //Last 7 Days
	    		chartArea:{    left: "18%",
	                top: "6%",
	                bottom:"30%",
	                height: "25%",
	                width: "85%" },
	    		hAxis : {
	    			title : 'Time ',
	    			//format: 'MMM dd', //'EEE, MMM dd',
	    			textStyle : {
	    				color : '#fff',fontSize: '5px',
	    					
	    			},
	    			titleTextStyle : {
	    				color : '#fff',size: '5px' ,
	    				
	    			},
	    			gridlines: {
		                 color: 'grey'
		             },
	    		},
	    		vAxis : {
	    			title : 'kWhr',
	    			textStyle : {
	    				color : '#fff',fontSize: '10px',
	    				
	    			},
	    			titleTextStyle : {
	    				color : '#fff',fontSize: '10px',
	    				//size: '6px'
	    			},
	    			gridlines: {
		                 color: 'transparent'
		             },
	    		},
	    		 bar: { gap: 0 },
	    		 
	    		colors: [ '#0066CC', '#fba651', '#336600', '#B00' ], // '#4566A3', '#DC3912', '#F98A1A', 
	    		backgroundColor : '#262626',
	    		legend: {position: 'none'},
//	    		seriesType: 'bars',
//	    		isStacked: true,
//	    		chartArea: {left: 50, width:'58%'},
	    		
	    };
		
	    var chart = {};
	    
	    chart.data = data;
	    chart.options = options;
	    $scope.chart = chart;
       count++;
	}
	drawConsumptionGraph();
	$interval(drawConsumptionGraph,10000);
});


app.controller('LightFloorTwoCtrl', function($scope, $filter,$interval,lightingService) {
	var count = 2;
	
	var rotate =function( array , times ){
		var array1=[];  
		while( times-- ){
			 
		    var temp = array.shift();
		    array.push( temp )
		  }
		  for(var i=0;i<array.length;i++){
			  array1.push(new Array(i*10,array[i]));
		  }
		  return array1;
		}
	var drawConsumptionGraph = function(){
	//var result = angular.copy(lightingService.energyConsumptionData);
	
	var graphData=[19.7,19.57,19.67,19.7,20,21.2,21.3,20.7,20.1,19.8,19.7,19.7,19.7,19.7,19.7,19.7,19.7,19.6,19.5,19.67,
	19.5,19.8,19.7,19.9,19.7,19.7,19.9,19.6,19.7,20.1,20.5,19.9,19.7,19.47,19.37,20.15,20.14,20.56,20.24,20.24,20.12,20.31,20.12,19.9,19.72,19.54,19.36,19.45,19.57,19.84,19.65,19.7,19.95,20.25,20.1,19.81,19.56,19.75,19.6,	19.4];
	
	
	if(count==graphData.length)
		count=0;
	var graphData1=[];
	
	graphData1 = angular.copy(rotate(graphData,count));
	graphData1.splice(0, 0,['seconds','Energy Consumption']);
		var data = new google.visualization.arrayToDataTable(graphData1);
		var options = {
	    		title: '', //Last 7 Days
	    		hAxis : {
	    			title : 'Time ',
	    			//format: 'MMM dd', //'EEE, MMM dd',
	    			textStyle : {
	    				color : '#fff',size: '10px'
	    			},
	    			titleTextStyle : {
	    				color : '#fff',size: '10px'                     
	    			},
	    			gridlines: {
		                 color: 'grey'
		             },
	    		},
	    		vAxis : {
	    			title : 'kWhr',
	    			textStyle : {
	    				color : '#fff',fontSize: '10px',
	    				
	    			},
	    			titleTextStyle : {
	    				color : '#fff',fontSize: '10px',
	    				
	    			},
	    			gridlines: {
		                 color: 'transparent'
		             },
	    		},
	    		 bar: { gap: 0 },
	    		 
	    		colors: [  '#fba651', '#336600', '#B00' ], // '#4566A3', '#DC3912', '#F98A1A', 
	    		backgroundColor : '#262626',
	    		legend: {position: 'none'},
//	    		seriesType: 'bars',
//	    		isStacked: true,
//	    		chartArea: {left: 50, width:'58%'},
	    		chartArea:{    left: "18%",
	                top: "6%",
	                bottom:"30%",
	                height: "25%",
	                width: "85%" },
	    };
		
	    var chart = {};
	    
	    chart.data = data;
	    chart.options = options;
	    $scope.chart = chart;
       count++;
	}
	drawConsumptionGraph();
	$interval(drawConsumptionGraph,10000);
});


app.controller('LightFloorThreeCtrl', function($scope, $filter,$interval,lightingService) {
	var count = 2;
	
	var rotate =function( array , times ){
		var array1=[];  
		while( times-- ){
			 
		    var temp = array.shift();
		    array.push( temp )
		  }
		  for(var i=0;i<array.length;i++){
			  array1.push(new Array(i*10,array[i]));
		  }
		  return array1;
		}
	var drawConsumptionGraph = function(){
	//var result = angular.copy(lightingService.energyConsumptionData);
	
	var graphData=[19.7,19.57,19.67,19.7,20,21.2,21.3,20.7,20.1,19.8,19.7,19.7,19.7,19.7,19.7,19.7,19.7,19.6,19.5,19.67,
	               19.47,19.37,20.15,20.14,20.56,20.24,20.24,20.12,20.31,20.12,19.9,19.72,19.54,19.36,19.45,19.57,19.84,19.65,19.7,19.95,20.25,20.1,19.81,19.56,
	19.5,19.8,19.7,19.9,19.7,19.7,19.9,19.6,19.7,20.1,20.5,19.9,19.7,19.75,19.6,	19.4];
	
	
	if(count==graphData.length)
		count=0;
	var graphData1=[];
	
	graphData1 = angular.copy(rotate(graphData,count));
	graphData1.splice(0, 0,['seconds','Energy Consumption']);
		var data = new google.visualization.arrayToDataTable(graphData1);
		var options = {
	    		title: '', //Last 7 Days
	    		hAxis : {
	    			title : 'Time ',
	    			//format: 'MMM dd', //'EEE, MMM dd',
	    			textStyle : {
	    				color : '#fff',fontSize: '12px',
	    				
	    			},
	    			titleTextStyle : {
	    				color : '#fff',fontSize: '12px',
	    				                   
	    			},
	    			gridlines: {
		                 color: 'grey'
		             },
	    		},
	    		vAxis : {
	    			title : 'kWhr',
	    			textStyle : {
	    				color : '#fff',fontSize: '10px',
	    				
	    			},
	    			titleTextStyle : {
	    				color : '#fff',fontSize: '10px',
	    				
	    			},
	    			gridlines: {
		                 color: 'transparent'
		             },
	    		},
	    		 bar: { gap: 0 },
	    		 
	    		colors: [  '#336600', '#B00' ], // '#4566A3', '#DC3912', '#F98A1A', 
	    		backgroundColor : '#262626',
	    		legend: {position: 'none'},
//	    		seriesType: 'bars',
//	    		isStacked: true,
//	    		chartArea: {left: 50, width:'58%'},
	    		chartArea:{    left: "18%",
	                top: "6%",
	                bottom:"35%",
	                height: "25%",
	                width: "85%" },
	    };
		
	    var chart = {};
	    
	    chart.data = data;
	    chart.options = options;
	    $scope.chart = chart;
       count++;
	}
	drawConsumptionGraph();
	$interval(drawConsumptionGraph,10000);
});



app.controller('LightFloorThreeCtrl', function($scope, $filter,$interval,lightingService) {
	var count = 2;
	
	var rotate =function( array , times ){
		var array1=[];  
		while( times-- ){
			 
		    var temp = array.shift();
		    array.push( temp )
		  }
		  for(var i=0;i<array.length;i++){
			  array1.push(new Array(i*10,array[i]));
		  }
		  return array1;
		}
	var drawConsumptionGraph = function(){
	//var result = angular.copy(lightingService.energyConsumptionData);
	
	var graphData=[19.7,19.57,19.67,19.7,19.5,19.8,19.7,19.9,19.7,19.47,19.37,20.15,20.14,20.56,20.24,20.24,20,21.2,21.3,20.7,20.1,19.8,19.7,19.7,19.7,19.7,19.7,19.7,19.7,19.6,19.5,19.67,
	               20.12,20.31,20.12,19.9,19.72,19.54,19.36,19.45,19.57,19.84,19.65,19.7,19.95,20.25,20.1,19.81,19.56,
	19.7,19.9,19.6,19.7,20.1,20.5,19.9,19.7,19.75,19.6,	19.4];
	
	
	if(count==graphData.length)
		count=0;
	var graphData1=[];
	
	graphData1 = angular.copy(rotate(graphData,count));
	graphData1.splice(0, 0,['seconds','Energy Consumption']);
		var data = new google.visualization.arrayToDataTable(graphData1);
		var options = {
	    		title: '', //Last 7 Days
	    		hAxis : {
	    			title : 'Time ',
	    			//format: 'MMM dd', //'EEE, MMM dd',
	    			textStyle : {
	    				color : '#fff',fontSize: '10px',
	    				
	    			},
	    			titleTextStyle : {
	    				color : '#fff',fontSize: '10px',
	    				                    
	    			},
	    			gridlines: {
		                 color: 'grey'
		             },
	    		},
	    		vAxis : {
	    			title : 'kWhr',
	    			textStyle : {
	    				color : '#fff',fontSize: '10px',
	    				
	    			},
	    			titleTextStyle : {
	    				color : '#fff',fontSize: '10px',
	    				
	    			},
	    			gridlines: {
		                 color: 'transparent'
		             },
	    		},
	    		 bar: { gap: 0 },
	    		 
	    		colors: [  '#336600', '#B00' ], // '#4566A3', '#DC3912', '#F98A1A', 
	    		backgroundColor : '#262626',
	    		legend: {position: 'none'},
//	    		seriesType: 'bars',
//	    		isStacked: true,
//	    		chartArea: {left: 50, width:'58%'},
	    		chartArea:{    left: "18%",
	                top: "6%",
	                bottom:"30%",
	                height: "25%",
	                width: "85%" },
	    };
		
	    var chart = {};
	    
	    chart.data = data;
	    chart.options = options;
	    $scope.chart = chart;
       count++;
	}
	drawConsumptionGraph();
	$interval(drawConsumptionGraph,10000);
});


// Floor Four

app.controller('LightFloorFourCtrl', function($scope, $filter,$interval,lightingService) {
	var count = 0;
	
	var rotate =function( array , times ){
		var array1=[];  
		while( times-- ){
			 
		    var temp = array.shift();
		    array.push( temp )
		  }
		  for(var i=0;i<array.length;i++){
			  array1.push(new Array(i*10,array[i]));
		  }
		  return array1;
		}
	var drawConsumptionGraph = function(){
	//var result = angular.copy(lightingService.energyConsumptionData);
	
	var graphData=[19.7,19.9,19.6,19.7,20.1,20.5,19.9,19.7,19.47,19.37,19.57,19.67,19.7,20,21.2,21.3,20.7,20.1,
	19.5,19.8,19.7,19.9,19.7,19.7,20.15,19.54,19.36,19.45,19.57,19.84,19.65,19.7,19.95,20.25,20.1,19.81,19.56,19.75,19.6,19.8,19.7,19.7,19.7,19.7,19.7,19.7,19.7,19.6,19.5,19.67,	20.14,20.56,20.24,20.24,20.12,20.31,20.12,19.9,19.72,19.4];
	
	
	if(count==graphData.length)
		count=0;
	var graphData1=[];
	
	graphData1 = angular.copy(rotate(graphData,count));
	graphData1.splice(0, 0,['seconds','Energy Consumption']);
		var data = new google.visualization.arrayToDataTable(graphData1);
		var options = {
	    		title: '', //Last 7 Days
	    		hAxis : {
	    			title : 'Time ',
	    			//format: 'MMM dd', //'EEE, MMM dd',
	    			textStyle : {
	    				color : '#fff',size: '10px'
	    			},
	    			titleTextStyle : {
	    				color : '#fff',size: '10px'                     
	    			},
	    			gridlines: {
		                 color: 'grey'
		             },
	    		},
	    		vAxis : {
	    			title : 'kWhr',
	    			textStyle : {
	    				color : '#fff',fontSize: '10px',
	    				
	    			},
	    			titleTextStyle : {
	    				color : '#fff',fontSize: '10px',
	    				
	    			},
	    			gridlines: {
		                 color: 'transparent'
		             },
	    		},
	    		 bar: { gap: 0 },
	    		 
	    		colors: [ '#0066CC', '#fba651', '#336600', '#B00' ], // '#4566A3', '#DC3912', '#F98A1A', 
	    		backgroundColor : '#262626',
	    		legend: {position: 'none'},
//	    		seriesType: 'bars',
//	    		isStacked: true,
//	    		chartArea: {left: 50, width:'58%'},
	    		chartArea:{    left: "18%",
	                top: "6%",
	                bottom:"30%",
	                height: "25%",
	                width: "85%" },
	    };
		
	    var chart = {};
	    
	    chart.data = data;
	    chart.options = options;
	    $scope.chart = chart;
       count++;
	}
	drawConsumptionGraph();
	$interval(drawConsumptionGraph,10000);
});
// Floor Five
app.controller('LightFloorFifthCtrl', function($scope, $filter,$interval,lightingService) {
	var count = 0;
	
	var rotate =function( array , times ){
		var array1=[];  
		while( times-- ){
			 
		    var temp = array.shift();
		    array.push( temp )
		  }
		  for(var i=0;i<array.length;i++){
			  array1.push(new Array(i*10,array[i]));
		  }
		  return array1;
		}
	var drawConsumptionGraph = function(){
	//var result = angular.copy(lightingService.energyConsumptionData);
	
	var graphData=[19.7,19.9,19.6,19.7,20.1,20.5,19.7,19.7,19.7,19.7,19.6,19.5,19.67,
	               19.9,19.7,19.47,19.37,19.57,19.67,19.7,20,21.2,21.3,20.7,20.1,19.8,19.7,19.7,19.7,19.5,19.8,19.7,19.9,19.7,19.7,20.15,20.14,20.56,20.24,20.24,20.12,20.31,20.12,19.9,19.72,19.54,19.36,19.45,19.57,19.84,19.65,19.7,19.95,20.25,20.1,19.81,19.56,19.75,19.6,	19.4];
	
	
	if(count==graphData.length)
		count=0;
	var graphData1=[];
	
	graphData1 = angular.copy(rotate(graphData,count));
	graphData1.splice(0, 0,['seconds','Energy Consumption']);
		var data = new google.visualization.arrayToDataTable(graphData1);
		var options = {
	    		title: '', //Last 7 Days
	    		hAxis : {
	    			title : 'Time ',
	    			//format: 'MMM dd', //'EEE, MMM dd',
	    			textStyle : {
	    				color : '#fff',size: '10px'
	    			},
	    			titleTextStyle : {
	    				color : '#fff',size: '10px'                     
	    			},
	    			gridlines: {
		                 color: 'grey'
		             },
	    		},
	    		vAxis : {
	    			title : 'kWhr',
	    			textStyle : {
	    				color : '#fff',fontSize: '10px',
	    				
	    			},
	    			titleTextStyle : {
	    				color : '#fff',fontSize: '10px',
	    				
	    			},
	    			gridlines: {
		                 color: 'transparent'
		             },
	    		},
	    		 bar: { gap: 0 },
	    		 
	    		colors: [  '#fba651', '#336600', '#B00' ], // '#4566A3', '#DC3912', '#F98A1A', 
	    		backgroundColor : '#262626',
	    		legend: {position: 'none'},
//	    		seriesType: 'bars',
//	    		isStacked: true,
//	    		chartArea: {left: 50, width:'58%'},
	    		chartArea:{    left: "18%",
	                top: "6%",
	                bottom:"30%",
	                height: "25%",
	                width: "85%" },
	    };
		
	    var chart = {};
	    
	    chart.data = data;
	    chart.options = options;
	    $scope.chart = chart;
       count++;
	}
	drawConsumptionGraph();
	$interval(drawConsumptionGraph,10000);
});

// Floor Six

app.controller('LightFloorSixCtrl', function($scope, $filter,$interval,lightingService) {
	var count = 0;
	
	var rotate =function( array , times ){
		var array1=[];  
		while( times-- ){
			 
		    var temp = array.shift();
		    array.push( temp )
		  }
		  for(var i=0;i<array.length;i++){
			  array1.push(new Array(i*10,array[i]));
		  }
		  return array1;
		}
	var drawConsumptionGraph = function(){
	//var result = angular.copy(lightingService.energyConsumptionData);
	
	var graphData=[19.5,19.8,19.7,19.9,19.7,19.7,20.15,20.14,20.56,20.24,20.24,20.12,20.31,20.12,19.9,19.72,19.54,19.7,19.9,19.6,19.7,20.1,20.5,19.9,19.7,19.47,19.37,19.57,19.67,19.7,20,21.2,21.3,20.7,20.1,19.8,19.7,19.7,19.7,19.7,19.7,19.7,19.7,19.6,19.5,19.67,
	19.36,19.45,19.57,19.84,19.65,19.7,19.95,20.25,20.1,19.81,19.56,19.75,19.6,	19.4];
	
	
	if(count==graphData.length)
		count=0;
	var graphData1=[];
	
	graphData1 = angular.copy(rotate(graphData,count));
	graphData1.splice(0, 0,['seconds','Energy Consumption']);
		var data = new google.visualization.arrayToDataTable(graphData1);
		var options = {
	    		title: '', //Last 7 Days
	    		hAxis : {
	    			title : 'Time ',
	    			//format: 'MMM dd', //'EEE, MMM dd',
	    			textStyle : {
	    				color : '#fff',size: '10px'
	    			},
	    			titleTextStyle : {
	    				color : '#fff',size: '10px'                     
	    			},
	    			gridlines: {
		                 color: 'grey'
		             },
	    		},
	    		vAxis : {
	    			title : 'kWhr',
	    			textStyle : {
	    				color : '#fff',fontSize: '10px',
	    				
	    			},
	    			titleTextStyle : {
	    				color : '#fff',fontSize: '10px',
	    				
	    			},
	    			gridlines: {
		                 color: 'transparent'
		             },
	    		},
	    		 bar: { gap: 0 },
	    		 
	    		colors: [  '#336600', '#B00' ], // '#4566A3', '#DC3912', '#F98A1A', 
	    		backgroundColor : '#262626',
	    		legend: {position: 'none'},
//	    		seriesType: 'bars',
//	    		isStacked: true,
//	    		chartArea: {left: 50, width:'58%'},
	    		chartArea:{    left: "18%",
	                top: "6%",
	                bottom:"30%",
	                height: "25%",
	                width: "85%" },
	    };
		
	    var chart = {};
	    
	    chart.data = data;
	    chart.options = options;
	    $scope.chart = chart;
       count++;
	}
	drawConsumptionGraph();
	$interval(drawConsumptionGraph,10000);
});


// Floor Seven

app.controller('LightFloorSevenCtrl', function($scope, $filter,$interval,lightingService) {
	var count = 0;
	
	var rotate =function( array , times ){
		var array1=[];  
		while( times-- ){
			 
		    var temp = array.shift();
		    array.push( temp )
		  }
		  for(var i=0;i<array.length;i++){
			  array1.push(new Array(i*10,array[i]));
		  }
		  return array1;
		}
	var drawConsumptionGraph = function(){
	//var result = angular.copy(lightingService.energyConsumptionData);
	
	var graphData=[20,21.2,21.3,20.7,20.1,19.8,19.7,19.7,19.7,19.7,19.7,19.7,19.7,19.6,19.5,19.67,
	19.5,19.8,19.7,19.9,19.7,19.7,20.15,20.14,20.56,20.24,20.24,20.12,20.31,20.12,19.9,19.72,19.54,19.36,19.45,19.57,19.84,19.65,19.7,19.95,20.25,20.1,19.81,
	19.7,19.9,19.6,19.7,20.1,20.5,19.9,19.7,19.47,19.37,19.57,19.67,19.7,19.56,19.75,19.6,	19.4];
	
	
	if(count==graphData.length)
		count=0;
	var graphData1=[];
	
	graphData1 = angular.copy(rotate(graphData,count));
	graphData1.splice(0, 0,['seconds','Energy Consumption']);
		var data = new google.visualization.arrayToDataTable(graphData1);
		var options = {
	    		title: '', //Last 7 Days
	    		hAxis : {
	    			title : 'Time ',
	    			//format: 'MMM dd', //'EEE, MMM dd',
	    			textStyle : {
	    				color : '#fff',size: '10px'
	    			},
	    			titleTextStyle : {
	    				color : '#fff',size: '10px'                     
	    			},
	    			gridlines: {
		                 color: 'grey'
		             },
	    		},
	    		vAxis : {
	    			title : 'kWhr',
	    			textStyle : {
	    				color : '#fff',fontSize: '10px',
	    				
	    			},
	    			titleTextStyle : {
	    				color : '#fff',fontSize: '10px',
	    				
	    			},
	    			gridlines: {
		                 color: 'transparent'
		             },
	    		},
	    		 bar: { gap: 0 },
	    		 
	    		colors: [ '#0066CC', '#fba651', '#336600', '#B00' ], // '#4566A3', '#DC3912', '#F98A1A', 
	    		backgroundColor : '#262626',
	    		legend: {position: 'none'},
//	    		seriesType: 'bars',
//	    		isStacked: true,
//	    		chartArea: {left: 50, width:'58%'},
	    		chartArea:{    left: "18%",
	                top: "6%",
	                bottom:"30%",
	                height: "25%",
	                width: "85%" },
	    };
		
	    var chart = {};
	    
	    chart.data = data;
	    chart.options = options;
	    $scope.chart = chart;
       count++;
	}
	drawConsumptionGraph();
	$interval(drawConsumptionGraph,5000);
});




