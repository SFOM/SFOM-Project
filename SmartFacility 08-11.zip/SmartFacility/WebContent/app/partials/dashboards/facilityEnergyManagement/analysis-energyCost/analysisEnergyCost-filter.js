/***
 * 
 */

// returns 'Date-Time' & Consumption values
app.filter('eqptDataFilter', function() {

	  return function(arrInput, propertyIndex, valueToCompare) {

	    var arrOutput = [];
	    angular.forEach(arrInput, function(iValue, iKey) {

	      if ((iValue[propertyIndex]).toLowerCase() == valueToCompare.toLowerCase()) {
	    	  arrOutput.push( [ iValue[0], iValue[2] ] );
	      }
	    })
	    return arrOutput;
	  }
	});