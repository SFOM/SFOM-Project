app.controller('equipmentWisePerformanceCntr', function($scope) {
	
	
});


app.controller('reduceCo2FootprintCntr', function($scope) {
	
	$scope.co2Measures = function() {
		//console.log("Selected " + $scope.radioModel);	
		if($scope.radioModel == 'Building'){
			$scope.measures2ReduceCo2="1. Energy Efficiency by Design   2. Energy Efficient Equipment";
			$scope.widthCo2=220;
			$scope.leftCo2=10;
			$scope.backColor="#27D239";
		} else if($scope.radioModel == 'IT'){
			$scope.measures2ReduceCo2='1. Green Procurement 2. Server Virtualization' + '   ' +  '   ' +  '3. Server Consolidation 4. Cooling Optimization';
			$scope.widthCo2=320;
			$scope.leftCo2=100;
			$scope.backColor="#C8D227";
		}else if($scope.radioModel == 'Efficient'){
			$scope.measures2ReduceCo2='1. Operational Efficiency 2. Remote Energy Monitoring and Control ';
			$scope.widthCo2=300;
			$scope.leftCo2=230;
			$scope.backColor="#E9967A";
		}else if($scope.radioModel == 'Renewable'){
			$scope.measures2ReduceCo2='1. Onsite RE Installations, Solar PV & Solar Thermal 2. Procurement of RE from Third Parties ';
			$scope.widthCo2=360;
			$scope.leftCo2=240;
			$scope.backColor="#3399ff;";
		}
	}
	
	$scope.Co2="Hi <br> Bro";
	
	$scope.radioModel = 'Building';
	$scope.co2Measures();
	
	
	
	
/*	function show()
	 {
	       var div1 = document.getElementById("co2MeasuresContent");
	
	    div1.style.display = "block";
	
	 }
	*/
	
});


app.controller('Co2PieChartCtrl', function($scope) {

	drawChart();

	function drawChart() {
		var data3 = google.visualization.arrayToDataTable([
				[ 'Source', 'Consumption' ], [ 'Electricity from Grid', 92.31 ], [ 'Electricity from Green Sources',3.14 ],
				[ 'Electricity from onsite fuel combustion sources', 4.55 ]]);

		var options3 = {
				
				//title : 'Break-up of Electricity Consumption by Source (%)',
				
			legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
			//pieSliceText : 'label',   /*we get the slice label in text instead of % number */
			
			pieHole : 0.3,
			backgroundColor : '#262626',
			is3D : true,

			chartArea : {
				width : '90%',
				height : '95%', 
					left :'10'
			},
			title : 'Reduction in Paper consumption ',
			titleTextStyle : {
				color : '#fff'                     
	
			},
						 
		};

		var chart = new google.visualization.PieChart(document.getElementById('Co2PieChart'));
		chart.draw(data3, options3);
	}

});


app.controller('reductionPaperconsumpBarChartCtrl', function($scope) {

	drawChart();

	function drawChart() {
		
		var data6 = google.visualization.arrayToDataTable([
		                                                   ['Year', 'Target', 'Actual'],
		                                                   ['2010-11', 72, 65],
		                                                   ['2011-12', 65, 59],
		                                                   ['2012-13', 55, 50],
		                                                   ['2013-14', 51, 47],
		                                                   ['2014-15', 50, 45],
		                                                   ['2015-16', 47, 42]]);	
	      	      
		var options6 = {
				
				/*title : 'Reduction in Paper consumption ',
				titleTextStyle : {
					color : '#fff'                     
		
				},*/
				 is3D:true,
				 legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
				hAxis : {
					title : 'Year',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : 'Reams/1000FTE/Month',
					textStyle : {
						color : '#fff',
						font: '8'
					},
					titleTextStyle : {
						color : '#fff',
						font: '8'
					},
				},
				backgroundColor : '#262626',
				//isStacked: true,		  
				chartArea:{                   //top: 10,left:65,
		        	width:'70%',height:'45%', 
		        		}
			};

		var chart = new google.visualization.ColumnChart(document.getElementById('reductionPaperconsumpBarChart'));
		chart.draw(data6, options6);
	}

});



app.controller('electricityConsmBarChartCtrl', function($scope) {

	drawChart();

	function drawChart() {
		
		var data6 = google.visualization.arrayToDataTable([
		                                                   ['Year', 'Cons'],
		                                                   ['2010-11', 222],
		                                                   ['2011-12', 208],
		                                                   ['2012-13', 195],
		                                                   ['2013-14', 176],
		                                                   ['2014-15', 168],
		                                                   ['2015-16', 160]]);	
	      	      
		var options6 = {
				
				/*title : 'Reduction in Paper consumption ',
				titleTextStyle : {
					color : '#fff'                     
		
				},*/
				 is3D:true,
				 //legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
				 legend : 'none',
				hAxis : {
					title : 'Year',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : 'kWh/month',
					textStyle : {
						color : '#fff',
						font: '8'
					},
					titleTextStyle : {
						color : '#fff',
						font: '8'
					},
				},
				backgroundColor : '#262626',
				//isStacked: true,		  
				chartArea:{                   //top: 10,left:65,
		        	width:'75%',height:'35%',left:'60'
		        		}
			};

		var chart = new google.visualization.ColumnChart(document.getElementById('electricityConsmBarChart'));
		chart.draw(data6, options6);
	}

});









app.controller('carbonFootprintDistrBarChartCtrl', function($scope) {

	drawChart();

	function drawChart() {
		
		var data6 = google.visualization.arrayToDataTable([
		                                                   ['Year', '2012-13', '2013-14', '2014-15', '2015-16'],		                                                   
		                                                   ['Scope 1', 58691, 56691, 34263, 31924],
		                                                   ['Scope 2', 300555, 378214, 423777, 439400]
		                                                   ]);			
				
		/*[
         ['Year', 'Scope 1', 'Scope 2'],		                                                   
         ['2012-13', 58691, 300555],
         ['2013-14', 56691, 378214],
         ['2014-15', 34263, 423777],
         ['2015-16', 31924, 439400]]*/
	      	      
		var options6 = {
				
				/*title : 'Reduction in Paper consumption ',
				titleTextStyle : {
					color : '#fff'                     
		
				},*/
				 is3D:true,
				 legend : {position: 'right', textStyle: { color: 'white', fontSize: 10}},
				hAxis : {
					title1 : 'Scope 1',
					title2 : 'Scope 2',
					textStyle : {
						color : '#fff'
					},
					titleTextStyle : {
						color : '#fff'
					},
				},
				vAxis : {
					title : 'Co2 Equivalent',
					textStyle : {
						color : '#fff',
						font: '8'
					},
					titleTextStyle : {
						color : '#fff',
						font: '8'
					},
				},
				backgroundColor : '#262626',
				//isStacked: true,		  
				chartArea:{                   //top: 10,left:65,
		        	width:'60%',height:'65%'
		        		}
			};

		var chart = new google.visualization.ColumnChart(document.getElementById('carbonFootprintDistrBarChart'));
		chart.draw(data6, options6);
	}

});
