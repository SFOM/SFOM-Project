/** 
 * get/set selected location details (Place, Building, Floor)
 * selLocationService: Added by #246292 (Lekha)
 */

app.service('heatMapService', function() {						
	this.floorMapList = [
             //S2
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.2', subLocDesc:'S2', floorId:'1', floorMap:'app/assets/images/floorHeatMap/S2Floor-1.jpg'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.2', subLocDesc:'S2', floorId:'2', floorMap:'app/assets/images/floorHeatMap/S2Floor-2.jpg'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.2', subLocDesc:'S2', floorId:'3', floorMap:'app/assets/images/floorHeatMap/S2Floor-3.jpg'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.2', subLocDesc:'S2', floorId:'4', floorMap:'app/assets/images/floorHeatMap/S2Floor-4.jpg'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.2', subLocDesc:'S2', floorId:'5', floorMap:'app/assets/images/floorHeatMap/S2Floor-5.jpg'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.2', subLocDesc:'S2', floorId:'6', floorMap:'app/assets/images/floorHeatMap/S2Floor-6.jpg'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.2', subLocDesc:'S2', floorId:'7', floorMap:'app/assets/images/floorHeatMap/S2Floor-7.jpg'},
             //S1
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.1', subLocDesc:'S1', floorId:'1', floorMap:'Floor-1'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.1', subLocDesc:'S1', floorId:'2', floorMap:'Floor-2'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.1', subLocDesc:'S1', floorId:'3', floorMap:'Floor-3'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.1', subLocDesc:'S1', floorId:'4', floorMap:'Floor-4'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.1', subLocDesc:'S1', floorId:'5', floorMap:'Floor-5'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.1', subLocDesc:'S1', floorId:'6', floorMap:'Floor-6'},
             { locId: '1', locDesc:'TCS Pune', subLocId:'1.1', subLocDesc:'S1', floorId:'7', floorMap:'Floor-7'}
         ];
	
	// Assumption : showing consumption(KWh) for a day before, Range: 0 to 40 - green,  40 to 70 - yellow, 70 to 100 - Red
	//Floor Map
	
	this.AHU_consumption = [
	                        //S2
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', consumption:280 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', consumption:260 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', consumption:306 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', consumption:284 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', consumption:275 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', consumption:294 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', consumption:255 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', consumption:282 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', consumption:271 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', consumption:301 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', consumption:279 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', consumption:265 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', consumption:245 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', consumption:253 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', consumption:286 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', consumption:274 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', consumption:262 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', consumption:270 },
	        
	        
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', consumption:265 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', consumption:258 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', consumption:270 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', consumption:279 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', consumption:271 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', consumption:302 },
	        

	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', consumption:252 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', consumption:237 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', consumption:261 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', consumption:277 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', consumption:272 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', consumption:304 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', consumption:305 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', consumption:307 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', consumption:275 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', consumption:280 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', consumption:263 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', consumption:309 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', consumption:271 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', consumption:275 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', consumption:265 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', consumption:282 },
	        
        ];
	
	this.AHU_ZoneCoordinates = [
	                        //S2   ///////   crlX = width/2 + rectX, crlY = height/2 + rectY                     
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', rectX:42, rectY:58, width:146, height:112, crlX:115, crlY:114 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', rectX:194, rectY:58, width:183, height:112, crlX:286, crlY:114 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', rectX:495, rectY:50, width:298, height:120, crlX:644, crlY:110 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', rectX:80, rectY:294, width:222, height:112, crlX:191, crlY:351 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', rectX:532, rectY:294, width:222, height:112, crlX:643, crlY:351 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', rectX:443, rectY:290, width:83, height:164, crlX:485, crlY:368 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', rectX:38, rectY:48, width:226, height:124, crlX:151, crlY:110 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', rectX:270, rectY:48, width:227, height:124, crlX:384, crlY:110 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', rectX:502, rectY:48, width:302, height:124, crlX:651, crlY:110 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', rectX:77, rectY:294, width:228, height:116, crlX:191, crlY:352 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', rectX:538, rectY:294, width:228, height:116, crlX:652, crlY:352 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', rectX:426, rectY:294, width:106, height:166, crlX:479, crlY:377 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', rectX:42, rectY:58, width:146, height:112, crlX:115, crlY:114 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', rectX:194, rectY:58, width:183, height:112, crlX:286, crlY:114 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', rectX:495, rectY:50, width:298, height:120, crlX:644, crlY:110 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', rectX:80, rectY:294, width:222, height:112, crlX:191, crlY:351 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', rectX:532, rectY:294, width:222, height:112, crlX:643, crlY:351 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', rectX:443, rectY:290, width:83, height:164, crlX:485, crlY:368 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', rectX:42, rectY:58, width:146, height:112, crlX:115, crlY:114 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', rectX:194, rectY:58, width:183, height:112, crlX:286, crlY:114 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', rectX:495, rectY:50, width:298, height:120, crlX:644, crlY:110 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', rectX:80, rectY:294, width:222, height:112, crlX:191, crlY:351 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', rectX:532, rectY:294, width:222, height:112, crlX:643, crlY:351 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', rectX:443, rectY:290, width:83, height:164, crlX:485, crlY:368 },
	        
	        
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', rectX:36, rectY:48, width:154, height:140, crlX:113, crlY:118 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', rectX:346, rectY:48, width:228, height:140, crlX:460, crlY:118 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', rectX:576, rectY:48, width:230, height:140, crlX:691, crlY:118 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', rectX:77, rectY:294, width:228, height:116, crlX:191, crlY:352 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', rectX:538, rectY:294, width:230, height:116, crlX:653, crlY:352 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', rectX:426, rectY:294, width:106, height:166, crlX:479, crlY:377 },
	        
	        
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', rectX:36, rectY:48, width:154, height:140, crlX:113, crlY:118 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', rectX:346, rectY:48, width:228, height:140, crlX:460, crlY:118 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', rectX:576, rectY:48, width:230, height:140, crlX:691, crlY:118 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', rectX:77, rectY:294, width:228, height:116, crlX:191, crlY:352 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', rectX:538, rectY:294, width:230, height:116, crlX:653, crlY:352 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', rectX:36, rectY:48, width:154, height:140, crlX:113, crlY:118 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', rectX:346, rectY:48, width:228, height:140, crlX:460, crlY:118 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', rectX:576, rectY:48, width:230, height:140, crlX:691, crlY:118 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', rectX:77, rectY:294, width:228, height:116, crlX:191, crlY:352 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', rectX:538, rectY:294, width:230, height:116, crlX:653, crlY:352 },
	        
        ];

	// Assumption : showing consumption(KWh) for a day before, Range: 0 to 40 - green,  40 to 70 - yellow, 70 to 100 - Red
	//Last 7 Days consumption
	this.AHU_consumption_lastWeek = [
	                        //S2 First Floor
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-21', consumption:285 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-22', consumption:305 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-23', consumption:229 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-24', consumption:272 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-25', consumption:306 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-21', consumption:275 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-23', consumption:272 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-24', consumption:280 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-25', consumption:236 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-26', consumption:229 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-28', consumption:055 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-21', consumption:250 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-22', consumption:275 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-23', consumption:256 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-24', consumption:272 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-25', consumption:306 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-26', consumption:268 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-21', consumption:250 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-22', consumption:275 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-23', consumption:309 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-24', consumption:272 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-25', consumption:306 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-21', consumption:250 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-23', consumption:269 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-24', consumption:257 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-25', consumption:266 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-28', consumption:305 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-21', consumption:225 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-22', consumption:252 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-23', consumption:270 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-24', consumption:265 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-25', consumption:268 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-26', consumption:269 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-28', consumption:242 },  // Sat
	        
            //S2 Second Floor
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-21', consumption:285 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-23', consumption:290 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-24', consumption:272 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-25', consumption:306 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-21', consumption:265 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-22', consumption:305 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-23', consumption:272 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-24', consumption:280 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-25', consumption:236 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-26', consumption:229 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-21', consumption:235 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-22', consumption:315 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-23', consumption:256 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-24', consumption:272 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-25', consumption:236 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-26', consumption:268 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-21', consumption:225 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-23', consumption:229 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-24', consumption:272 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-25', consumption:306 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-21', consumption:265 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-23', consumption:269 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-24', consumption:257 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-25', consumption:266 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-21', consumption:275 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-22', consumption:252 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-23', consumption:270 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-24', consumption:265 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-25', consumption:268 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-26', consumption:269 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-28', consumption:302 },  // Sat
	        
	        
	        //S2 Third Floor
	        
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-21', consumption:251 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-23', consumption:290 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-24', consumption:272 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-25', consumption:236 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-21', consumption:258 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-22', consumption:305 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-23', consumption:272 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-24', consumption:280 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-25', consumption:306 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-26', consumption:293 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-21', consumption:235 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-22', consumption:250 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-23', consumption:261 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-24', consumption:272 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-25', consumption:306 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-26', consumption:268 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-21', consumption:250 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-22', consumption:305 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-23', consumption:290 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-24', consumption:272 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-25', consumption:306 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-21', consumption:250 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-22', consumption:302 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-23', consumption:269 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-24', consumption:257 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-25', consumption:266 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-21', consumption:250 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-22', consumption:252 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-23', consumption:270 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-24', consumption:265 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-25', consumption:268 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-26', consumption:269 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-28', consumption:242 },  // Sat
	        
	        
	        //S2 Fourth Floor
	        
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-21', consumption:250 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-23', consumption:239 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-24', consumption:272 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-25', consumption:236 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-21', consumption:255 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-23', consumption:272 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-24', consumption:280 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-25', consumption:306 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-26', consumption:209 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-21', consumption:245 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-23', consumption:256 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-24', consumption:272 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-25', consumption:306 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-26', consumption:268 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-21', consumption:258 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-23', consumption:290 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-24', consumption:272 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-25', consumption:236 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-21', consumption:250 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-23', consumption:269 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-24', consumption:257 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-25', consumption:266 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-21', consumption:250 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-22', consumption:252 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-23', consumption:270 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-24', consumption:265 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-25', consumption:268 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-26', consumption:269 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-28', consumption:242 },  // Sat
	        
	        
	        //S2 Fifth Floor
	        

	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-21', consumption:255 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-23', consumption:229 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-24', consumption:272 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-25', consumption:236 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-21', consumption:225 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-23', consumption:272 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-24', consumption:280 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-25', consumption:236 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-26', consumption:229 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-21', consumption:275 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-22', consumption:315 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-23', consumption:256 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-24', consumption:272 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-25', consumption:236 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-26', consumption:268 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-21', consumption:251 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-23', consumption:29 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-24', consumption:272 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-25', consumption:236 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-21', consumption:251 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-23', consumption:269 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-24', consumption:257 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-25', consumption:266 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-21', consumption:225 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-22', consumption:252 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-23', consumption:270 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-24', consumption:265 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-25', consumption:268 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-26', consumption:269 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-28', consumption:242 },  // Sat
	        
	        
	        // S2 SIXTH FLOOR
	        
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-21', consumption:225 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-23', consumption:229 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-24', consumption:272 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-25', consumption:236 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-21', consumption:257 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-22', consumption:234 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-23', consumption:272 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-24', consumption:280 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-25', consumption:236 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-26', consumption:229 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-21', consumption:259 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-23', consumption:256 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-24', consumption:272 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-25', consumption:236 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-26', consumption:268 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-21', consumption:225 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-23', consumption:290 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-24', consumption:272 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-25', consumption:306 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-21', consumption:251 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-23', consumption:69 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-24', consumption:257 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-25', consumption:266 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-28', consumption:255 },  // Sat
	        
	        //S2 SEVENTH FLOOR
	        
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-21', consumption:25 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-23', consumption:290 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-24', consumption:272 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-25', consumption:306 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-21', consumption:215 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-23', consumption:272 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-24', consumption:280 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-25', consumption:236 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-26', consumption:290 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-28', consumption:255 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-21', consumption:25 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-22', consumption:45 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-23', consumption:56 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-24', consumption:72 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-25', consumption:36 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-26', consumption:68 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-28', consumption:55 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-21', consumption:25 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-22', consumption:45 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-23', consumption:29 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-24', consumption:72 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-25', consumption:36 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-26', consumption:80 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-28', consumption:55 },  // Sat
	        
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-21', consumption:252 }, //Sun
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-22', consumption:245 },  // Mon
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-23', consumption:269 },  // Tue
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-24', consumption:257 },  // Wed
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-25', consumption:266 },  // Thu
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-26', consumption:280 },  // Fri
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-28', consumption:255 },  // Sat
	        
	        


        ];
	
	
	// Assumption : showing consumption(KWh) for a day before, Range: 0 to 1 - green,  1 to 2 - yellow, Above 2 - Red
	//Todays' data at each hour
	this.AHU_consumption_today = [
	     	                        //S2 First Floor
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'00:00', consumption:40.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'01:00', consumption:40.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'02:00', consumption:30.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_1', date:'2016-08-30', time:'23:00', consumption:1.5 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_2', date:'2016-08-30', time:'23:00', consumption:1.5 },
	     	   
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'00:00', consumption:1.1 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'01:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'04:00', consumption:0.75 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'05:00', consumption:0.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'06:00', consumption:1.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'07:00', consumption:1.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'08:00', consumption:2.1 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'09:00', consumption:2.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'10:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'11:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'12:00', consumption:2.85 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'13:00', consumption:3.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'14:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'15:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'16:00', consumption:3.25 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'17:00', consumption:2.6 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'18:00', consumption:2.2 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'19:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'20:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'21:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'22:00', consumption:1.1 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_3', date:'2016-08-30', time:'23:00', consumption:1.11 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'00:00', consumption:1.1 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'01:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'04:00', consumption:0.75 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'05:00', consumption:0.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'06:00', consumption:1.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'07:00', consumption:1.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'08:00', consumption:2.1 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'09:00', consumption:2.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'10:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'11:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'12:00', consumption:2.85 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'13:00', consumption:3.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'14:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'15:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'16:00', consumption:3.25 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'17:00', consumption:2.6 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'18:00', consumption:2.2 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'19:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'20:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'21:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'22:00', consumption:1.1 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_4', date:'2016-08-30', time:'23:00', consumption:1.11 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_5', date:'2016-08-30', time:'23:00', consumption:1.5 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'00:00', consumption:1.1 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'01:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'04:00', consumption:0.75 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'05:00', consumption:0.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'06:00', consumption:1.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'07:00', consumption:1.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'08:00', consumption:2.1 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'09:00', consumption:2.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'10:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'11:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'12:00', consumption:2.85 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'13:00', consumption:3.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'14:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'15:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'16:00', consumption:3.25 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'17:00', consumption:2.6 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'18:00', consumption:2.2 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'19:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'20:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'21:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'22:00', consumption:1.1 },
	        { locId: '1', subLocId:'1.2', floorId:'1', meterId:'AHU_6', date:'2016-08-30', time:'23:00', consumption:1.11 },
 	        
            //S2 Second Floor
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_1', date:'2016-08-30', time:'23:00', consumption:1.5 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_2', date:'2016-08-30', time:'23:00', consumption:1.5 },
	     	   
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'00:00', consumption:1.1 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'01:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'04:00', consumption:0.75 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'05:00', consumption:0.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'06:00', consumption:1.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'07:00', consumption:1.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'08:00', consumption:2.1 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'09:00', consumption:2.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'10:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'11:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'12:00', consumption:2.85 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'13:00', consumption:3.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'14:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'15:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'16:00', consumption:3.25 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'17:00', consumption:2.6 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'18:00', consumption:2.2 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'19:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'20:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'21:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'22:00', consumption:1.1 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_3', date:'2016-08-30', time:'23:00', consumption:1.11 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'00:00', consumption:1.1 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'01:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'04:00', consumption:0.75 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'05:00', consumption:0.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'06:00', consumption:1.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'07:00', consumption:1.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'08:00', consumption:2.1 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'09:00', consumption:2.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'10:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'11:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'12:00', consumption:2.85 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'13:00', consumption:3.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'14:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'15:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'16:00', consumption:3.25 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'17:00', consumption:2.6 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'18:00', consumption:2.2 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'19:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'20:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'21:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'22:00', consumption:1.1 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_4', date:'2016-08-30', time:'23:00', consumption:1.11 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_5', date:'2016-08-30', time:'23:00', consumption:1.5 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'00:00', consumption:1.1 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'01:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'04:00', consumption:0.75 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'05:00', consumption:0.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'06:00', consumption:1.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'07:00', consumption:1.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'08:00', consumption:2.1 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'09:00', consumption:2.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'10:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'11:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'12:00', consumption:2.85 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'13:00', consumption:3.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'14:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'15:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'16:00', consumption:3.25 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'17:00', consumption:2.6 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'18:00', consumption:2.2 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'19:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'20:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'21:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'22:00', consumption:1.1 },
	        { locId: '1', subLocId:'1.2', floorId:'2', meterId:'AHU_6', date:'2016-08-30', time:'23:00', consumption:1.11 },
	        
	      //S2 Third Floor
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_1', date:'2016-08-30', time:'23:00', consumption:1.5 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_2', date:'2016-08-30', time:'23:00', consumption:1.5 },
	     	   
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'00:00', consumption:1.1 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'01:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'04:00', consumption:0.75 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'05:00', consumption:0.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'06:00', consumption:1.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'07:00', consumption:1.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'08:00', consumption:2.1 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'09:00', consumption:2.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'10:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'11:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'12:00', consumption:2.85 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'13:00', consumption:3.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'14:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'15:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'16:00', consumption:3.25 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'17:00', consumption:2.6 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'18:00', consumption:2.2 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'19:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'20:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'21:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'22:00', consumption:1.1 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_3', date:'2016-08-30', time:'23:00', consumption:1.11 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'00:00', consumption:1.1 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'01:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'04:00', consumption:0.75 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'05:00', consumption:0.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'06:00', consumption:1.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'07:00', consumption:1.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'08:00', consumption:2.1 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'09:00', consumption:2.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'10:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'11:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'12:00', consumption:2.85 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'13:00', consumption:3.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'14:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'15:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'16:00', consumption:3.25 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'17:00', consumption:2.6 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'18:00', consumption:2.2 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'19:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'20:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'21:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'22:00', consumption:1.1 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_4', date:'2016-08-30', time:'23:00', consumption:1.11 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_5', date:'2016-08-30', time:'23:00', consumption:1.5 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'00:00', consumption:1.1 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'01:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'04:00', consumption:0.75 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'05:00', consumption:0.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'06:00', consumption:1.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'07:00', consumption:1.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'08:00', consumption:2.1 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'09:00', consumption:2.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'10:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'11:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'12:00', consumption:2.85 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'13:00', consumption:3.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'14:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'15:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'16:00', consumption:3.25 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'17:00', consumption:2.6 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'18:00', consumption:2.2 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'19:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'20:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'21:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'22:00', consumption:1.1 },
	        { locId: '1', subLocId:'1.2', floorId:'3', meterId:'AHU_6', date:'2016-08-30', time:'23:00', consumption:1.11 },
	        
	        
	        //S2 Fourth Floor
	        
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_1', date:'2016-08-30', time:'23:00', consumption:1.5 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_2', date:'2016-08-30', time:'23:00', consumption:1.5 },
	     	   
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'00:00', consumption:1.1 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'01:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'04:00', consumption:0.75 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'05:00', consumption:0.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'06:00', consumption:1.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'07:00', consumption:1.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'08:00', consumption:2.1 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'09:00', consumption:2.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'10:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'11:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'12:00', consumption:2.85 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'13:00', consumption:3.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'14:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'15:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'16:00', consumption:3.25 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'17:00', consumption:2.6 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'18:00', consumption:2.2 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'19:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'20:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'21:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'22:00', consumption:1.1 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_3', date:'2016-08-30', time:'23:00', consumption:1.11 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'00:00', consumption:1.1 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'01:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'04:00', consumption:0.75 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'05:00', consumption:0.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'06:00', consumption:1.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'07:00', consumption:1.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'08:00', consumption:2.1 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'09:00', consumption:2.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'10:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'11:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'12:00', consumption:2.85 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'13:00', consumption:3.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'14:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'15:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'16:00', consumption:3.25 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'17:00', consumption:2.6 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'18:00', consumption:2.2 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'19:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'20:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'21:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'22:00', consumption:1.1 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_4', date:'2016-08-30', time:'23:00', consumption:1.11 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_5', date:'2016-08-30', time:'23:00', consumption:1.5 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'00:00', consumption:1.1 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'01:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'04:00', consumption:0.75 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'05:00', consumption:0.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'06:00', consumption:1.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'07:00', consumption:1.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'08:00', consumption:2.1 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'09:00', consumption:2.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'10:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'11:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'12:00', consumption:2.85 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'13:00', consumption:3.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'14:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'15:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'16:00', consumption:3.25 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'17:00', consumption:2.6 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'18:00', consumption:2.2 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'19:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'20:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'21:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'22:00', consumption:1.1 },
	        { locId: '1', subLocId:'1.2', floorId:'4', meterId:'AHU_6', date:'2016-08-30', time:'23:00', consumption:1.11 },

            //S2 Fifth Floor
	        
	        
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_1', date:'2016-08-30', time:'23:00', consumption:1.5 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_2', date:'2016-08-30', time:'23:00', consumption:1.5 },
	     	   
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'00:00', consumption:1.1 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'01:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'04:00', consumption:0.75 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'05:00', consumption:0.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'06:00', consumption:1.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'07:00', consumption:1.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'08:00', consumption:2.1 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'09:00', consumption:2.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'10:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'11:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'12:00', consumption:2.85 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'13:00', consumption:3.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'14:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'15:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'16:00', consumption:3.25 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'17:00', consumption:2.6 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'18:00', consumption:2.2 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'19:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'20:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'21:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'22:00', consumption:1.1 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_3', date:'2016-08-30', time:'23:00', consumption:1.11 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'00:00', consumption:1.1 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'01:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'04:00', consumption:0.75 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'05:00', consumption:0.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'06:00', consumption:1.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'07:00', consumption:1.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'08:00', consumption:2.1 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'09:00', consumption:2.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'10:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'11:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'12:00', consumption:2.85 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'13:00', consumption:3.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'14:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'15:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'16:00', consumption:3.25 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'17:00', consumption:2.6 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'18:00', consumption:2.2 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'19:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'20:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'21:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'22:00', consumption:1.1 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_4', date:'2016-08-30', time:'23:00', consumption:1.11 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_5', date:'2016-08-30', time:'23:00', consumption:1.5 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'00:00', consumption:1.1 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'01:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'04:00', consumption:0.75 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'05:00', consumption:0.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'06:00', consumption:1.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'07:00', consumption:1.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'08:00', consumption:2.1 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'09:00', consumption:2.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'10:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'11:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'12:00', consumption:2.85 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'13:00', consumption:3.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'14:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'15:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'16:00', consumption:3.25 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'17:00', consumption:2.6 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'18:00', consumption:2.2 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'19:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'20:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'21:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'22:00', consumption:1.1 },
	        { locId: '1', subLocId:'1.2', floorId:'5', meterId:'AHU_6', date:'2016-08-30', time:'23:00', consumption:1.11 },

	        // S2 SIXTH FLOOR
	        
	        
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_1', date:'2016-08-30', time:'23:00', consumption:1.5 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_2', date:'2016-08-30', time:'23:00', consumption:1.5 },
	     	   
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'00:00', consumption:1.1 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'01:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'04:00', consumption:0.75 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'05:00', consumption:0.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'06:00', consumption:1.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'07:00', consumption:1.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'08:00', consumption:2.1 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'09:00', consumption:2.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'10:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'11:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'12:00', consumption:2.85 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'13:00', consumption:3.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'14:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'15:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'16:00', consumption:3.25 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'17:00', consumption:2.6 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'18:00', consumption:2.2 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'19:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'20:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'21:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'22:00', consumption:1.1 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_3', date:'2016-08-30', time:'23:00', consumption:1.11 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'00:00', consumption:1.1 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'01:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'04:00', consumption:0.75 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'05:00', consumption:0.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'06:00', consumption:1.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'07:00', consumption:1.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'08:00', consumption:2.1 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'09:00', consumption:2.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'10:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'11:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'12:00', consumption:2.85 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'13:00', consumption:3.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'14:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'15:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'16:00', consumption:3.25 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'17:00', consumption:2.6 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'18:00', consumption:2.2 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'19:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'20:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'21:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'22:00', consumption:1.1 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_4', date:'2016-08-30', time:'23:00', consumption:1.11 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'6', meterId:'AHU_5', date:'2016-08-30', time:'23:00', consumption:1.5 },
	        

	        // S2 SEVENTH FLOOR 
	        
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_1', date:'2016-08-30', time:'23:00', consumption:1.5 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_2', date:'2016-08-30', time:'23:00', consumption:1.5 },
	     	   
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'00:00', consumption:1.1 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'01:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'04:00', consumption:0.75 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'05:00', consumption:0.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'06:00', consumption:1.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'07:00', consumption:1.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'08:00', consumption:2.1 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'09:00', consumption:2.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'10:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'11:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'12:00', consumption:2.85 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'13:00', consumption:3.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'14:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'15:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'16:00', consumption:3.25 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'17:00', consumption:2.6 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'18:00', consumption:2.2 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'19:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'20:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'21:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'22:00', consumption:1.1 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_3', date:'2016-08-30', time:'23:00', consumption:1.11 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'00:00', consumption:1.1 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'01:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'04:00', consumption:0.75 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'05:00', consumption:0.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'06:00', consumption:1.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'07:00', consumption:1.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'08:00', consumption:2.1 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'09:00', consumption:2.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'10:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'11:00', consumption:2.9 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'12:00', consumption:2.85 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'13:00', consumption:3.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'14:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'15:00', consumption:3.2 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'16:00', consumption:3.25 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'17:00', consumption:2.6 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'18:00', consumption:2.2 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'19:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'20:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'21:00', consumption:1.5 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'22:00', consumption:1.1 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_4', date:'2016-08-30', time:'23:00', consumption:1.11 },
	        
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'00:00', consumption:0.5 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'01:00', consumption:0.2 }, 
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'02:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'03:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'04:00', consumption:0 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'05:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'06:00', consumption:0.2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'07:00', consumption:0.4 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'08:00', consumption:0.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'09:00', consumption:0.8 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'10:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'11:00', consumption:2 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'12:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'13:00', consumption:2.5 },
 	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'14:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'15:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'16:00', consumption:2 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'17:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'18:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'19:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'20:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'21:00', consumption:2.5 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'22:00', consumption:2.0 },
	        { locId: '1', subLocId:'1.2', floorId:'7', meterId:'AHU_5', date:'2016-08-30', time:'23:00', consumption:1.5 },
	        
         ];
	
});




