app.controller('heatMapCtrl', function($scope, $filter, selLocationService, heatMapService) {
	$scope.viewDataModel = 0;      // default value
	$scope.AhuModel_lastWeek = 'AHU_1';
	$scope.AhuModel_hourlyToday = 'AHU_1';
	$scope.lblMap;
	$scope.lblAHU;

	/**** Supporting Functions ****/
	
	/** Assumption : showing consumption(KWh) for a day before, 
	 * Range: 0 to 40 - green,  40 to 70 - yellow, 70 to 100 - Red
	 */
	var getZoneBorderColor = function(varConsumption){
		if(varConsumption > 0 && varConsumption <= 250){
			return '#319831'; //'rgba(0, 255, 0, 1)';
		}else if(varConsumption > 250 && varConsumption <= 290){
			return 'rgba(255, 194, 0, 1)';
		}else if(varConsumption > 290 && varConsumption <= 350){
			return 'rgba(255, 0, 0, 1)';
		}
	};
	
	/** Assumption : showing consumption(KWh) for a day before, 
	 * Range: 0 to 40 - green,  40 to 70 - yellow, 70 to 100 - Red
	 */
	var getZoneConsumptionColor = function(varConsumption){
		if(varConsumption > 0 && varConsumption <= 40){
			return 'rgba(20, 204, 20, 0.6)'; //'rgba(49, 150, 49, 0.5)';
		}else if(varConsumption > 40 && varConsumption <= 70){
			return 'rgba(255, 194, 0, 0.7)';
		}else if(varConsumption > 70 && varConsumption <= 100){
			return 'rgba(255, 0, 0, 0.6)';
		}
	};
	
	var drawRectangle = function(ctx, varConsumption, varCoordinates){
		ctx.beginPath();
		ctx.rect(varCoordinates.rectX, varCoordinates.rectY, varCoordinates.width, varCoordinates.height);
		//ctx.rect(x, y, width, height);
		ctx.fillStyle = 'rgba(255,255,255,0)'; // transparent
		ctx.fill();
		ctx.lineWidth = 3;
		ctx.strokeStyle = getZoneBorderColor(varConsumption);
		ctx.stroke();
	};
	
	var drawCircle = function(ctx, varConsumptionm, varCoordinates){
		var maxRadius = 27;
		var radius = varCoordinates.height < varCoordinates.width? varCoordinates.height:varCoordinates.width;
		radius = maxRadius > radius/4? radius/4:maxRadius;
		var lineWidth = radius > 7?  radius - 7: 1; 
		ctx.beginPath();
	    ctx.arc(varCoordinates.crlX, varCoordinates.crlY, radius, 0, 2 * Math.PI, false);
	    //ctx.arc(x, y, radius, startAngle, endAngle, counterClockwise);
	    ctx.fillStyle ='rgba(255,255,255,0)'; // transparent
	    ctx.fill();
	    ctx.lineWidth = lineWidth; //20;
	    ctx.strokeStyle = getZoneConsumptionColor(varConsumptionm);
	    ctx.stroke();
	};
	
	var createTooltip = function(evt, canvas, varConsumptionData, varZoneCoordinates, tipCanvas, tipCtx){
        
		var rect = canvas.getBoundingClientRect();
		var mouseX = evt.clientX - rect.left;
		var mouseY =  evt.clientY - rect.top;
	    
		var tipCanvasLeft = evt.clientX - rect.left + canvas.offsetLeft;
		var tipCanvasTop = evt.clientY - rect.top + canvas.offsetTop;
        var tooltipText = '';
        
        angular.forEach(varZoneCoordinates, function(iVal, iIdx){
        	if(mouseX > iVal.rectX && mouseX < iVal.rectX +  iVal.width && mouseY > iVal.rectY && mouseY < iVal.rectY +  iVal.height){
        		var valConsumption = (($filter('filter')(varConsumptionData, 
    					{ locId:iVal.locId, subLocId:iVal.subLocId, 
        				  floorId:iVal.floorId, meterId:iVal.meterId}))[0]).consumption;
        		
        		tooltipText = iVal.meterId + ': ' + valConsumption + " KWh";
        	}
  
            if(tooltipText == ''){
            	tipCanvas.style.left = "-200px";
            } else {
	            tipCanvas.style.left = (tipCanvasLeft + 5) + "px"; //(evt.clientX + 05) + "px";
	            tipCanvas.style.top = (tipCanvasTop + 5) + "px"; //(evt.clientY + 10) + "px";
	            tipCtx.clearRect(0, 0, tipCanvas.width, tipCanvas.height);
	            
	            tipCtx.fillStyle = '#fff';//'#000'; //'#0099f9';
	            tipCtx.font = 'bold 11px arial'; //  'normal 12px arial';
	            tipCtx.fillText(tooltipText, 10, 15);
            }
        });
	};
	/**** END - Supporting Functions ****/

	/**** Floor wise heat map  ****/
	var drawFloorWiseHeatmap = function(selectedLocation){
		
		var canvas = document.getElementById('canvasFloorMap');
		var ctx = document.getElementById('canvasFloorMap').getContext('2d');
		
		var tipCanvas = document.getElementById('tooltipCanvas');
		var tipCtx = tipCanvas.getContext('2d');
		
		var background = new Image();
		
		var floorMapLink =  ($filter('filter')($scope.floorMapList, 
				{locId:selectedLocation[0], subLocId:selectedLocation[1], floorId:selectedLocation[2]}))[0].floorMap;
		
		console.log("floorMapLink variable= "+floorMapLink);
		// change background floor wise
		background.src = floorMapLink;

		background.onload = function(){
		    ctx.drawImage(background,0,0);   
		    //get value for energy consumption
			var floorAHUConsumptionData = $filter('filter')($scope.AHU_consumption, 
					{locId:selectedLocation[0], subLocId:selectedLocation[1], floorId:selectedLocation[2]});
			
			console.log("fllor AHU Consumption = "+floorAHUConsumptionData);
			
			// for each meter(AHU) - draw rectangle, circle on the floor map
			angular.forEach(floorAHUConsumptionData, function(iValue, iIndex){
					// take coordinates for the rect area and circle 
					// call function to draw rect and circle
					
					var coordinatesData = ($filter('filter')($scope.AHU_ZoneCoordinates, 
							{	locId:selectedLocation[0], subLocId:selectedLocation[1], 
								floorId:selectedLocation[2], meterId:iValue.meterId }))[0];
					
					drawRectangle(ctx, iValue.consumption, coordinatesData);
					///////   crlX = width/2 + rectX, crlY = height/2 + rectY
					drawCircle(ctx, iValue.consumption, coordinatesData);
			}); // END - angular.forEach
			
			canvas.addEventListener('mousemove', function(evt) {
				var floorCoordinatesData = $filter('filter')($scope.AHU_ZoneCoordinates, 
						{	locId:selectedLocation[0], subLocId:selectedLocation[1], floorId:selectedLocation[2] });
				
				createTooltip(evt, canvas, floorAHUConsumptionData, floorCoordinatesData, tipCanvas, tipCtx);
			}, false); // END - addEventListener
		}
	};
	
	/******************------$$$$$$$$$$$$$$------############------############------$$$$$$$$$$$$$$------******************/
	
	var createTooltipLastWeek = function(evt, canvas, varConsumptionData, varZoneCoordinates, tipCanvas, tipCtx){
        
		var tooltipText = '';
		var rect, mouseX, mouseY, tipCanvasLeft, tipCanvasTop;
		if(evt.currentTarget.id.toLowerCase().indexOf('canvas') >= 0){
			rect = evt.currentTarget.getBoundingClientRect();
			mouseX = evt.clientX - rect.left;
			mouseY =  evt.clientY - rect.top;
		    
//			tipCanvasLeft = evt.clientX - rect.left + evt.currentTarget.offsetLeft;
//			tipCanvasTop = evt.clientY - rect.top + evt.currentTarget.offsetTop;
			
			tipCanvasLeft = evt.clientX - 20;//53;
			tipCanvasTop = evt.clientY - 210;//215;
	//        var mouseX = parseInt(evt.clientX - canvas.offsetLeft);
	//        var mouseY = parseInt(evt.clientY - canvas.offsetTop);
	        
	        //tooltipText = varZoneCoordinates.meterId + ': ' + varConsumptionData + " KWh";
	        tooltipText = varConsumptionData[0] + ': ' + varConsumptionData[1] + " KWh";
		}
  
        	if(tooltipText == ''){
            	tipCanvas.style.left = "-200px";
            } else {
	            tipCanvas.style.left = (tipCanvasLeft + 5) + "px"; //(evt.clientX + 05) + "px";
	            tipCanvas.style.top = (tipCanvasTop + 5) + "px"; //(evt.clientY + 10) + "px";
	            tipCtx.clearRect(0, 0, tipCanvas.width, tipCanvas.height);
	            
	            tipCtx.fillStyle = '#fff';//'#000'; //'#0099f9';
	            tipCtx.font = 'bold 11px arial'; //  'normal 12px arial';
	            tipCtx.fillText(tooltipText, 10, 15);
            }
//        });
	};
	/**** heat map for last 7 days  ****/
	var drawWeeklyHeatmap = function(selectedLocation){
			
			$scope.lastWeekConsumption = heatMapService.AHU_consumption_lastWeek;
			
			$scope.AHU_List = ($filter('filter')($scope.AHU_ZoneCoordinates, 
					{	locId:selectedLocation[0], subLocId:selectedLocation[1], floorId:selectedLocation[2]	}));
			
			// Set default values
			if($scope.AhuModel_lastWeek==undefined || $scope.AhuModel_lastWeek == null || $scope.AhuModel_lastWeek == "") {
				$scope.AhuModel_lastWeek = angular.copy($scope.AHU_List[0].meterId);
			}
			
			// To add AHU dynamically
			$scope.lblAHU = new Array();
			
		    for(var i=0 ; i < $scope.AHU_List.length ; i++){
				
				$scope.lblAHU.push($scope.AHU_List[i].meterId);
				
			}
			
			var selectedLocation = selLocationService.getSelFloor();
			var floorMapLink = ($filter('filter')($scope.floorMapList, 
					{locId:selectedLocation[0], subLocId:selectedLocation[1], floorId:selectedLocation[2]}))[0].floorMap;
			
			
				var coordinatesData = ($filter('filter')($scope.AHU_ZoneCoordinates, 
						{	locId:selectedLocation[0], subLocId:selectedLocation[1], 
							floorId:selectedLocation[2], meterId:$scope.AhuModel_lastWeek 	}))[0];
				
				$scope.selectedAHUConsumptionData = ($filter('filter')($scope.lastWeekConsumption, 
						{	locId:selectedLocation[0], subLocId:selectedLocation[1], 
							floorId:selectedLocation[2], meterId:$scope.AhuModel_lastWeek 	}));
				var today = new Date();
				var dayOfWeek = today.getDay();  //Monday = 1
				dayOfWeek = dayOfWeek - 1; // Exclude today, show data starting from previous day

				// extract data from result
				// if today = 1(Monday) start with 0 th elmt in result array
				// if today = 2(Tuesday) start with 1
				// if today = 3(Wednesday) start with 2 and so on
		 
				var lastWeekConsumptionData = new Array();
				$scope.lblMap = new Array();
				var iStart = dayOfWeek >= 0 ? dayOfWeek: 6;// - 1
				var newDate = new Date(today);
				newDate.setDate(today.getDate() - 1);
				
				for(var count=0; count<7; count++){
					if($scope.selectedAHUConsumptionData[iStart]){
						$scope.lblMap.push(angular.copy($filter('date')(newDate,'MMM dd')));
						lastWeekConsumptionData.push( new Array(angular.copy($filter('date')(newDate,'MMM dd')), 
											$scope.selectedAHUConsumptionData[iStart].consumption));
						//iStart = iStart == 6 ? 0 : iStart+1;
						iStart = iStart == 0 ? 6 : iStart-1;
						newDate.setDate(newDate.getDate() - 1);
					}
				}
				
				var background = new Image();
				
				// change background floor wise
				background.src = floorMapLink;
				background.onload = function(){
					for(var i=1; i<=lastWeekConsumptionData.length; i++){
						var canvasName = "canvasLastWeekMap_" + i;
						var canvas = document.getElementById(canvasName);
						var ctx = canvas.getContext('2d');
						
						var tipCanvas = document.getElementById('tooltipLastWeekCanvas');
						var tipCtx = tipCanvas.getContext('2d');
						//context.drawImage(img,sx,sy,swidth,sheight,x,y,width,height);
						var canWidth = 250, canHeight = 150;
						
						var canStartX = 0, canStartY = 0;
						canStartX = [canWidth - (coordinatesData.width+10)] / 2 >0? [canWidth - (coordinatesData.width+10)] / 2:0;
						//canStartY = [canHeight - (coordinatesData.height+10)] / 2;
						
						var widthDiff = 250-(coordinatesData.width+10);
							var heightDiff = 150-(coordinatesData.height+10); 
							if( widthDiff > heightDiff){
								canWidth = coordinatesData.width+10 + heightDiff;
								canHeight = coordinatesData.height+10 + heightDiff;
							} else {
								canWidth = coordinatesData.width+10 + widthDiff;
								canHeight = coordinatesData.height+10 + widthDiff;
							}
						
						// clear canvas
						ctx.clearRect(0, 0, canvas.width, canvas.height);
						// draw on canvas
					    ctx.drawImage(background, coordinatesData.rectX-5, coordinatesData.rectY-5, 
					    		coordinatesData.width+10, coordinatesData.height+10, 
					    		canStartX, canStartY, canWidth, canHeight);  
					    		//0, 0, canWidth, canHeight);  
					    		//canStartX, canStartY, coordinatesData.width+10, coordinatesData.height+10);   
					    drawRectangle(ctx, lastWeekConsumptionData[i-1][1], {rectX: canStartX+5, rectY:canStartY+5, width:canWidth-10, height:canHeight-10});
						drawCircle(ctx, lastWeekConsumptionData[i-1][1], {crlX: (canWidth-10)/2 + canStartX+5 , crlY:(canHeight-10)/2 + canStartY+5, 
					    							width:coordinatesData.width , height:coordinatesData.height});
						
						canvas.addEventListener('mousemove', function(evt) {
							var varIndex = Number(evt.currentTarget.id.split('_')[1]) - 1;
							createTooltipLastWeek(evt, canvas, lastWeekConsumptionData[varIndex], coordinatesData, tipCanvas, tipCtx);
						}, false); // END - mousemove addEventListener
						
						canvas.addEventListener('mouseout', function(evt) {
							tipCanvas.style.left = "-300px";
						}, false); // END - mouseout addEventListener
						
					}
				};
//			}); // END Watch AhuModel_lastWeek
	}
	
	
	/******************------$$$$$$$$$$$$$$------############------############------$$$$$$$$$$$$$$------******************/

	/** Assumption : showing consumption(KWh) for a day before, 
	 * Range: 0 to 40 - green,  40 to 70 - yellow, 70 to 100 - Red
	 */
	var getZoneBorderColor_Hourly = function(varConsumption){
		if(varConsumption >= 0 && varConsumption <= 1){
			return '#319831'; //'rgba(0, 255, 0, 1)';
		}else if(varConsumption > 1 && varConsumption <= 2){
			return 'rgba(255, 194, 0, 1)';
		}else if(varConsumption > 2 && varConsumption <= 100){
			return 'rgba(255, 0, 0, 1)';
		}
	};
	
	/** Assumption : showing consumption(KWh) for a day before, 
	 * Range: 0 to 40 - green,  40 to 70 - yellow, 70 to 100 - Red
	 */
	var getZoneConsumptionColor_Hourly = function(varConsumption){
		if(varConsumption >= 0 && varConsumption <= 1){
			return 'rgba(20, 204, 20, 0.6)'; //'rgba(49, 150, 49, 0.5)';
		}else if(varConsumption > 1 && varConsumption <= 2){
			return 'rgba(255, 194, 0, 0.7)';
		}else if(varConsumption > 2 && varConsumption <= 100){
			return 'rgba(255, 0, 0, 0.6)';
		}
	};
	
	var drawRectangle_Hourly = function(ctx, varConsumption, varCoordinates){
		ctx.beginPath();
		ctx.rect(varCoordinates.rectX, varCoordinates.rectY, varCoordinates.width, varCoordinates.height);
		//ctx.rect(x, y, width, height);
		ctx.fillStyle = 'rgba(255,255,255,0)'; // transparent
		ctx.fill();
		ctx.lineWidth = 3;
		ctx.strokeStyle = getZoneBorderColor_Hourly(varConsumption);
		ctx.stroke();
	};
	
	var drawCircle_Hourly = function(ctx, varConsumptionm, varCoordinates){
		var maxRadius = 27;
		var radius = varCoordinates.height < varCoordinates.width? varCoordinates.height:varCoordinates.width;
		radius = maxRadius > radius/4? radius/4:maxRadius;
		var lineWidth = radius > 7?  radius - 7: 1; 
		ctx.beginPath();
	    ctx.arc(varCoordinates.crlX, varCoordinates.crlY, radius, 0, 2 * Math.PI, false);
	    //ctx.arc(x, y, radius, startAngle, endAngle, counterClockwise);
	    ctx.fillStyle ='rgba(255,255,255,0)'; // transparent
	    ctx.fill();
	    ctx.lineWidth = lineWidth; //20;
	    ctx.strokeStyle = getZoneConsumptionColor_Hourly(varConsumptionm);
	    ctx.stroke();
	};
	
	
	var createTooltipTodayHourly = function(evt, canvas, varConsumptionData, varZoneCoordinates, tipCanvas, tipCtx){
        
		var tooltipText = '';
		var rect, mouseX, mouseY, tipCanvasLeft, tipCanvasTop;
		if(evt.currentTarget.id.toLowerCase().indexOf('canvas') >= 0){
			rect = evt.currentTarget.getBoundingClientRect();
			
			tipCanvasLeft = evt.clientX - 20;//53;
			tipCanvasTop = evt.clientY - 210;//215;
	        
	        tooltipText = varConsumptionData[0] + ': ' + varConsumptionData[1] + " KWh";
		}
  
        	if(tooltipText == ''){
            	tipCanvas.style.left = "-200px";
            } else {
	            tipCanvas.style.left = (tipCanvasLeft + 5) + "px"; //(evt.clientX + 05) + "px";
	            tipCanvas.style.top = (tipCanvasTop + 5) + "px"; //(evt.clientY + 10) + "px";
	            tipCtx.clearRect(0, 0, tipCanvas.width, tipCanvas.height);
	            
	            tipCtx.fillStyle = '#fff';//'#000'; //'#0099f9';
	            tipCtx.font = 'bold 11px arial'; //  'normal 12px arial';
	            tipCtx.fillText(tooltipText, 10, 15);
            }
	};
	
	/**** heat map for Today on Hourly basis   ****/
	var drawTodayHourlyHeatmap = function(selectedLocation){

		$scope.TodayConsumption = heatMapService.AHU_consumption_today;
			
		$scope.AHU_List = ($filter('filter')($scope.AHU_ZoneCoordinates, 
				{	locId:selectedLocation[0], subLocId:selectedLocation[1], floorId:selectedLocation[2]	}));
		
		// Set default values
		if($scope.AhuModel_hourlyToday==undefined || $scope.AhuModel_hourlyToday == null || $scope.AhuModel_hourlyToday == "") {
			$scope.AhuModel_hourlyToday = angular.copy($scope.AHU_List[0].meterId);
		}
		
		// To add AHU dynamically
		$scope.lblAHU = new Array();
		
	    for(var i=0 ; i < $scope.AHU_List.length ; i++){
			
			$scope.lblAHU.push($scope.AHU_List[i].meterId);
			
		}
		
		var selectedLocation = selLocationService.getSelFloor();
		var floorMapLink = ($filter('filter')($scope.floorMapList, 
				{locId:selectedLocation[0], subLocId:selectedLocation[1], floorId:selectedLocation[2]}))[0].floorMap;
		
		var coordinatesData = ($filter('filter')($scope.AHU_ZoneCoordinates, 
				{	locId:selectedLocation[0], subLocId:selectedLocation[1], 
					floorId:selectedLocation[2], meterId:$scope.AhuModel_hourlyToday 	}))[0];
		
		$scope.selectedAHUConsumptionData = ($filter('filter')($scope.TodayConsumption, 
				{	locId:selectedLocation[0], subLocId:selectedLocation[1], 
					floorId:selectedLocation[2], meterId:$scope.AhuModel_hourlyToday 	}));

		var TodayConsumptionData = new Array();
		$scope.lblMap = new Array();
		
		// get current time
		var todayNow = new Date();
		var readingDateTime; 
		
		for(var count=0; count<$scope.selectedAHUConsumptionData.length; count++){
			readingDateTime = new Date((todayNow.getMonth()+1) + "/" + todayNow.getDate() + "/" + todayNow.getFullYear() + 
					" " + $scope.selectedAHUConsumptionData[count].time);
			if(readingDateTime < todayNow ){
				$scope.lblMap.push(angular.copy($scope.selectedAHUConsumptionData[count].time));
				TodayConsumptionData.push( new Array(angular.copy($scope.selectedAHUConsumptionData[count].time), 
									$scope.selectedAHUConsumptionData[count].consumption));
			}
		}
				
		var background = new Image();
		
		// change background floor wise
		background.src = floorMapLink;
		background.onload = function(){
			for(var i=1; i<=TodayConsumptionData.length; i++){
				var canvasName = "canvasHourlyMap_" + i;
				var canvas = document.getElementById(canvasName);
				var ctx = canvas.getContext('2d');
				
				var tipCanvas = document.getElementById('tooltipHourlyCanvas');
				var tipCtx = tipCanvas.getContext('2d');
				//context.drawImage(img,sx,sy,swidth,sheight,x,y,width,height);
				var canWidth = 250, canHeight = 150;
				
				var canStartX = 0, canStartY = 0;
				canStartX = [canWidth - (coordinatesData.width+10)] / 2 >0? [canWidth - (coordinatesData.width+10)] / 2:0;
				//canStartY = [canHeight - (coordinatesData.height+10)] / 2;
				
				var widthDiff = 250-(coordinatesData.width+10);
					var heightDiff = 150-(coordinatesData.height+10); 
					if( widthDiff > heightDiff){
						canWidth = coordinatesData.width+10 + heightDiff;
						canHeight = coordinatesData.height+10 + heightDiff;
					} else {
						canWidth = coordinatesData.width+10 + widthDiff;
						canHeight = coordinatesData.height+10 + widthDiff;
					}
				
				// clear canvas
				ctx.clearRect(0, 0, canvas.width, canvas.height);
				// draw on canvas
			    ctx.drawImage(background, coordinatesData.rectX-5, coordinatesData.rectY-5, 
			    		coordinatesData.width+10, coordinatesData.height+10, 
			    		canStartX, canStartY, canWidth, canHeight);  
			    		//0, 0, canWidth, canHeight);  
			    		//canStartX, canStartY, coordinatesData.width+10, coordinatesData.height+10);   
			    drawRectangle_Hourly(ctx, TodayConsumptionData[i-1][1], {rectX: canStartX+5, rectY:canStartY+5, width:canWidth-10, height:canHeight-10});
			    drawCircle_Hourly(ctx, TodayConsumptionData[i-1][1], {crlX: (canWidth-10)/2 + canStartX+5 , crlY:(canHeight-10)/2 + canStartY+5, 
			    							width:coordinatesData.width , height:coordinatesData.height});
				
				canvas.addEventListener('mousemove', function(evt) {
					var varIndex = Number(evt.currentTarget.id.split('_')[1]) - 1;
					createTooltipTodayHourly(evt, canvas, TodayConsumptionData[varIndex], coordinatesData, tipCanvas, tipCtx);
				}, false); // END - addEventListener
				
				canvas.addEventListener('mouseout', function(evt) {
					tipCanvas.style.left = "-300px";
				}, false); // END - mouseout addEventListener
			}
		};
//			}); // END Watch AhuModel_hourlyToday
	}
	
	
	/******************------$$$$$$$$$$$$$$------############------############------$$$$$$$$$$$$$$------******************/
	
	
	/**** Draw heatmap on canvas according to Consumption data ****/
	// get data
	$scope.floorMapList = heatMapService.floorMapList;
	$scope.AHU_consumption = heatMapService.AHU_consumption;
	$scope.AHU_ZoneCoordinates = heatMapService.AHU_ZoneCoordinates;
	
	$scope.$watch(function(){ return selLocationService.selLocation; }, function() {
		$scope.viewDataModel = 0;
		$scope.AhuModel_lastWeek = 'AHU_1';
		$scope.AhuModel_hourlyToday = 'AHU_1';
		
		var selectedLocation = selLocationService.getSelFloor();
		drawFloorWiseHeatmap(selectedLocation);
	}); // END- $watch
	
	$scope.$watch('[viewDataModel, AhuModel_lastWeek, AhuModel_hourlyToday]', function() {
		var selectedLocation = selLocationService.getSelFloor();
		if($scope.viewDataModel==0){
			drawFloorWiseHeatmap(selectedLocation);
		}else if($scope.viewDataModel==1){
			drawTodayHourlyHeatmap(selectedLocation);
		}else if($scope.viewDataModel==2){
			drawWeeklyHeatmap(selectedLocation);
		}
	});
	
})