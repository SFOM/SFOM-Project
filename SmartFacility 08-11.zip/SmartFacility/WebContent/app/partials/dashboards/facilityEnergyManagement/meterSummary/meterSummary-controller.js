
app.controller('meterSummaryCtrl', function($scope, $filter,  meterSummaryService) {

	$scope.tableDataModel = 0;
	$scope.dtFrom = new Date(); //"";  temporarily set current date
	$scope.dtTo = new Date(); //"";    temporarily set current date
	$scope.maxDate = new Date();
	$scope.dateFormat = "MM/dd/yyyy";
	
	$scope.dateOptions = {
		    formatYear: 'yy',
		    startingDay: 1,
		    showWeeks: false,
	};
	
	$scope.status = {
		    fromOpened: false,
		    toOpened: false
		  };
	
	$scope.open = function($event) {
		if($event.currentTarget.id == "btnDtFrom"){
			$scope.status.fromOpened = true;
		} else if($event.currentTarget.id == "btnDtTo"){
			$scope.status.toOpened = true;
		}
	  };
	  
	$scope.hourlyMeterReadingData = meterSummaryService.getHourlyMeterReadingData();
	
	$scope.meterForcastData = meterSummaryService.getForcastData(); 
	
	$scope.reportGridOptions = { data: 'hourlyMeterReadingData',
			 enableSorting: true,
            columnDefs: [{field:'mtrLocation', displayName:'Meter Location', headerCellClass:'ui-grid-header-cell-blue'}, //type: 'date', cellFilter: 'date:\'MMM dd, yyyy\'', width: 125 
                         {field:'mtrTitle', displayName:'Meter Title', headerCellClass:'ui-grid-header-cell-blue', 
            				enableSorting: false}, 
                         {field:'currReading', displayName:'Current Reading', headerCellClass:'ui-grid-header-cell-blue'}, 
                         {field:'hourlyUsage', displayName:'Hourly Usage', headerCellClass:'ui-grid-header-cell-blue'},
                         {field:'hourlyTarget', displayName:'Hourly Target', headerCellClass:'ui-grid-header-cell-blue', 
                    	 	resizable: true}, 
                         {field:'hourlyForcast', displayName:'Hourly Forecast', headerCellClass:'ui-grid-header-cell-blue',
                	 		enableSorting: false, resizable: true}
                         ],
                         //rowTemplate: rowtpl,
                         //enableColumnMenus: false
                        // enableHorizontalScrollbar : 0,
    };
	
	$scope.gridForcastOptions = { data: 'meterForcastData',
            columnDefs: [
                     	 {field:'mtrTitle', displayName:'Meter Title', headerCellClass:'ui-grid-header-cell-green'},	
                         {field:'dailyForcast', displayName:'Daily Forecast', headerCellClass:'ui-grid-header-cell-green'}, //type: 'date', cellFilter: 'date:\'MMM dd, yyyy\'', width: 125 
                         {field:'monthlyForcast', displayName:'Monthly Forecast', headerCellClass:'ui-grid-header-cell-green', 
            				enableSorting: false}, 
                         {field:'quarterlyForcast', displayName:'Quarterly Forecast', headerCellClass:'ui-grid-header-cell-green'}, 
                         {field:'yearlyForcast', displayName:'Yearly Forecast', headerCellClass:'ui-grid-header-cell-green'},
                        ],
                         //rowTemplate: rowtpl,
                         //enableColumnMenus: false
                         enableHorizontalScrollbar : 1, //uiGridConstants.scrollbars.NEVER,
    };
});