
app.service('meterSummaryService', function($http) {
	
	var meterReading = [
	                  {
	                      "mtrLocation": "S1 - Ground Floor", 
	                      "mtrTitle": "S1-0-m1",
	                      "currReading": 2456,
	                      "hourlyUsage": 232, 
	                      "hourlyTarget": 251,
	                      "hourlyForcast": 244
	                  },
	                  {
	                	  "mtrLocation": "S1 - Ground Floor",
	                      "mtrTitle": "S1-0-m2",
	                      "currReading": 3688,
	                      "hourlyUsage": 425, 
	                      "hourlyTarget": 547,
	                      "hourlyForcast": 600
	                  },
	                  {
	                	  "mtrLocation": "S1 - Ground Floor",
	                      "mtrTitle": "S1-0-m3",
	                      "currReading": 4254,
	                      "hourlyUsage": 788, 
	                      "hourlyTarget": 528,
	                      "hourlyForcast": 841
	                  },
	                  {
	                	  "mtrLocation": "S1 - Ground Floor",
	                      "mtrTitle": "S1-0-m5",
	                      "currReading": 4254,
	                      "hourlyUsage": 788, 
	                      "hourlyTarget": 528,
	                      "hourlyForcast": 941
	                  },
	                  {
	                	  "mtrLocation": "S1 - Ground Floor",
	                      "mtrTitle": "S1-0-m8",
	                      "currReading": 14254,
	                      "hourlyUsage": 588, 
	                      "hourlyTarget": 628,
	                      "hourlyForcast": 590
	                  },
	                  {
	                	  "mtrLocation": "S1 - Ground Floor",
	                      "mtrTitle": "S1-0-m10",
	                      "currReading": 7254,
	                      "hourlyUsage": 1020, 
	                      "hourlyTarget": 1100,
	                      "hourlyForcast": 980
	                  },
	                  {
	                	  "mtrLocation": "S1 - Ground Floor",
	                      "mtrTitle": "S1-0-m11",
	                      "currReading": 4254,
	                      "hourlyUsage": 788, 
	                      "hourlyTarget": 528,
	                      "hourlyForcast": 841
	                  },
	                  {
	                	  "mtrLocation": "S1 - Ground Floor",
	                      "mtrTitle": "S1-0-m15",
	                      "currReading": 1254,
	                      "hourlyUsage": 488, 
	                      "hourlyTarget": 528,
	                      "hourlyForcast": 441
	                  },
	                  {
	                	  "mtrLocation": "S1 - Ground Floor",
	                      "mtrTitle": "S1-0-m17",
	                      "currReading": 14254,
	                      "hourlyUsage": 388, 
	                      "hourlyTarget": 571,
	                      "hourlyForcast": 818
	                  },
	                  {
	                	  "mtrLocation": "S1 - Ground Floor",
	                      "mtrTitle": "S1-0-m18",
	                      "currReading": 41720,
	                      "hourlyUsage": 1138, 
	                      "hourlyTarget": 1286,
	                      "hourlyForcast": 1756
	                  },
	                  {
	                	  "mtrLocation": "S1 - Ground Floor",
	                      "mtrTitle": "S1-0-m22",
	                      "currReading": 4254,
	                      "hourlyUsage": 788, 
	                      "hourlyTarget": 528,
	                      "hourlyForcast": 841
	                  },
	                  {
	                	  "mtrLocation": "S1 - Ground Floor", 
	                      "mtrTitle": "S1-0-m23",
	                      "currReading": 2456,
	                      "hourlyUsage": 232, 
	                      "hourlyTarget": 376,
	                      "hourlyForcast": 344
	                  },
	                  {
	                	  "mtrLocation": "S1 - Ground Floor",
	                      "mtrTitle": "S1-0-m24",
	                      "currReading": 8254,
	                      "hourlyUsage": 1020, 
	                      "hourlyTarget": 1010,
	                      "hourlyForcast": 980
	                  },
	                  {
	                	  "mtrLocation": "S1 - Ground Floor",
	                      "mtrTitle": "S1-0-m25",
	                      "currReading": 17254,
	                      "hourlyUsage": 620, 
	                      "hourlyTarget": 915,
	                      "hourlyForcast": 1021
	                  },
	                  {
	                	  "mtrLocation": "S1 - Ground Floor",
	                      "mtrTitle": "S1-0-m28",
	                      "currReading": 81720,
	                      "hourlyUsage": 1138, 
	                      "hourlyTarget": 1286,
	                      "hourlyForcast": 1021
	                  }
	              ];
	
	this.getHourlyMeterReadingData = function() {
		return meterReading;
	};
	
	var meterForcastData = [
		                  {
		                      "mtrLocation": "S1 - Ground Floor", 
		                      "mtrTitle": "S1-0-m1",
		                      "dailyForcast": 456,
		                      "monthlyForcast": 13680, 
		                      "quarterlyForcast": 41040,
		                      "yearlyForcast": 164160
		                  },
		                  {
		                	  "mtrLocation": "S1 - Ground Floor", 
		                      "mtrTitle": "S1-0-m2",
		                      "dailyForcast": 1688,
		                      "monthlyForcast": 23884, 
		                      "quarterlyForcast": 81742,
		                      "yearlyForcast": 425912
		                  },
		                  {
		                	  "mtrLocation": "S1 - Ground Floor",
		                      "mtrTitle": "S1-0-m4",
		                      "dailyForcast": 615,
		                      "monthlyForcast": 35087, 
		                      "quarterlyForcast": 92534,
		                      "yearlyForcast": 486862
		                  },
		                  {
		                	  "mtrLocation": "S1 - Ground Floor",
		                      "mtrTitle": "S1-0-m5",
		                      "dailyForcast": 856,
		                      "monthlyForcast": 3752, 
		                      "quarterlyForcast": 71243,
		                      "yearlyForcast": 525513
		                  },
		                  {
		                	  "mtrLocation": "S1 - Ground Floor",
		                      "mtrTitle": "S1-0-m9",
		                      "dailyForcast": 1688,
		                      "monthlyForcast": 23884, 
		                      "quarterlyForcast": 81742,
		                      "yearlyForcast": 425912
		                  },
		                  {
		                	  "mtrLocation": "S1 - Ground Floor",
		                      "mtrTitle": "S1-0-m10",
		                      "dailyForcast": 456,
		                      "monthlyForcast": 13680, 
		                      "quarterlyForcast": 41040,
		                      "yearlyForcast": 164160
		                  },
		                  {
		                	  "mtrLocation": "S1 - Ground Floor",
		                      "mtrTitle": "S1-0-m11",
		                      "dailyForcast": 1256,
		                      "monthlyForcast": 53682, 
		                      "quarterlyForcast": 301740,
		                      "yearlyForcast": 416168
		                  },
		                  {
		                	  "mtrLocation": "S1 - Ground Floor",
		                      "mtrTitle": "S1-0-m12",
		                      "dailyForcast": 461,
		                      "monthlyForcast": 13697, 
		                      "quarterlyForcast": 71549,
		                      "yearlyForcast": 264067
		                  },
		                  {
		                	  "mtrLocation": "S1 - Ground Floor",
		                      "mtrTitle": "S1-0-m13",
		                      "dailyForcast": 276,
		                      "monthlyForcast": 10617, 
		                      "quarterlyForcast": 21748,
		                      "yearlyForcast": 144961
		                  },
		                  {
		                	  "mtrLocation": "S1 - Ground Floor",
		                      "mtrTitle": "S1-0-m14",
		                      "dailyForcast": 456,
		                      "monthlyForcast": 13680, 
		                      "quarterlyForcast": 41040,
		                      "yearlyForcast": 164160
		                  },
		                  {
		                	  "mtrLocation": "S1 - Ground Floor",
		                      "mtrTitle": "S1-0-m18",
		                      "dailyForcast": 1688,
		                      "monthlyForcast": 23884, 
		                      "quarterlyForcast": 81742,
		                      "yearlyForcast": 425912
		                  },
		                  {
		                	  "mtrLocation": "S1 - Ground Floor", 
		                      "mtrTitle": "S1-0-m21",
		                      "dailyForcast": 815,
		                      "monthlyForcast": 3452, 
		                      "quarterlyForcast": 81141,
		                      "yearlyForcast": 519573
		                  },
		                  {
		                	  "mtrLocation": "S1 - Ground Floor",
		                      "mtrTitle": "S1-0-m22",
		                      "dailyForcast": 914,
		                      "monthlyForcast": 3958, 
		                      "quarterlyForcast": 74355,
		                      "yearlyForcast": 625619
		                  },
		                  {
		                	  "mtrLocation": "S1 - Ground Floor",
		                      "mtrTitle": "S1-0-m26",
		                      "dailyForcast": 856,
		                      "monthlyForcast": 3752, 
		                      "quarterlyForcast": 71243,
		                      "yearlyForcast": 525513
		                  },
		                  {
		                	  "mtrLocation": "S1 - Ground Floor",
		                      "mtrTitle": "S1-0-m27",
		                      "dailyForcast": 1688,
		                      "monthlyForcast": 23884, 
		                      "quarterlyForcast": 81742,
		                      "yearlyForcast": 425912
		                  }
		              ];
		
		this.getForcastData = function() {
			return meterForcastData;
		};
});
