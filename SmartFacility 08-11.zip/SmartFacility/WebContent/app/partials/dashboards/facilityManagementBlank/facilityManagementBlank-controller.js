app.controller('facilityManagementBlankCtrl', function($scope) {

	

});

