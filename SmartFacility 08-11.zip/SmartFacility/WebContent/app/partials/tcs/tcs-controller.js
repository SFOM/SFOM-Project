/** Created by Vishwajeet  **/

app.controller('tcsCtrl', function ($scope,$location) { // HvacService
	
	$scope.location = $location;
	
	$(document).ready(function() {
		$( "body" ).removeClass("loginBody2");
		
	});
			
	
/*	$scope.radioModel = 'todayho';
	$scope.consumptionObj = new Array();
	var chartSource = new Array();
	
	$scope.clickButton = function( varSelectedValue ){
		if(varSelectedValue.toLowerCase() === 'todayho' ) {
			$scope.consumptionObj = [500,19];
		}else if(varSelectedValue.toLowerCase() === 'weekho' ) {
			$scope.consumptionObj = [480,108];
		}else if(varSelectedValue.toLowerCase() === 'monthho' ) {
			$scope.consumptionObj = [490,438];
		}
	};
	
	// call function once by default to load data on load
	$scope.clickButton($scope.radioModel);*/
	
	
});



/** HVAC Gauge Chart controller   **/

/*app.controller('GaugeHoCtrl', function ($scope) {
	$scope.$watch('$parent.consumptionObj', function() {
		
		
	var chartSource = new Array( ['Label', 'Value'], ['KWH', $scope.$parent.consumptionObj[1]],['Occupants', $scope.$parent.consumptionObj[0]]);
	var data = new google.visualization.arrayToDataTable(chartSource);
	var options = {
			  label: { position: 'bottom'},
                            greenFrom: 0, greenTo: 200,
			  redFrom: 400, redTo: 600,
			  yellowFrom:200, yellowTo: 400,
			  minorTicks: 30,
			  max : 600, min:0, 
			  chartArea: { left : 0, top:50, width: '60%', height: '60%'},
		};
	
		  var chart = {};
		  
		  chart.data = data;
		  chart.options = options;
		  $scope.chart = chart;
	
	})
		   
});*/





// Carousel Controllers

/*app.controller('CarouselCtrl', function ($scope) {	
	
  $scope.myInterval = 3000;
  $scope.slides = [
    {
      image: 'app/assets/images/11.jpg'
    },
    {
      image: 'app/assets/images/12.jpg'
    },
    {
      image: 'app/assets/images/13.jpg'
    }

];
});


angular.module('plunker', ['ui.bootstrap']).controller('Ctrl',['$scope', function($scope){
	
app.controller('Ctrl1',['$scope', function($scope){
	  
	  $scope.slides = [];
	  $scope.slides.push({text: 'cats!', image: 'app/assets/images/11.jpg'});
	  $scope.slides.push({text: 'cats!', image: 'app/assets/images/12.jpg'});
	  $scope.slides.push({text: 'cats!', image: 'app/assets/images/13.jpg'});
	  
	  $scope.setActive = function(idx) {
	    $scope.slides[idx].active=true;
	  }
	  
	}]);



app.controller("MainController", function($scope) {

  $scope.myInterval = 5000;
  var slides = $scope.slides = [];
  $scope.addSlide = function() {
    var newWidth = 600 + slides.length;
    slides.push({
      image: 'http://placekitten.com/' + newWidth + '/300',
      text: ['More','Extra','Lots of','Surplus'][slides.length % 4] + ' ' +
        ['Cats', 'Kittys', 'Felines', 'Cutes'][slides.length % 4]
    });
  };
  for (var i=0; i<4; i++) {
    $scope.addSlide();
  }


});*/


