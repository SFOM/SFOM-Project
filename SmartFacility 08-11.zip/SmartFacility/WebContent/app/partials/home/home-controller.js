/** Created by Vishwajeet * */

app.controller('HomeCtrl', function($scope, $location) { // HvacService

	$scope.location = $location;

	$(document).ready(function() {
		$("body").removeClass("loginBody2");

	});
});

app.controller('googleMapCtrl', function($scope) { // uiGmapGoogleMapApi
                   
	
                    // The below code is 	
	                /*var img2 = '<a href="#tcs"><img style="width:200px; height: 150px; display-inline;" src="app/assets/images/TCS_Com.jpg"></a> <i class="fa fa-smile-o fa-3x" style="color:green; display-inline;" aria-hidden="true"></i>  <p style=" margin-top:5px; color:#000;">TCS - Hinjewadi, Pune, India<br> <div style="display-inline; color:#000;"><a href="#energyManagement">Eco-Sustainability Indicator</a> &nbsp; <i class="fa fa-check-circle fa-lg" style="color:green; display:inline; margin-left: 52px;"aria-hidden="true"></div></i> <div style="display-inline; color:#000;"><a href="#equipmentAnalysis">Assets Health Prediction</a> &nbsp; <i class="fa fa-check-circle fa-lg" style="color:green; display:inline; margin-left:65px;"aria-hidden="true"></div></i></p>';*/
					var imgArray = new Array();
					/*var img1 = '<a ><img style="width:200px; height: 150px; display-inline;" src="app/assets/images/tcs_tokyo.jpg"></a> <i class="fa fa-frown-o fa-3x" style="color:red; display-inline;" aria-hidden="true"></i>  <p style=" margin-top:5px; color:#000;">TCS -Tokyo, Japan<br> <div style="display-inline; color:#000;">Eco-Sustainability Indicator &nbsp; <i class="fa fa-check-circle fa-lg" style="color:red; display:inline; margin-left: 52px;"aria-hidden="true"></div></i> <div style="display-inline; color:#000;">Assets Health Prediction &nbsp; <i class="fa fa-check-circle fa-lg" style="color:green; display:inline; margin-left:65px;"aria-hidden="true"></div></i></p>';*/
					var img1 = '<a ><img style="width:200px; height: 130px; border-radius:10px;" src="app/assets/images/tcs_tokyo.jpg"></a>   <div style="display-inline color:#000;"><a >TCS - Tokyo, Japan </a>&nbsp;<i class="fa fa-frown-o fa-2x" style="color:red; display-inline; margin-left:60px;" aria-hidden="true"></div></i> <div style="display-inline; color:#000;"><a >Eco-Sustainability Indicator</a> &nbsp; <i class="fa fa-check-circle fa-lg" style="color:red; display:inline; margin-left:15px;"aria-hidden="true"></div></i> <div style="display-inline; color:#000;"><a >Assets Health Prediction</a> &nbsp; <i class="fa fa-check-circle fa-lg" style="color:green; display:inline; margin-left:29px; "aria-hidden="true"></div></i>';
					var img2 = '<a href="#tcs"><img style="width:200px; height: 130px; border-radius:10px;" src="app/assets/images/TCS_Com3.jpg"></a>   <div style="display-inline color:#000;"><a href="#tcs">TCS - Hinjewadi, Pune, India </a>&nbsp;<i class="fa fa-smile-o fa-2x" style="color:green; display-inline; margin-left:10px;" aria-hidden="true"></div></i> <div style="display-inline; color:#000;"><a href="#sustainabilityPune">Eco-Sustainability Indicator</a> &nbsp; <i class="fa fa-check-circle fa-lg" style="color:green; display:inline; margin-left:15px;"aria-hidden="true"></div></i> <div style="display-inline; color:#000;"><a href="#equipmentAnalysis">Assets Health Prediction</a> &nbsp; <i class="fa fa-check-circle fa-lg" style="color:green; display:inline; margin-left:29px; "aria-hidden="true"></div></i>';

					var img3 = '<a ><img style="width:200px; height: 130px; border-radius:10px;" src="app/assets/images/tcs_kolkata3.jpg"></a>   <div style="display-inline color:#000;"><a >TCS - Kolkata, India </a>&nbsp;<i class="fa fa-smile-o fa-2x" style="color:green; display-inline; margin-left:60px;" aria-hidden="true"></div></i> <div style="display-inline; color:#000;"><a href="#sustainabilityKolkata">Eco-Sustainability Indicator</a> &nbsp; <i class="fa fa-check-circle fa-lg" style="color:green; display:inline; margin-left:15px;"aria-hidden="true"></div></i> <div style="display-inline; color:#000;"><a >Assets Health Prediction</a> &nbsp; <i class="fa fa-check-circle fa-lg" style="color:green; display:inline; margin-left:29px; "aria-hidden="true"></div></i>';
					
					var img4 = '<a ><img style="width:200px; height: 130px; border-radius:10px;" src="app/assets/images/tcs_santa_clara.jpg"></a>   <div style="display-inline color:#000;"><a >TCS - London, UK </a>&nbsp;<i class="fa fa-meh-o fa-2x" style="color:#999900; display-inline; margin-left:69px;" aria-hidden="true"></div></i> <div style="display-inline; color:#000;"><a >Eco-Sustainability Indicator</a> &nbsp; <i class="fa fa-check-circle fa-lg" style="color:yellow; display:inline; margin-left:15px;"aria-hidden="true"></div></i> <div style="display-inline; color:#000;"><a >Assets Health Prediction</a> &nbsp; <i class="fa fa-check-circle fa-lg" style="color:green; display:inline; margin-left:29px; "aria-hidden="true"></div></i>';
					imgArray = [ img1, img2, img3, img4 ];

					var mapCanvas = document.getElementById('googleMap');
					var mapOptions = {
						center : new google.maps.LatLng(18.719, 37.87),
						 center : new google.maps.LatLng(18.5204,73.8567), 
						zoom : 3,
						mapTypeId : google.maps.MapTypeId.ROADMAP
					}
					var map = new google.maps.Map(mapCanvas, mapOptions);

					// variable to hold current active InfoWindow
					var activeInfoWindow;
					
					
					var markerss=new Array();
					
					
					
					var marker1 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(35.6895,
										139.6917),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Tokyo, Japan",
								icon : 'http://maps.google.com/mapfiles/ms/icons/green-dot.png'

							});

					var marker2 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(18.5204,
										73.8567),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Hinjewadi, Pune, India",
								icon : 'http://maps.google.com/mapfiles/ms/icons/green-dot.png'

							});	
					
					var marker3 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(22.5726,
										88.3639),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Kolkata, India",
								icon : 'http://maps.google.com/mapfiles/ms/icons/green-dot.png'

							});

					
					var marker33 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(37.354107,
										-121.955238),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Santa Clara, CA, USA",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});
					
					var marker4 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(51.5074,
										0.1278),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- London, UK",
								icon : 'http://maps.google.com/mapfiles/ms/icons/green-dot.png'

							});
					
					
					
					var marker5 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(34.0522,
										-118.243683),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Los Angeles, USA",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});

					
					var marker6 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(-37.8132,
										144.9631),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Melbourne, Australia",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});
					var marker7 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(-33.8688,
										151.2093),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Sydney, Australia",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});
					var marker8 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(-36.848461,
										174.7633),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Auckland, New Zealand",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});
					var marker9 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(12.9716,
										77.5946),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Bangalore, India",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});
					var marker10 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(13.0827,
										80.2707),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- TCS- Chennai, India",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});
					var marker11 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(19.0760,
										72.8777),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- TCS- Mumbai, India",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});
					var marker12 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(17.3850,
										78.4867),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Hyderabad, India",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});
					var marker13 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(28.5355,
										77.3910),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Noida, India",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});
					
					var marker14 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(53.5511,
										9.9937),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Hamburg, Germany",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});
					
					var marker15 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(40.7128,
										-73.935242),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- New York, USA",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});
					var marker16 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(48.8566,
										2.3522),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Paris, France",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});
					var marker17 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(52.4227,
										10.7865),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Wolfsburg, Germany",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});
					var marker18 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(19.2465,
										-99.133209),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Mexico city, Mexico",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});
					var marker19 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(47.3769,
										8.5417),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Zurich, Switzerland",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});
					var marker20 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(49.246292,
										-123.116226),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- British Columbia, Canada",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});

					var marker21 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(25.2048,
										55.2708),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Dubai, UAE",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});
					var marker22 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(39.9042,
										116.4074),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Beijing, China",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});
					var marker23 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(13.7563,
										100.5018),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Bangkok,Thailand",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
							// draggable: true,
							// animation: google.maps.Animation.DROP,

							});
					var marker24 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(-23.533773,
										-46.625290),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Sao Paulo, Brazil",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
							// draggable: true,
							// animation: google.maps.Animation.DROP,

							});
					var marker25 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(-34.603722,
										-58.381592),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Buenos Aires, Argentina",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
							// draggable: true,
							// animation: google.maps.Animation.DROP,

							});
					var marker26 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(-26.195246,
										28.034088),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Johannesburg, South Africa",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
							// draggable: true,
							// animation: google.maps.Animation.DROP,

							});
					var marker27 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(-33.918861,
										18.423300),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Cape Town, South Africa",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
							// draggable: true,
							// animation: google.maps.Animation.DROP,

							});
					var marker28 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(29.3823,
										47.9886),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Ash Sharq, Kuwait",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
							// draggable: true,
							// animation: google.maps.Animation.DROP,

							});
					var marker29 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(25.3, 51.6),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Doha, Qatar",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
							// draggable: true,
							// animation: google.maps.Animation.DROP,

							});
					var marker30 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(22.282721,
										114.212303),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Quarry Bay, Hong Kong",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
							// draggable: true,
							// animation: google.maps.Animation.DROP,

							});
					var marker31 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(41.881832,
										-87.623177),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Chicago, IL, USA",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
							// draggable: true,
							// animation: google.maps.Animation.DROP,

							});
					var marker32 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(53.350140,
										-6.266155),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- Dublin, Ireland",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
							// draggable: true,
							// animation: google.maps.Animation.DROP,

							});
					
					/*var marker33 = new google.maps.Marker(
							{
								position : new google.maps.LatLng(51.5074,
										0.1278),
								// animation : google.maps.Animation.BOUNCE,
								title : "TCS- London, UK",
								icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'

							});*/

					// To add the marker to the map, call setMap();

					marker2.setMap(map);
					marker1.setMap(map);
					marker3.setMap(map);
					marker4.setMap(map);
					marker5.setMap(map);
					marker6.setMap(map);
					marker7.setMap(map);
					marker8.setMap(map);
					marker9.setMap(map);
					marker10.setMap(map);
					marker11.setMap(map);
					marker12.setMap(map);
					marker13.setMap(map);
					marker14.setMap(map);
					marker15.setMap(map);
					marker16.setMap(map);
					marker17.setMap(map);
					marker18.setMap(map);
					marker19.setMap(map);
					marker20.setMap(map);
					marker21.setMap(map);
					marker22.setMap(map);
					marker23.setMap(map);
					marker24.setMap(map);
					marker25.setMap(map);
					marker26.setMap(map);
					marker27.setMap(map);
					marker28.setMap(map);
					marker29.setMap(map);
					marker30.setMap(map);
					marker31.setMap(map);
					marker32.setMap(map);
					marker33.setMap(map);

					var markerArray= new Array();
					markerArray=[marker1,marker2,marker3,marker4,marker5,marker6];

					// create InfoWindow - on mouseclick
					var infowindowClick = new google.maps.InfoWindow({
						content : imgArray[1]

					});
					
					var infowindowClick2 = new google.maps.InfoWindow({
						content : imgArray[0],
					   // maxWidth: 150

					});
					
					var infowindowClick3 = new google.maps.InfoWindow({
						content : imgArray[2]

					});
					
					var infowindowClick4 = new google.maps.InfoWindow({
						content : imgArray[3]

					});

					// create an InfoWindow - for mouseover
					var infoWndMouse = new google.maps.InfoWindow({
						content : imgArray[1]
						});

					google.maps.event.addListener(marker2, 'click', function() {

						//Close active window if exists - [one might expect this to be default behaviour no?]				
						if (activeInfoWindow != null)
							activeInfoWindow.close();

						// Open InfoWindow - on click 
						infowindowClick.open(map, marker2);

						// Close "mouseover" infoWindow
						infoWndMouse.close();

					});
					
					
					google.maps.event.addListener(marker1, 'click', function() {

						//Close active window if exists - [one might expect this to be default behaviour no?]				
						if (activeInfoWindow != null)
							activeInfoWindow.close();

						// Open InfoWindow - on click 
						infowindowClick2.open(map, marker1);

						// Close "mouseover" infoWindow
						infoWndMouse.close();

					});
					
					
					google.maps.event.addListener(marker3, 'click', function() {

						//Close active window if exists - [one might expect this to be default behaviour no?]				
						if (activeInfoWindow != null)
							activeInfoWindow.close();

						// Open InfoWindow - on click 
						infowindowClick3.open(map, marker3);

						// Close "mouseover" infoWindow
						infoWndMouse.close();

					});
					
					
					google.maps.event.addListener(marker4, 'click', function() {

						//Close active window if exists - [one might expect this to be default behaviour no?]				
						if (activeInfoWindow != null)
							activeInfoWindow.close();

						// Open InfoWindow - on click 
						infowindowClick4.open(map, marker4);

						// Close "mouseover" infoWindow
						infoWndMouse.close();

					});

	
	

	
	
				});
