/** Created by Vishwajeet  **/

app.controller('loginPageCtrl', function($scope, $state) {
	
	$(document).ready(function() {
		$( "body" ).addClass("loginBody2");
       // $(".navbar-fixed-top").removeClass("top-nav-collapse");
	});
	
	$scope.validateForm = function () {
        var un = document.getElementById('userid').value;
        var pw = document.getElementById('passwordinput').value;
        /*var username = "tcsuser"; 
        var password = "testbed123";*/
        var username = "admin"; 
        var password = "admin";
        if ((un != "") && (pw != "")) {    
        	if ((un == username) && (pw == password)) {
	        	//window.open('pages/dashboard.html');
        		$state.go('home');
	        }
        	
        	/*if (((un == "mangesh") && (pw == "p@ssword")) ||((un == "manish") && (pw == "p@ssword")) || 
        			((un == "sachin") && (pw == "p@ssword"))) {
	        	//window.open('pages/dashboard.html');
        		$state.go('home');
	        }*/
	        else {
	        	alert("Login was unsuccessful, please check your username and password.");
//	            $("#login-alert").text("Login was unsuccessful, please check your username and password.");
//	            $('#login-alert').css('display','inline-block');
	            //return false;
	        }
	  	} else {
	  		alert("Please fill login details.");
	  	}
	}
});



app.controller('TabsCtrl', function ($scope) {
    $scope.myLoginTab = [{
            title: 'Log In',
            url: 'one.tpl.html'
        }, {
            title: 'Sign Up',
            url: 'two.tpl.html'
        }];

    $scope.currentTab = 'one.tpl.html';

    $scope.onClickTab = function (tab) {
        $scope.currentTab = tab.url;
    }
    
    $scope.isActiveTab = function(tabUrl) {
        return tabUrl == $scope.currentTab;
    }
});