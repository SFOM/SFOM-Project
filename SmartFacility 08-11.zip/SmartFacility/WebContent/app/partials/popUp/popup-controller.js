/*app.controller('modelActualExpectedChartCtrls', function ($scope, $uibModalInstance, data, options) {*/
app.controller('popUpCtrls', function ($scope, $uibModalInstance) {


	//var data=[['number','number'],[19, 5623],[18, 4879],[17, 2451],[16, 3478],[15, 5876],[14, 4785], [13, 4528]];
	/*var chartData = new google.visualization.arrayToDataTable(data);*/
	
	var chartData = new google.visualization.DataTable();
	
	chartData.addColumn('number', 'Days of week');
	chartData.addColumn('number', 'Cost');

	
	chartData.addRows([ [19, 5623],[18, 4879],[17, 2451],[16, 3478],[15, 5876],[14, 4785], [13, 4528] ]);

	var chartOptions = {
  
    		backgroundColor: '#a1a1a1',
    		color: '#46607A', 
    	
    		
    		vAxis:
    			{
    			title : 'Cost in Rupees',
				textStyle : {
					color : '#fff'
				},
				titleTextStyle : {
					color : '#fff'
				},
    				},
    		hAxis:
    			{
    			title : 'Days of Week',
				textStyle : {
					color : '#fff'
				},
				titleTextStyle : {
					color : '#fff'
				},
    				},
    	
    		seriesType: 'bars',
    		isStacked: false,
    		
    		chartArea: {
    			
    				top: 15,left:50,
		        	width:'95%',height:'75%'
    				}
    };

    var chart = {};
    chart.data = chartData;
    chart.options = chartOptions;
    $scope.chart = chart;

    $scope.title= 'Total Cost of Last 7 Days',


	$scope.close = function () {
		$uibModalInstance.dismiss('close');
	};

}) 