app.controller('adminHomeCtrl', function($scope, $state, $filter, $uibModal, adminHomeService) { //$modal

	$scope.selectedNodeData = { selLevelInTree:0, locIndex:-1 , subLocIndex:-1, floorIndex:-1};
	$scope.isFloorSelected = false;
	$scope.lblSelectedTreeNode = "Select a floor";
	//$scope.selLevelInTree = 0;

	// Load data
	$scope.roleList = adminHomeService.locationList;
	$scope.equipmentList = adminHomeService.equipmentList;
	$scope.floorEquipList = adminHomeService.floorEquipList;
	$scope.selectedFloorEquipList = null;
	
	//temporary node
	$scope.temporaryNode = {
			children: []
	};

  	//Default values
	$scope.selectedFloorEquipList = $filter('filter')($scope.floorEquipList, 
			{	locId:$scope.roleList[0].id, 
				subLocId:$scope.roleList[0].children[0].id, 
				floorNo:$scope.roleList[0].children[0].children[0].floorNo
			});
	
  	/*** Click on tree node - identify location, floor selected  **/
  	$scope.nodeClicked = function ($event, varNode) {
  		$scope.lblSelectedTreeNode = "Select a floor";
  		$scope.isFloorSelected = false;
  		$scope.selectedNodeData.selLevelInTree = 0;
  		
  		var indices = getRefNodeIDs(varNode);
  		// location check
  		if(indices[0] != null || indices[0] !=undefined ){
  			$scope.lblSelectedTreeNode = "TCS >> " + $scope.roleList[indices[0]].label;
  			$scope.selectedNodeData = { selLevelInTree:1, locIndex:indices[0] , subLocIndex:-1, floorIndex:-1};
  			
  			// sub-location check
	  		if(indices[1] != null || indices[1] !=undefined){
	  			$scope.lblSelectedTreeNode = $scope.lblSelectedTreeNode + " >> " + 
	  				$scope.roleList[indices[0]].children[indices[1]].label;
	  			$scope.selectedNodeData = { selLevelInTree:2, locIndex:indices[0] , subLocIndex:indices[1], floorIndex:-1};
	  			
	  			// Floor check
		  		if(indices[2] != null || indices[2] !=undefined){
		  			$scope.lblSelectedTreeNode = $scope.lblSelectedTreeNode + " >> " + 
		  				$scope.roleList[indices[0]].children[indices[1]].children[indices[2]].label;
		  			$scope.selectedNodeData = { selLevelInTree:3, locIndex:indices[0] , subLocIndex:indices[1], 
		  					floorIndex:indices[2]};
		  			
		  			$scope.isFloorSelected = true;
		  			// after selecting a floor -- filter floorEquipList to identify configured equipts
		  			var varFloorNo = $scope.roleList[indices[0]].children[indices[1]].children[indices[2]].floorNo;
		  			var equipForFloor;
		  			if(varFloorNo != null && varFloorNo != undefined && varFloorNo != ""){
		  				equipForFloor = $filter('filter')($scope.floorEquipList, 
							{	locId:$scope.roleList[indices[0]].id, 
  								subLocId:$scope.roleList[indices[0]].children[indices[1]].id, 
  								floorNo:$scope.roleList[indices[0]].children[indices[1]].children[indices[2]].floorNo
							});
		  			}
		  			else {
		  				equipForFloor ="";
		  			}
		  			if(equipForFloor.length > 0) $scope.selectedFloorEquipList = equipForFloor;
		  			//console.log($scope.selectedFloorEquipList);
		  		}
	  		}
  		}
  	}
  	
  	/*** Reset after add, edit, delete **/
    $scope.done = function () {
        /* reset */
        $scope.mytree.currentNode.selected = undefined;
        $scope.mytree.currentNode = undefined;
        $scope.mode = undefined;
        //$scope.selectedTreeNode = $scope.mytree.currentNode;
        $scope.lblSelectedTreeNode = "Select a floor";
        $scope.isFloorSelected = false;
        $scope.selectedNodeData = { selLevelInTree:0, locIndex:-1 , subLocIndex:-1, floorIndex:-1};
    };
    
    /*** Add sub-location, Floor  **/
    $scope.addChildDone = function () {
        /* add child */
        if( $scope.temporaryNode.id && $scope.temporaryNode.label ) {
        	
        	var newFloorNo = -1;
        	if($scope.selectedNodeData.selLevelInTree == 1) {
        		$scope.roleList[$scope.selectedNodeData.locIndex].children.push(
        				{	label : angular.copy($scope.temporaryNode.label), 
        					id : angular.copy($scope.temporaryNode.id), 
        					children : [] 
        				});
        	} else if($scope.selectedNodeData.selLevelInTree == 2) {
        		// temp logic to generate floorNo, it should actually come from database
        		for(var i = 0; i < $scope.mytree.currentNode.children.length; i++){
        			var tempFlrNo = $scope.roleList[$scope.selectedNodeData.locIndex].children[$scope.selectedNodeData.subLocIndex].children[i].floorNo;
        			if(Number(tempFlrNo) > newFloorNo) {
        				newFloorNo = Number(tempFlrNo);
        			}
        		}
        		$scope.temporaryNode.floorNo = newFloorNo + 1; 
        		$scope.selectedNodeData.floorIndex = $scope.mytree.currentNode.children.length;
        		$scope.roleList[$scope.selectedNodeData.locIndex].children[$scope.selectedNodeData.subLocIndex].children.push(
        				{	label : angular.copy($scope.temporaryNode.label), 
        					id : angular.copy($scope.temporaryNode.id), 
        					floorNo: angular.copy($scope.temporaryNode.floorNo), 
        					children : []	
        				});
        		addEqptsForNewFloor($scope.selectedNodeData); // add new eqpts to $scope.floorEquipList
        	} 
        	
        	//$scope.mytree.currentNode.children.push( angular.copy($scope.temporaryNode) );
        }
        
        /* reset */
        $scope.temporaryNode.id = "";
        $scope.temporaryNode.label = "";
        
        $scope.done();
    };
	
    /*** Delete floor from tree
     * Find exact element in tree
     **/
    $scope.deleteChild = function() {
    	//console.log ($scope.mytree.currentNode.children.length);
    	if($scope.mytree.currentNode.children.length == 0){
	    	if( $scope.mytree.currentNode.label ) {
	    		// level 1
	    		angular.forEach($scope.roleList, function(val, idx) {
	    			if(val.children.length > 0){
	    				// level 2
	    				angular.forEach(val.children, function(val1, idx1) {
	    					if(val1.children.length > 0){
	    						// level 3
	    	    				angular.forEach(val1.children, function(val2, idx2) {
	    	    					if(val2['id'] == $scope.mytree.currentNode.id){
	    	    						$scope.roleList[idx].children[idx1].children.splice(idx2, 1);
	    	    					}
	    	    				});
	    	    			}else{
	    	    				if(val1['id'] == $scope.mytree.currentNode.id){
    	    						$scope.roleList[idx].children.splice(idx1, 1);
    	    					}
	    	    			}
	    				});
	    			} else{
	    				// do nothing, can not remove main location
	    			}
				});
	        }
    	}
        
        /* reset */
        $scope.temporaryNode.id = "";
        $scope.temporaryNode.label = "";
        
        $scope.done();
    }
    
    /*** On Cancel click - Hide Add, Edit, Delete Window  **/
    $scope.cancelHideWindow  = function() {
    	/* reset */
        $scope.temporaryNode.id = "";
        $scope.temporaryNode.label = "";
        
    	$scope.done();
    }
    
    // function to get indices of current node in roleList
    var getRefNodeIDs = function(varCurrentNode) {
    	var indxLevel_1, indxLevel_2, indxLevel_3;
    	var isFound = false;
    	
    	angular.forEach($scope.roleList, function(val, idx) {
    		if(val['id'] == varCurrentNode.id){
				indxLevel_1 = idx;
				indxLevel_2 = undefined;
				indxLevel_3 = undefined;
			} else if(val.children.length > 0){
					// level 2
					angular.forEach(val.children, function(val1, idx1) {
						if(val1['id'] == varCurrentNode.id){
							indxLevel_1 = idx;
							indxLevel_2 = idx1;
							indxLevel_3 = undefined;
						} else if(val1.children.length > 0){
							// level 3
		    				angular.forEach(val1.children, function(val2, idx2) {
		    					if(val2['id'] == varCurrentNode.id){
		    						indxLevel_1 = idx;
		    						indxLevel_2 = idx1;
		    						indxLevel_3 = idx2;
		    					}
		    				});
		    			}
					});
				}
		});
    	return [indxLevel_1, indxLevel_2, indxLevel_3]
    }
    
    //addEqptsForNewFloor($scope.selectedNodeData); // add new eqpts to $scope.floorEquipList
    var addEqptsForNewFloor = function (varfloorData) {
    	angular.forEach($scope.equipmentList, function(value, index) {
    		var floorEqpt = {	
					locId: angular.copy($scope.roleList[varfloorData.locIndex].id),
					subLocId: angular.copy($scope.roleList[varfloorData.locIndex].children[varfloorData.subLocIndex].id),
					flrId: angular.copy($scope.floorEquipList.length) + 1, // temp data
					eqptId: value.eqptId,
					floorNo: $scope.roleList[varfloorData.locIndex].children[varfloorData.subLocIndex].children[varfloorData.floorIndex].floorNo,
					floorDesc: "Floor-" + $scope.roleList[varfloorData.locIndex].children[varfloorData.subLocIndex].children[varfloorData.floorIndex].floorNo,
					isConfigured: false,
					sensorId:''
				};
    		$scope.floorEquipList.push(floorEqpt);
    	})
    }
    
    /*** TRee End***/
    
/**** Widget section ***********/
    
//    $scope.numOfMaps = [ 
//	                    {count: 1, text: "Text 1", header: "HVAC", isConfigured:true},
//	                    {count: 2, text: "Text 2", header: "Light", isConfigured:true},
//	                    {count: 3, text: "Text 3", header: "UPS", isConfigured:false},
//	                    {count: 4, text: "Text 4", header: "DG", isConfigured:false},
//	                    {count: 4, text: "Text 4", header: "LIFT", isConfigured:false}
//	                  ];
    
    $scope.getEqptName = function (varEqptId) {
    	var arrSelEqpt = $filter('filter')($scope.equipmentList, {eqptId: varEqptId });
    	var eqptName = ""; 
    	if(arrSelEqpt.length > 0) {
    		eqptName =  arrSelEqpt[0].eqptName;
    	}
    	return eqptName;
    }
    
    $scope.getEqptIcon = function (varEqptId) {
    	var eqptIcon = "";
    	if(varEqptId != null && varEqptId != undefined && varEqptId != ""){
	    	if(varEqptId == '1') {
	    		eqptIcon = "app/assets/images/admin/HVAC.png";
	    	} else if(varEqptId == '2') {
	    		eqptIcon = "app/assets/images/admin/LIGHT.png";
	    	} else if(varEqptId == '3') {
	    		eqptIcon = "app/assets/images/admin/UPS.png";
	    	} else if(varEqptId == '4') {
	    		eqptIcon = "app/assets/images/admin/DG.png";
	    	} else if(varEqptId == '5') {
	    		eqptIcon = "app/assets/images/admin/LIFT.png";
	    	}
    	}
    	return eqptIcon;
    }
    
//    $scope.addNewConfig = function () {
//        /* add child */
//        if( $scope.temporaryNode.id && $scope.temporaryNode.label ) {
//        	
//        	var arr = [{count:5, text: $scope.temporaryNode.id, header:$scope.temporaryNode.label}];
//        	console.log(arr);
//        	$scope.numOfMaps.push(angular.copy(arr));
//        }
//    };
    
    ///// Open popup on click of Add and Edit Configuration buttons
    $scope.openAddEditConfigWindow = function (varDevice) { //openSettingsWindow
    	$scope.device = varDevice;
    	$scope.modalTitle = $scope.getEqptName(varDevice.eqptId) + " Configuration";
    	$scope.modalSubTitle = "for " + $scope.lblSelectedTreeNode;
    	var modalInstance = $uibModal.open({
    	      animation: true,
    	      templateUrl: 'add_edit_eqptConfiguration', //adminHome.html
    	      controller: 'add_edit_eqptConfigurationModalCtrl',
    	      windowClass: 'modal-conf-form', // app.css
    	      scope:$scope,
    	});
    	
    	modalInstance.result.then(function (varFormDevice) {
    	      varDevice.isConfigured = true;
    	      varDevice.sensorId = varFormDevice.sensorId;
    	    });
    } // end : openAddConfigWindow
    
    ///// Open popup on click of Remove button
    $scope.openRemoveConfigWindow = function (varDevice) { 
    	$scope.device = varDevice;
    	$scope.modalTitle = $scope.getEqptName(varDevice.eqptId) + " Configuration";
    	$scope.modalSubTitle = "for " + $scope.lblSelectedTreeNode;
    	var modalInstance = $uibModal.open({
    	      animation: true,
    	      templateUrl: 'remove_eqptConfiguration', //adminHome.html
    	      controller: 'remove_eqptConfigurationModalCtrl',
    	      windowClass: 'modal-conf-form', // app.css
    	      scope:$scope,
    	});
    	
    	modalInstance.result.then(function (varFormDevice) {
    	      console.log(varDevice);
    	      varDevice.isConfigured = false;
    	      varDevice.sensorId = "";
    	    });
    } // end : openRemoveConfigWindow
});


/****  Controller for 'add edit eqpt Configuration' modal  ****/
app.controller('add_edit_eqptConfigurationModalCtrl', function ($scope, $uibModalInstance) { //, resultData

	  $scope.ok = function () {
		  $uibModalInstance.close($scope.device);
	  };

	  $scope.cancel = function () {
		  $uibModalInstance.dismiss('cancel');
	  };
});

/****  Controller for 'remove eqpt Configuration' modal  ****/
app.controller('remove_eqptConfigurationModalCtrl', function ($scope, $uibModalInstance) { //, resultData

	  $scope.remove = function () {
		  $uibModalInstance.close($scope.device);
	  };

	  $scope.cancel = function () {
		  $uibModalInstance.dismiss('cancel');
	  };
});

/*
@license Angular Treeview version 0.1.6
ⓒ 2013 AHN JAE-HA http://github.com/eu81273/angular.treeview
License: MIT
*/
//
//(function(f){f.module("angularTreeview",[]).directive("treeModel",function($compile){return{restrict:"A",link:function(b,h,c){var a=c.treeId,g=c.treeModel,e=c.nodeLabel||"label",d=c.nodeChildren||"children",e='<ul><li data-ng-repeat="node in '+g+'"><i class="collapsed" data-ng-show="node.'+d+'.length && node.collapsed" data-ng-click="'+a+'.selectNodeHead(node)"></i><i class="expanded" data-ng-show="node.'+d+'.length && !node.collapsed" data-ng-click="'+a+'.selectNodeHead(node)"></i><i class="normal" data-ng-hide="node.'+
//d+'.length"></i> <span data-ng-class="node.selected" data-ng-click="'+a+'.selectNodeLabel(node)">{{node.'+e+'}}</span><div data-ng-hide="node.collapsed" data-tree-id="'+a+'" data-tree-model="node.'+d+'" data-node-id='+(c.nodeId||"id")+" data-node-label="+e+" data-node-children="+d+"></div></li></ul>";a&&g&&(c.angularTreeview&&(b[a]=b[a]||{},b[a].selectNodeHead=b[a].selectNodeHead||function(a){a.collapsed=!a.collapsed},b[a].selectNodeLabel=b[a].selectNodeLabel||function(c){b[a].currentNode&&b[a].currentNode.selected&&
//(b[a].currentNode.selected=void 0);c.selected="selected";b[a].currentNode=c}),h.html('').append($compile(e)(b)))}}})})(angular);
//
//
