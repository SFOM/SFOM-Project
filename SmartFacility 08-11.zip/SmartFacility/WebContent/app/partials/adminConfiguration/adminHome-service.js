app.service('adminHomeService', function($http) {

	this.locationList =[
      { label : "TCS Commercial", id : "1", children : [
        { label : "S-1", id : "1.1", children : [
            { label : "Floor-1", id : "1.1.1", floorNo:'1', children : []},
            { label : "Floor-2", id : "1.1.2", floorNo:'2', children : []},
            { label : "Floor-3", id : "1.1.3", floorNo:'3', children : []}
         ] },
         { label : "S-2", id : "1.2", children : [
              { label : "Ground Floor", id : "1.2.0", floorNo:'0', children : []},
		      { label : "Floor-1", id : "1.2.1", floorNo:'1', children : []},
			  { label : "Floor-2", id : "1.2.2", floorNo:'2', children : []},
			  { label : "Floor-3", id : "1.2.3", floorNo:'3', children : []}
        ]}
      ]} //,

//      { label : "TCS,CZ", id : "role2", children : [
//                                                    
//            { label : "CZ1", id : "role11", children : [
//		          { label : "Floor-1", id : "role121", children : []},
//		          { label : "Floor-2", id : "role121", children : []},
//		          { label : "Floor-3", id : "role121", children : []}
//		       ] },
//		      { label : "CZ2", id : "role12", children : [
//			      { label : "Floor-1", id : "role121", children : []},
//				  { label : "Floor-2", id : "role121", children : []},
//				  { label : "Floor-3", id : "role121", children : []}
//		      ]}   
//                                                    
//      ] },

//      { label : "TCS,Mum", id : "role3", children : [
//         	{ label : "Mum1", id : "role11", children : [
//	          { label : "Floor-1", id : "role121", children : []},
//	          { label : "Floor-2", id : "role121", children : []},
//	          { label : "Floor-3", id : "role121", children : []}
//	       ] },
//	      { label : "Mum2", id : "role12", children : [
//		      { label : "Floor-1", id : "role121", children : []},
//			  { label : "Floor-2", id : "role121", children : []},
//			  { label : "Floor-3", id : "role121", children : []}
//	      ]}   
//                                                     
//	       ] }
    ];
	
	this.equipmentList = [
          {		eqptId:'1', eqptCode:'HVAC', eqptName:'HVAC', eqptDesc:'' },
          {		eqptId:'2', eqptCode:'LIGHT', eqptName:'Light', eqptDesc:''},
          {		eqptId:'3', eqptCode:'UPS', eqptName:'UPS', eqptDesc:'' },
    	  {		eqptId:'4', eqptCode:'DG', eqptName:'Diesel Generator', eqptDesc:''},
    	  {		eqptId:'5', eqptCode:'LIFT', eqptName:'Lift', eqptDesc:''}
      ]
	
	this.floorEquipList = [
       // S-1
         {
        	 locId:'1', subLocId:'1.1', flrId:'1', eqptId:'1', floorNo:'1', floorDesc:'Floor-1', isConfigured:true, sensorId: '001'// HVAC
         },
         {
        	 locId:'1', subLocId:'1.1', flrId:'2', eqptId:'2', floorNo:'1', floorDesc:'Floor-1', isConfigured:true, sensorId: '012' // LIGHT
         },
         {
			 locId:'1', subLocId:'1.1', flrId:'3', eqptId:'3', floorNo:'1', floorDesc:'Floor-1', isConfigured:true, sensorId: '020' // UPS
		 },
		 {
			 locId:'1', subLocId:'1.1', flrId:'4', eqptId:'4', floorNo:'1', floorDesc:'Floor-1', isConfigured:false, sensorId: '' // DG
		 },
		 {
			 locId:'1', subLocId:'1.1', flrId:'5', eqptId:'5', floorNo:'1', floorDesc:'Floor-1', isConfigured:false, sensorId: '' // LIFT
		 },
         {
        	 locId:'1', subLocId:'1.1', flrId:'6', eqptId:'1', floorNo:'2', floorDesc:'Floor-2', isConfigured:true, sensorId: '002' // HVAC
         },
         {
        	 locId:'1', subLocId:'1.1', flrId:'7', eqptId:'2', floorNo:'2', floorDesc:'Floor-2', isConfigured:true, sensorId: '011' // LIGHT
		 },
		 {
			 locId:'1', subLocId:'1.1', flrId:'8', eqptId:'3', floorNo:'2', floorDesc:'Floor-2', isConfigured:false, sensorId: '' // UPS
		 },
		 {
			 locId:'1', subLocId:'1.1', flrId:'9', eqptId:'4', floorNo:'2', floorDesc:'Floor-2', isConfigured:false, sensorId: '' // DG
		 },
		 {
			 locId:'1', subLocId:'1.1', flrId:'10', eqptId:'5', floorNo:'2', floorDesc:'Floor-2', isConfigured:false, sensorId: '' // LIFT
		 },
		 {
        	 locId:'1', subLocId:'1.1', flrId:'6', eqptId:'1', floorNo:'3', floorDesc:'Floor-3', isConfigured:true, sensorId: '002' // HVAC
         },
         {
        	 locId:'1', subLocId:'1.1', flrId:'7', eqptId:'2', floorNo:'3', floorDesc:'Floor-3', isConfigured:true, sensorId: '013' // LIGHT
		 },
		 {
			 locId:'1', subLocId:'1.1', flrId:'8', eqptId:'3', floorNo:'3', floorDesc:'Floor-3', isConfigured:false, sensorId: '' // UPS
		 },
		 {
			 locId:'1', subLocId:'1.1', flrId:'9', eqptId:'4', floorNo:'3', floorDesc:'Floor-3', isConfigured:true, sensorId: '032' // DG
		 },
		 {
			 locId:'1', subLocId:'1.1', flrId:'10', eqptId:'5', floorNo:'3', floorDesc:'Floor-3', isConfigured:false, sensorId: '' // LIFT
		 },
		 // S-2
		 {
        	 locId:'1', subLocId:'1.2', flrId:'11', eqptId:'1', floorNo:'0', floorDesc:'Ground Floor', isConfigured:false, sensorId: '' // HVAC
         },
         {
        	 locId:'1', subLocId:'1.2', flrId:'12', eqptId:'2', floorNo:'0', floorDesc:'Ground Floor', isConfigured:true, sensorId: '016' // LIGHT
         },
         {
        	 locId:'1', subLocId:'1.2', flrId:'13', eqptId:'3', floorNo:'0', floorDesc:'Ground Floor', isConfigured:true, sensorId: '021' // UPS
         },
		 {
			 locId:'1', subLocId:'1.2', flrId:'14', eqptId:'4', floorNo:'0', floorDesc:'Ground Floor', isConfigured:true, sensorId: '035' // DG
		 },
		 {
			 locId:'1', subLocId:'1.2', flrId:'15', eqptId:'5', floorNo:'0', floorDesc:'Ground Floor', isConfigured:true, sensorId: '041' // LIFT
		 },
		 {
        	 locId:'1', subLocId:'1.2', flrId:'1', eqptId:'1', floorNo:'1', floorDesc:'Floor-1', isConfigured:false, sensorId: '' // HVAC
         },
         {
        	 locId:'1', subLocId:'1.2', flrId:'2', eqptId:'2', floorNo:'1', floorDesc:'Floor-1', isConfigured:true, sensorId: '013' // LIGHT
         },
         {
			 locId:'1', subLocId:'1.2', flrId:'3', eqptId:'3', floorNo:'1', floorDesc:'Floor-1', isConfigured:true, sensorId: '033' // UPS
		 },
		 {
			 locId:'1', subLocId:'1.2', flrId:'4', eqptId:'4', floorNo:'1', floorDesc:'Floor-1', isConfigured:true, sensorId: '044' // DG
		 },
		 {
			 locId:'1', subLocId:'1.2', flrId:'5', eqptId:'5', floorNo:'1', floorDesc:'Floor-1', isConfigured:false, sensorId: '' // LIFT
		 },
         {
        	 locId:'1', subLocId:'1.2', flrId:'6', eqptId:'1', floorNo:'2', floorDesc:'Floor-2', isConfigured:true, sensorId: '005' // HVAC
         },
         {
        	 locId:'1', subLocId:'1.2', flrId:'7', eqptId:'2', floorNo:'2', floorDesc:'Floor-2', isConfigured:true, sensorId: '015' // LIGHT
		 },
		 {
			 locId:'1', subLocId:'1.2', flrId:'8', eqptId:'3', floorNo:'2', floorDesc:'Floor-2', isConfigured:false, sensorId: '' // UPS
		 },
		 {
			 locId:'1', subLocId:'1.2', flrId:'9', eqptId:'4', floorNo:'2', floorDesc:'Floor-2', isConfigured:false, sensorId: '' // DG
		 },
		 {
			 locId:'1', subLocId:'1.2', flrId:'10', eqptId:'5', floorNo:'2', floorDesc:'Floor-2', isConfigured:true, sensorId: '053' // LIFT
		 },
		 {
        	 locId:'1', subLocId:'1.2', flrId:'16', eqptId:'1', floorNo:'3', floorDesc:'Floor-3', isConfigured:false, sensorId: '' // HVAC
         },
		 {
			 locId:'1', subLocId:'1.2', flrId:'17', eqptId:'2', floorNo:'3', floorDesc:'Floor-3', isConfigured:true, sensorId: '017' // LIGHT
		 },
		 {
			 locId:'1', subLocId:'1.2', flrId:'18', eqptId:'3', floorNo:'3', floorDesc:'Floor-3', isConfigured:true, sensorId: '034' // UPS
		 },
		 {
			 locId:'1', subLocId:'1.2', flrId:'19', eqptId:'4', floorNo:'3', floorDesc:'Floor-3', isConfigured:true, sensorId: '045' // DG
		 },
//		 {
//			 locId:'1', subLocId:'1.2', flrId:'20', eqptId:'5', floorNo:'3', floorDesc:'Floor-3', isConfigured:true, sensorId: '054' // LIFT
//		 }
	];
});