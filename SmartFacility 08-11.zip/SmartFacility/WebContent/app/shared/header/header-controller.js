app.controller('headerCtrl',  function($scope, $location, $rootScope, $state) {
	//console.log("App Controller reporting for duty.");
	$scope.location = $location;
	
	/*console.log(location.hash);*/

	$scope.state = $state;
	
	
	
	/*$scope.logoutButton=true;
	var url=$location.absUrl();
	var split=url.split("/")[5];
	console.log(url);
	console.log(split);
	if(split=='login')
		{
		   $scope.logoutButton=false;
		}
	
	$scope.HomeButton=false;
	$scope.HomeButton2=false;
	$scope.WelcomeButton=false;
	
	if(split!='home')
	{
		$scope.HomeButton=true;
	}
	
	if(split=='home')
	{
		$scope.HomeButton2=true;
	}
	
	if(split=='home')
	{
		$scope.WelcomeButton=true;
	}*/
	
	
	
	
	/*$scope.btnLogoutDisplay = 'none';
	
	$rootScope.$on('$stateChangeSuccess', function() {
		console.log(location.hash);
		console.log(location.hash());
		console.log(location.path);
		console.log(location.path());
		
		
		
		if(location.hash == '#/login') {
			console.log("App Controller reporting for duty.");
			var child = $("#topNav");
	        $("#topNav").addClass("loginHeader");
	        $scope.btnLogoutDisplay = 'none';
		} else {
			$("#topNav").removeClass("loginHeader");
			console.log("App Controller reporting for duty 2.");
			$scope.btnLogoutDisplay = 'block';
		}
	});*/
	
});
	






	




