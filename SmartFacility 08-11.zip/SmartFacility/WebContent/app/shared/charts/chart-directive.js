
/*******************************************************************************
 * *****************   CHART DIRECTIVES - GAUGE, COLUMN, BAR   *****************
 ******************************************************************************/

/** Draw Gauge chart  **/
/*** Gauge does not have event handler i.e. Click on gauge will not work **/
app.directive('gaugeChartDrct', function () {
	
	return {
		restrict: 'A',  /**a directive can be used as a class, an attribute, or a tag. Using directive here as an attribute**/
	    link: function ($scope, elm, attrs) {
	    	
	    	$scope.$watch('chart', function() {
	    	
	    		if($scope.chart) {
		    		 
			    	var chart = new google.visualization.Gauge(elm[0]);
			    	chart.draw($scope.chart.data, $scope.chart.options);
	    		}
	    		
	    	}, true);
	    }
	};

});



/** Draw pie chart  **/
/*** Gauge does not have event handler i.e. Click on gauge will not work **/
app.directive('pieChartDrct', function () {
	
	return {
		restrict: 'A',  /**a directive can be used as a class, an attribute, or a tag. Using directive here as an attribute**/
	    link: function ($scope, elm, attrs) {
	    	
	    	$scope.$watch('chart', function() {
	    		if($scope.chart) {
		    		 
			    	var chart = new google.visualization.Pie(elm[0]);
			    	chart.draw($scope.chart.data, $scope.chart.options);
	    		}
	    	}, true);
	    }
	};

});




/** Draw Column/Bar chart  **/

app.directive('barChartDrct', function () {
	
	return {
		restrict: 'A',  /**a directive can be used as a class, an attribute, or a tag. Using directive here as an attribute**/
	    link: function ($scope, elm, attrs) {
	    	
	    	$scope.$watch('chart', function() {
	    		if($scope.chart) {
	    			
	    			var chart = new google.visualization.ColumnChart(elm[0]);
	    			/*var chart = new google.visualization.Line(elm[0]);*/
	    			chart.draw($scope.chart.data, $scope.chart.options);
		    	
	    		}
	    	}, true);
	    }
	};

});


/**  Line chart  **/
app.directive('lineChartDrct', function () {
	
	return {
		restrict: 'A',  /**a directive can be used as a class, an attribute, or a tag. Using directive here as an attribute**/
	    link: function ($scope, elm, attrs) {
	    	$scope.$watch('chart', function() {
	    		if($scope.chart) {
		    		var chart = new google.visualization.LineChart(elm[0]);
		    		//**************| Attach Custom Chart Column Select Handler |***************//
			    	if($scope.customSelectHandler) {
			    		google.visualization.events.addListener(chart, 'select', selectHandler);
			    		function selectHandler () {
			    			$scope.customSelectHandler(chart, $scope.chart);
			    		}
			    	}
			    	//**************| |***************//
			    	chart.draw($scope.chart.data, $scope.chart.options);
	    		}
	    	}, true);
	    }
	};
});

/**  Material Line chart  **/
app.directive('materialLineChartDrct', function () {
	

	return {
		restrict: 'A',  /**a directive can be used as a class, an attribute, or a tag. Using directive here as an attribute**/
	    link: function ($scope, elm, attrs) {
	    	$scope.$watch('chart', function() {
	    		if($scope.chart) {
		    		//var chart = new google.visualization.LineChart(elm[0]);
	    			var chart = new google.charts.Line(elm[0]);
		    		//**************| Attach Custom Chart Column Select Handler |***************//
			    	if($scope.customSelectHandler) {
			    		google.visualization.events.addListener(chart, 'select', selectHandler);
			    		function selectHandler () {
			    			$scope.customSelectHandler(chart, $scope.chart);
			    		}
			    	}
			    	//**************| |***************//
			    	chart.draw($scope.chart.data,  google.charts.Line.convertOptions($scope.chart.options));
	    		}
	    	}, true);
	    }
	
	};
});


/** Column chart  **/
app.directive('columnChartDrct', function () {
	
	return {
		restrict: 'A',  /**a directive can be used as a class, an attribute, or a tag. Using directive here as an attribute**/
	    link: function ($scope, elm, attrs) {
	    	$scope.$watch('chart', function() {
	    		if($scope.chart) {
		    		 
			    	var chart = new google.visualization.ColumnChart(elm[0]);
			    	chart.draw($scope.chart.data, $scope.chart.options);
	    		}
	    	}, true);
	    }
	};

});


/** Combo chart  **/
app.directive('comboChartDrct', function () {
	
	return {
		restrict: 'A',  /**a directive can be used as a class, an attribute, or a tag. Using directive here as an attribute**/
	    link: function ($scope, elm, attrs) {
	    	$scope.$watch('chart', function() {
	    		if($scope.chart) {
		    		 
			    	var chart = new google.visualization.ComboChart(elm[0]);
			    	chart.draw($scope.chart.data, $scope.chart.options);
	    		}
	    	}, true);
	    }
	};

});