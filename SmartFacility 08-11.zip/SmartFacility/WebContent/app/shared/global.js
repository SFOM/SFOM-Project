/**
 * Created by: Lekha (#246292)
 */

/**************************** SHARED VARIABLES ******************************/
_modalColumnChartTemplateUrl = "app/shared/modals/modalColumnChart.html";
_modalPieChartTemplateUrl = "app/shared/modals/modalPieChart.html";
_modalLineChartTemplateUrl = "app/shared/modals/modalLineChart.html";
/***************************** SHARED FUNCTIONS *****************************/

	/** transform the successful response, unwrapping the application data from API response payload **/
    function handleSuccess( response ) {
    	console.log(response.data);
    	var csvAsArray = response.data.csvToArray();
    	//csvAsArray.splice(0, 1);  //to remove labels from array
    	
    	// csvToArray() generates array of strings, but chart data table requires array of numbers. Convert below
    	$.each( csvAsArray, function(i, arrValue) {
    		$.each( arrValue, function(j, value) {
    			if($.isNumeric(value)) 
    				csvAsArray[i][j] = Number(value);
    		});
    	});
        return( csvAsArray );
    }
    
    /** transform the error response, unwrapping the application dta from API response payload **/
    function handleError( response ) {
		// The API response from the server should be returned in a nomralized format. 
		// However, if the request was not handled by the server (or what not handles properly - ex. server error), 
		// then we may have to normalize it on our end, as best we can.
        if ( ! angular.isObject( response.data ) || ! response.data.message ) {
            return( $q.reject( "An unknown error occurred." ) );
        }

        // Otherwise, use expected error message.
        return( $q.reject( response.data.message ) );
    }
    
    /**** Common Procedure to read csv file ***/
	readCsvFile = function ($http, url) {
		var request = $http({
	    		method: "get",
	    		url: url
    	});
    	return( request.then( handleSuccess, handleError ) );
	}
	
	/** Directive similar to Document.ready  **/
	app.directive( 'elemReady', function( $parse ) {
		   return {
		       restrict: 'A',
		       link: function( $scope, elem, attrs ) {    
		          elem.ready(function(){
		            $scope.$apply(function(){
		                var func = $parse(attrs.elemReady);
		                func($scope);
		            })
		          })
		       }
		    }
		})